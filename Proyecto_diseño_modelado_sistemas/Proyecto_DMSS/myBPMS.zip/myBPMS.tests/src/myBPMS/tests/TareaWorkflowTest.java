/**
 */
package myBPMS.tests;

import myBPMS.TareaWorkflow;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Tarea Workflow</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class TareaWorkflowTest extends TareaTest {

	/**
	 * Constructs a new Tarea Workflow test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TareaWorkflowTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Tarea Workflow test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected TareaWorkflow getFixture() {
		return (TareaWorkflow)fixture;
	}

} //TareaWorkflowTest

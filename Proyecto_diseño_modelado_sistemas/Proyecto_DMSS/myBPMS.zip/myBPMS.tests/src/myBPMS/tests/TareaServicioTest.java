/**
 */
package myBPMS.tests;

import junit.textui.TestRunner;

import myBPMS.MyBPMSFactory;
import myBPMS.TareaServicio;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Tarea Servicio</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class TareaServicioTest extends TareaWorkflowTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(TareaServicioTest.class);
	}

	/**
	 * Constructs a new Tarea Servicio test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TareaServicioTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Tarea Servicio test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected TareaServicio getFixture() {
		return (TareaServicio)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MyBPMSFactory.eINSTANCE.createTareaServicio());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //TareaServicioTest

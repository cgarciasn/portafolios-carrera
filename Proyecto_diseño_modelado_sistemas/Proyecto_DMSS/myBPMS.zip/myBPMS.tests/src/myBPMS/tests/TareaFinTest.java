/**
 */
package myBPMS.tests;

import junit.textui.TestRunner;

import myBPMS.MyBPMSFactory;
import myBPMS.TareaFin;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Tarea Fin</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class TareaFinTest extends TareaTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(TareaFinTest.class);
	}

	/**
	 * Constructs a new Tarea Fin test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TareaFinTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Tarea Fin test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected TareaFin getFixture() {
		return (TareaFin)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MyBPMSFactory.eINSTANCE.createTareaFin());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //TareaFinTest

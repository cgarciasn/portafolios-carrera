/**
 */
package myBPMS.tests;

import junit.framework.TestCase;

import myBPMS.Tarea;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Tarea</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class TareaTest extends TestCase {

	/**
	 * The fixture for this Tarea test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Tarea fixture = null;

	/**
	 * Constructs a new Tarea test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TareaTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Tarea test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Tarea fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Tarea test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Tarea getFixture() {
		return fixture;
	}

} //TareaTest

/**
 */
package myBPMS.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import myBPMS.MyBPMSFactory;
import myBPMS.ProcesoDeNegocio;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Proceso De Negocio</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class ProcesoDeNegocioTest extends TestCase {

	/**
	 * The fixture for this Proceso De Negocio test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProcesoDeNegocio fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(ProcesoDeNegocioTest.class);
	}

	/**
	 * Constructs a new Proceso De Negocio test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProcesoDeNegocioTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Proceso De Negocio test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(ProcesoDeNegocio fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Proceso De Negocio test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProcesoDeNegocio getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MyBPMSFactory.eINSTANCE.createProcesoDeNegocio());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //ProcesoDeNegocioTest

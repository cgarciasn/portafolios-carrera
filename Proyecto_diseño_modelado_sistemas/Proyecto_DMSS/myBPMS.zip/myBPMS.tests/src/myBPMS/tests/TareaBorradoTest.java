/**
 */
package myBPMS.tests;

import junit.textui.TestRunner;

import myBPMS.MyBPMSFactory;
import myBPMS.TareaBorrado;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Tarea Borrado</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class TareaBorradoTest extends TareaWorkflowTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(TareaBorradoTest.class);
	}

	/**
	 * Constructs a new Tarea Borrado test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TareaBorradoTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Tarea Borrado test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected TareaBorrado getFixture() {
		return (TareaBorrado)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MyBPMSFactory.eINSTANCE.createTareaBorrado());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //TareaBorradoTest

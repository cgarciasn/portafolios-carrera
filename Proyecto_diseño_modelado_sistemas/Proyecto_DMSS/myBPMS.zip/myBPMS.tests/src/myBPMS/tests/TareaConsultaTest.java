/**
 */
package myBPMS.tests;

import junit.textui.TestRunner;

import myBPMS.MyBPMSFactory;
import myBPMS.TareaConsulta;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Tarea Consulta</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class TareaConsultaTest extends TareaWorkflowTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(TareaConsultaTest.class);
	}

	/**
	 * Constructs a new Tarea Consulta test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TareaConsultaTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Tarea Consulta test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected TareaConsulta getFixture() {
		return (TareaConsulta)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MyBPMSFactory.eINSTANCE.createTareaConsulta());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //TareaConsultaTest

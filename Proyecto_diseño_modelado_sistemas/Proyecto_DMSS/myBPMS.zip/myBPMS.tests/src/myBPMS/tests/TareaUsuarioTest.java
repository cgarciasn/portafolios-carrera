/**
 */
package myBPMS.tests;

import junit.textui.TestRunner;

import myBPMS.MyBPMSFactory;
import myBPMS.TareaUsuario;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Tarea Usuario</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class TareaUsuarioTest extends TareaWorkflowTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(TareaUsuarioTest.class);
	}

	/**
	 * Constructs a new Tarea Usuario test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TareaUsuarioTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Tarea Usuario test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected TareaUsuario getFixture() {
		return (TareaUsuario)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MyBPMSFactory.eINSTANCE.createTareaUsuario());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //TareaUsuarioTest

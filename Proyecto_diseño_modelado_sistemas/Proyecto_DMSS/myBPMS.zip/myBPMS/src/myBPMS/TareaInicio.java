/**
 */
package myBPMS;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tarea Inicio</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see myBPMS.MyBPMSPackage#getTareaInicio()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='r8tas'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot r8tas='self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor'"
 *        annotation="gmf.node label.placement='none' color='44,178,182' figure='rectangle'"
 * @generated
 */
public interface TareaInicio extends Tarea {
} // TareaInicio

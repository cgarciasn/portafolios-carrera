/**
 */
package myBPMS;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Proceso De Negocio</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.ProcesoDeNegocio#getActores <em>Actores</em>}</li>
 *   <li>{@link myBPMS.ProcesoDeNegocio#getId_proceso <em>Id proceso</em>}</li>
 *   <li>{@link myBPMS.ProcesoDeNegocio#getBasesdedatos <em>Basesdedatos</em>}</li>
 * </ul>
 *
 * @see myBPMS.MyBPMSPackage#getProcesoDeNegocio()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='r1 r2'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot r1='self.actores.tareas->selectByType(TareaInicio)->size() = 1' r2='self.actores.tareas->selectByType(TareaFin)->size() = 1'"
 * @generated
 */
public interface ProcesoDeNegocio extends EObject {
	/**
	 * Returns the value of the '<em><b>Actores</b></em>' containment reference list.
	 * The list contents are of type {@link myBPMS.Actor}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Actores</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Actores</em>' containment reference list.
	 * @see myBPMS.MyBPMSPackage#getProcesoDeNegocio_Actores()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Actor> getActores();

	/**
	 * Returns the value of the '<em><b>Id proceso</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id proceso</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id proceso</em>' attribute.
	 * @see #setId_proceso(String)
	 * @see myBPMS.MyBPMSPackage#getProcesoDeNegocio_Id_proceso()
	 * @model required="true"
	 * @generated
	 */
	String getId_proceso();

	/**
	 * Sets the value of the '{@link myBPMS.ProcesoDeNegocio#getId_proceso <em>Id proceso</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id proceso</em>' attribute.
	 * @see #getId_proceso()
	 * @generated
	 */
	void setId_proceso(String value);

	/**
	 * Returns the value of the '<em><b>Basesdedatos</b></em>' containment reference list.
	 * The list contents are of type {@link myBPMS.BaseDeDatos}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Basesdedatos</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Basesdedatos</em>' containment reference list.
	 * @see myBPMS.MyBPMSPackage#getProcesoDeNegocio_Basesdedatos()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<BaseDeDatos> getBasesdedatos();

} // ProcesoDeNegocio

/**
 */
package myBPMS;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tarea Envio Msj</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.TareaEnvioMsj#getEnvio_msj <em>Envio msj</em>}</li>
 *   <li>{@link myBPMS.TareaEnvioMsj#getCodificacion <em>Codificacion</em>}</li>
 *   <li>{@link myBPMS.TareaEnvioMsj#getAdjunta <em>Adjunta</em>}</li>
 * </ul>
 *
 * @see myBPMS.MyBPMSPackage#getTareaEnvioMsj()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='r10 r8tes r8tep'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot r10='self.codificacion = self.sucesor.oclAsType(TareaRecepMsj).codificacion' r8tes='self.oclContainer().oclAsType(Actor).id_actor <> self.sucesor.oclContainer().oclAsType(Actor).id_actor' r8tep='self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor'"
 *        annotation="gmf.node label='id_tareaworkflow' color='4,46,255' figure='rectangle'"
 * @generated
 */
public interface TareaEnvioMsj extends TareaWorkflow {
	/**
	 * Returns the value of the '<em><b>Envio msj</b></em>' reference list.
	 * The list contents are of type {@link myBPMS.Tabla}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Envio msj</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Envio msj</em>' reference list.
	 * @see myBPMS.MyBPMSPackage#getTareaEnvioMsj_Envio_msj()
	 * @model required="true"
	 *        annotation="gmf.link target='envio_msj' target.decoration='arrow' style='dash'"
	 * @generated
	 */
	EList<Tabla> getEnvio_msj();

	/**
	 * Returns the value of the '<em><b>Codificacion</b></em>' attribute.
	 * The literals are from the enumeration {@link myBPMS.Tipo_codificacion}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Codificacion</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Codificacion</em>' attribute.
	 * @see myBPMS.Tipo_codificacion
	 * @see #setCodificacion(Tipo_codificacion)
	 * @see myBPMS.MyBPMSPackage#getTareaEnvioMsj_Codificacion()
	 * @model
	 * @generated
	 */
	Tipo_codificacion getCodificacion();

	/**
	 * Sets the value of the '{@link myBPMS.TareaEnvioMsj#getCodificacion <em>Codificacion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Codificacion</em>' attribute.
	 * @see myBPMS.Tipo_codificacion
	 * @see #getCodificacion()
	 * @generated
	 */
	void setCodificacion(Tipo_codificacion value);

	/**
	 * Returns the value of the '<em><b>Adjunta</b></em>' reference list.
	 * The list contents are of type {@link myBPMS.Fichero}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Adjunta</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Adjunta</em>' reference list.
	 * @see myBPMS.MyBPMSPackage#getTareaEnvioMsj_Adjunta()
	 * @model annotation="gmf.link taget='adjunta' target.decoration='rhomb' style='dash'"
	 * @generated
	 */
	EList<Fichero> getAdjunta();

} // TareaEnvioMsj

/**
 */
package myBPMS;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Atributo</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.Atributo#getId_atributo <em>Id atributo</em>}</li>
 *   <li>{@link myBPMS.Atributo#getTipo_atributo <em>Tipo atributo</em>}</li>
 *   <li>{@link myBPMS.Atributo#getClave_ajena <em>Clave ajena</em>}</li>
 *   <li>{@link myBPMS.Atributo#isVisible <em>Visible</em>}</li>
 *   <li>{@link myBPMS.Atributo#getClave_primaria <em>Clave primaria</em>}</li>
 * </ul>
 *
 * @see myBPMS.MyBPMSPackage#getAtributo()
 * @model annotation="gmf.node label='id_atributo' color='100,44,182' figure='rectangle'"
 * @generated
 */
public interface Atributo extends EObject {
	/**
	 * Returns the value of the '<em><b>Id atributo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id atributo</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id atributo</em>' attribute.
	 * @see #setId_atributo(String)
	 * @see myBPMS.MyBPMSPackage#getAtributo_Id_atributo()
	 * @model required="true"
	 * @generated
	 */
	String getId_atributo();

	/**
	 * Sets the value of the '{@link myBPMS.Atributo#getId_atributo <em>Id atributo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id atributo</em>' attribute.
	 * @see #getId_atributo()
	 * @generated
	 */
	void setId_atributo(String value);

	/**
	 * Returns the value of the '<em><b>Tipo atributo</b></em>' attribute.
	 * The literals are from the enumeration {@link myBPMS.Tipo_atributo}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tipo atributo</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tipo atributo</em>' attribute.
	 * @see myBPMS.Tipo_atributo
	 * @see #setTipo_atributo(Tipo_atributo)
	 * @see myBPMS.MyBPMSPackage#getAtributo_Tipo_atributo()
	 * @model
	 * @generated
	 */
	Tipo_atributo getTipo_atributo();

	/**
	 * Sets the value of the '{@link myBPMS.Atributo#getTipo_atributo <em>Tipo atributo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tipo atributo</em>' attribute.
	 * @see myBPMS.Tipo_atributo
	 * @see #getTipo_atributo()
	 * @generated
	 */
	void setTipo_atributo(Tipo_atributo value);

	/**
	 * Returns the value of the '<em><b>Clave ajena</b></em>' reference list.
	 * The list contents are of type {@link myBPMS.Tabla}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Clave ajena</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Clave ajena</em>' reference list.
	 * @see myBPMS.MyBPMSPackage#getAtributo_Clave_ajena()
	 * @model annotation="gmf.link target='clave_ajena' target.decoration='square' style='dash'"
	 * @generated
	 */
	EList<Tabla> getClave_ajena();

	/**
	 * Returns the value of the '<em><b>Visible</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Visible</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Visible</em>' attribute.
	 * @see #setVisible(boolean)
	 * @see myBPMS.MyBPMSPackage#getAtributo_Visible()
	 * @model
	 * @generated
	 */
	boolean isVisible();

	/**
	 * Sets the value of the '{@link myBPMS.Atributo#isVisible <em>Visible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Visible</em>' attribute.
	 * @see #isVisible()
	 * @generated
	 */
	void setVisible(boolean value);

	/**
	 * Returns the value of the '<em><b>Clave primaria</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Clave primaria</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Clave primaria</em>' reference.
	 * @see #setClave_primaria(Tabla)
	 * @see myBPMS.MyBPMSPackage#getAtributo_Clave_primaria()
	 * @model annotation="gmf.link taget='clave_primaria' target.decoration='arrow' style='dash'"
	 * @generated
	 */
	Tabla getClave_primaria();

	/**
	 * Sets the value of the '{@link myBPMS.Atributo#getClave_primaria <em>Clave primaria</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Clave primaria</em>' reference.
	 * @see #getClave_primaria()
	 * @generated
	 */
	void setClave_primaria(Tabla value);

} // Atributo

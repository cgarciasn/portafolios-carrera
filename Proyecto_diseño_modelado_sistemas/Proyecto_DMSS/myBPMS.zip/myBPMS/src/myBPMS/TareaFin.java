/**
 */
package myBPMS;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tarea Fin</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see myBPMS.MyBPMSPackage#getTareaFin()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='r8tfp'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot r8tfp='self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor'"
 *        annotation="gmf.node label.placement='none' color='4,255,217' figure='rectangle'"
 * @generated
 */
public interface TareaFin extends Tarea {
} // TareaFin

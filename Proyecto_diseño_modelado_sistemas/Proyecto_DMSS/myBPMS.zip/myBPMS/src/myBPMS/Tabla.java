/**
 */
package myBPMS;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tabla</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.Tabla#getAtributos <em>Atributos</em>}</li>
 *   <li>{@link myBPMS.Tabla#getId_tabla <em>Id tabla</em>}</li>
 * </ul>
 *
 * @see myBPMS.MyBPMSPackage#getTabla()
 * @model annotation="gmf.node label='id_tabla' color='88,51,255' figure='rectangle'"
 * @generated
 */
public interface Tabla extends EObject {
	/**
	 * Returns the value of the '<em><b>Atributos</b></em>' containment reference list.
	 * The list contents are of type {@link myBPMS.Atributo}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Atributos</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Atributos</em>' containment reference list.
	 * @see myBPMS.MyBPMSPackage#getTabla_Atributos()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Atributo> getAtributos();

	/**
	 * Returns the value of the '<em><b>Id tabla</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id tabla</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id tabla</em>' attribute.
	 * @see #setId_tabla(String)
	 * @see myBPMS.MyBPMSPackage#getTabla_Id_tabla()
	 * @model required="true"
	 * @generated
	 */
	String getId_tabla();

	/**
	 * Sets the value of the '{@link myBPMS.Tabla#getId_tabla <em>Id tabla</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id tabla</em>' attribute.
	 * @see #getId_tabla()
	 * @generated
	 */
	void setId_tabla(String value);

} // Tabla

/**
 */
package myBPMS.impl;

import java.util.Collection;

import myBPMS.Atributo;
import myBPMS.MyBPMSPackage;
import myBPMS.Tabla;
import myBPMS.Tipo_atributo;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Atributo</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.impl.AtributoImpl#getId_atributo <em>Id atributo</em>}</li>
 *   <li>{@link myBPMS.impl.AtributoImpl#getTipo_atributo <em>Tipo atributo</em>}</li>
 *   <li>{@link myBPMS.impl.AtributoImpl#getClave_ajena <em>Clave ajena</em>}</li>
 *   <li>{@link myBPMS.impl.AtributoImpl#isVisible <em>Visible</em>}</li>
 *   <li>{@link myBPMS.impl.AtributoImpl#getClave_primaria <em>Clave primaria</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AtributoImpl extends EObjectImpl implements Atributo {
	/**
	 * The default value of the '{@link #getId_atributo() <em>Id atributo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId_atributo()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_ATRIBUTO_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getId_atributo() <em>Id atributo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId_atributo()
	 * @generated
	 * @ordered
	 */
	protected String id_atributo = ID_ATRIBUTO_EDEFAULT;

	/**
	 * The default value of the '{@link #getTipo_atributo() <em>Tipo atributo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTipo_atributo()
	 * @generated
	 * @ordered
	 */
	protected static final Tipo_atributo TIPO_ATRIBUTO_EDEFAULT = Tipo_atributo.INT;

	/**
	 * The cached value of the '{@link #getTipo_atributo() <em>Tipo atributo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTipo_atributo()
	 * @generated
	 * @ordered
	 */
	protected Tipo_atributo tipo_atributo = TIPO_ATRIBUTO_EDEFAULT;

	/**
	 * The cached value of the '{@link #getClave_ajena() <em>Clave ajena</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClave_ajena()
	 * @generated
	 * @ordered
	 */
	protected EList<Tabla> clave_ajena;

	/**
	 * The default value of the '{@link #isVisible() <em>Visible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isVisible()
	 * @generated
	 * @ordered
	 */
	protected static final boolean VISIBLE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isVisible() <em>Visible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isVisible()
	 * @generated
	 * @ordered
	 */
	protected boolean visible = VISIBLE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getClave_primaria() <em>Clave primaria</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClave_primaria()
	 * @generated
	 * @ordered
	 */
	protected Tabla clave_primaria;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AtributoImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyBPMSPackage.Literals.ATRIBUTO;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getId_atributo() {
		return id_atributo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId_atributo(String newId_atributo) {
		String oldId_atributo = id_atributo;
		id_atributo = newId_atributo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.ATRIBUTO__ID_ATRIBUTO, oldId_atributo, id_atributo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tipo_atributo getTipo_atributo() {
		return tipo_atributo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTipo_atributo(Tipo_atributo newTipo_atributo) {
		Tipo_atributo oldTipo_atributo = tipo_atributo;
		tipo_atributo = newTipo_atributo == null ? TIPO_ATRIBUTO_EDEFAULT : newTipo_atributo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.ATRIBUTO__TIPO_ATRIBUTO, oldTipo_atributo, tipo_atributo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Tabla> getClave_ajena() {
		if (clave_ajena == null) {
			clave_ajena = new EObjectResolvingEList<Tabla>(Tabla.class, this, MyBPMSPackage.ATRIBUTO__CLAVE_AJENA);
		}
		return clave_ajena;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isVisible() {
		return visible;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVisible(boolean newVisible) {
		boolean oldVisible = visible;
		visible = newVisible;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.ATRIBUTO__VISIBLE, oldVisible, visible));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tabla getClave_primaria() {
		if (clave_primaria != null && clave_primaria.eIsProxy()) {
			InternalEObject oldClave_primaria = (InternalEObject)clave_primaria;
			clave_primaria = (Tabla)eResolveProxy(oldClave_primaria);
			if (clave_primaria != oldClave_primaria) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MyBPMSPackage.ATRIBUTO__CLAVE_PRIMARIA, oldClave_primaria, clave_primaria));
			}
		}
		return clave_primaria;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tabla basicGetClave_primaria() {
		return clave_primaria;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setClave_primaria(Tabla newClave_primaria) {
		Tabla oldClave_primaria = clave_primaria;
		clave_primaria = newClave_primaria;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.ATRIBUTO__CLAVE_PRIMARIA, oldClave_primaria, clave_primaria));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MyBPMSPackage.ATRIBUTO__ID_ATRIBUTO:
				return getId_atributo();
			case MyBPMSPackage.ATRIBUTO__TIPO_ATRIBUTO:
				return getTipo_atributo();
			case MyBPMSPackage.ATRIBUTO__CLAVE_AJENA:
				return getClave_ajena();
			case MyBPMSPackage.ATRIBUTO__VISIBLE:
				return isVisible();
			case MyBPMSPackage.ATRIBUTO__CLAVE_PRIMARIA:
				if (resolve) return getClave_primaria();
				return basicGetClave_primaria();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MyBPMSPackage.ATRIBUTO__ID_ATRIBUTO:
				setId_atributo((String)newValue);
				return;
			case MyBPMSPackage.ATRIBUTO__TIPO_ATRIBUTO:
				setTipo_atributo((Tipo_atributo)newValue);
				return;
			case MyBPMSPackage.ATRIBUTO__CLAVE_AJENA:
				getClave_ajena().clear();
				getClave_ajena().addAll((Collection<? extends Tabla>)newValue);
				return;
			case MyBPMSPackage.ATRIBUTO__VISIBLE:
				setVisible((Boolean)newValue);
				return;
			case MyBPMSPackage.ATRIBUTO__CLAVE_PRIMARIA:
				setClave_primaria((Tabla)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.ATRIBUTO__ID_ATRIBUTO:
				setId_atributo(ID_ATRIBUTO_EDEFAULT);
				return;
			case MyBPMSPackage.ATRIBUTO__TIPO_ATRIBUTO:
				setTipo_atributo(TIPO_ATRIBUTO_EDEFAULT);
				return;
			case MyBPMSPackage.ATRIBUTO__CLAVE_AJENA:
				getClave_ajena().clear();
				return;
			case MyBPMSPackage.ATRIBUTO__VISIBLE:
				setVisible(VISIBLE_EDEFAULT);
				return;
			case MyBPMSPackage.ATRIBUTO__CLAVE_PRIMARIA:
				setClave_primaria((Tabla)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.ATRIBUTO__ID_ATRIBUTO:
				return ID_ATRIBUTO_EDEFAULT == null ? id_atributo != null : !ID_ATRIBUTO_EDEFAULT.equals(id_atributo);
			case MyBPMSPackage.ATRIBUTO__TIPO_ATRIBUTO:
				return tipo_atributo != TIPO_ATRIBUTO_EDEFAULT;
			case MyBPMSPackage.ATRIBUTO__CLAVE_AJENA:
				return clave_ajena != null && !clave_ajena.isEmpty();
			case MyBPMSPackage.ATRIBUTO__VISIBLE:
				return visible != VISIBLE_EDEFAULT;
			case MyBPMSPackage.ATRIBUTO__CLAVE_PRIMARIA:
				return clave_primaria != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (id_atributo: ");
		result.append(id_atributo);
		result.append(", tipo_atributo: ");
		result.append(tipo_atributo);
		result.append(", visible: ");
		result.append(visible);
		result.append(')');
		return result.toString();
	}

} //AtributoImpl

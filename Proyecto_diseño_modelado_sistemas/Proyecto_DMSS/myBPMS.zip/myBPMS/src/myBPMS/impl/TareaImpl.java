/**
 */
package myBPMS.impl;

import myBPMS.MyBPMSPackage;
import myBPMS.Tarea;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tarea</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.impl.TareaImpl#getPredecesor <em>Predecesor</em>}</li>
 *   <li>{@link myBPMS.impl.TareaImpl#getSucesor <em>Sucesor</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class TareaImpl extends EObjectImpl implements Tarea {
	/**
	 * The cached value of the '{@link #getPredecesor() <em>Predecesor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPredecesor()
	 * @generated
	 * @ordered
	 */
	protected Tarea predecesor;

	/**
	 * The cached value of the '{@link #getSucesor() <em>Sucesor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSucesor()
	 * @generated
	 * @ordered
	 */
	protected Tarea sucesor;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TareaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyBPMSPackage.Literals.TAREA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tarea getPredecesor() {
		if (predecesor != null && predecesor.eIsProxy()) {
			InternalEObject oldPredecesor = (InternalEObject)predecesor;
			predecesor = (Tarea)eResolveProxy(oldPredecesor);
			if (predecesor != oldPredecesor) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MyBPMSPackage.TAREA__PREDECESOR, oldPredecesor, predecesor));
			}
		}
		return predecesor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tarea basicGetPredecesor() {
		return predecesor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPredecesor(Tarea newPredecesor, NotificationChain msgs) {
		Tarea oldPredecesor = predecesor;
		predecesor = newPredecesor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, MyBPMSPackage.TAREA__PREDECESOR, oldPredecesor, newPredecesor);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPredecesor(Tarea newPredecesor) {
		if (newPredecesor != predecesor) {
			NotificationChain msgs = null;
			if (predecesor != null)
				msgs = ((InternalEObject)predecesor).eInverseRemove(this, MyBPMSPackage.TAREA__SUCESOR, Tarea.class, msgs);
			if (newPredecesor != null)
				msgs = ((InternalEObject)newPredecesor).eInverseAdd(this, MyBPMSPackage.TAREA__SUCESOR, Tarea.class, msgs);
			msgs = basicSetPredecesor(newPredecesor, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.TAREA__PREDECESOR, newPredecesor, newPredecesor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tarea getSucesor() {
		if (sucesor != null && sucesor.eIsProxy()) {
			InternalEObject oldSucesor = (InternalEObject)sucesor;
			sucesor = (Tarea)eResolveProxy(oldSucesor);
			if (sucesor != oldSucesor) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MyBPMSPackage.TAREA__SUCESOR, oldSucesor, sucesor));
			}
		}
		return sucesor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tarea basicGetSucesor() {
		return sucesor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSucesor(Tarea newSucesor, NotificationChain msgs) {
		Tarea oldSucesor = sucesor;
		sucesor = newSucesor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, MyBPMSPackage.TAREA__SUCESOR, oldSucesor, newSucesor);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSucesor(Tarea newSucesor) {
		if (newSucesor != sucesor) {
			NotificationChain msgs = null;
			if (sucesor != null)
				msgs = ((InternalEObject)sucesor).eInverseRemove(this, MyBPMSPackage.TAREA__PREDECESOR, Tarea.class, msgs);
			if (newSucesor != null)
				msgs = ((InternalEObject)newSucesor).eInverseAdd(this, MyBPMSPackage.TAREA__PREDECESOR, Tarea.class, msgs);
			msgs = basicSetSucesor(newSucesor, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.TAREA__SUCESOR, newSucesor, newSucesor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case MyBPMSPackage.TAREA__PREDECESOR:
				if (predecesor != null)
					msgs = ((InternalEObject)predecesor).eInverseRemove(this, MyBPMSPackage.TAREA__SUCESOR, Tarea.class, msgs);
				return basicSetPredecesor((Tarea)otherEnd, msgs);
			case MyBPMSPackage.TAREA__SUCESOR:
				if (sucesor != null)
					msgs = ((InternalEObject)sucesor).eInverseRemove(this, MyBPMSPackage.TAREA__PREDECESOR, Tarea.class, msgs);
				return basicSetSucesor((Tarea)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case MyBPMSPackage.TAREA__PREDECESOR:
				return basicSetPredecesor(null, msgs);
			case MyBPMSPackage.TAREA__SUCESOR:
				return basicSetSucesor(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MyBPMSPackage.TAREA__PREDECESOR:
				if (resolve) return getPredecesor();
				return basicGetPredecesor();
			case MyBPMSPackage.TAREA__SUCESOR:
				if (resolve) return getSucesor();
				return basicGetSucesor();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MyBPMSPackage.TAREA__PREDECESOR:
				setPredecesor((Tarea)newValue);
				return;
			case MyBPMSPackage.TAREA__SUCESOR:
				setSucesor((Tarea)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.TAREA__PREDECESOR:
				setPredecesor((Tarea)null);
				return;
			case MyBPMSPackage.TAREA__SUCESOR:
				setSucesor((Tarea)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.TAREA__PREDECESOR:
				return predecesor != null;
			case MyBPMSPackage.TAREA__SUCESOR:
				return sucesor != null;
		}
		return super.eIsSet(featureID);
	}

} //TareaImpl

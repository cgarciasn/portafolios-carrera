/**
 */
package myBPMS.impl;

import myBPMS.MyBPMSPackage;
import myBPMS.TareaFin;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tarea Fin</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TareaFinImpl extends TareaImpl implements TareaFin {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TareaFinImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyBPMSPackage.Literals.TAREA_FIN;
	}

} //TareaFinImpl

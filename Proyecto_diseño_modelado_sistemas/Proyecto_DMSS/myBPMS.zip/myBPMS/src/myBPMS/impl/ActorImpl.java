/**
 */
package myBPMS.impl;

import java.util.Collection;

import myBPMS.Actor;
import myBPMS.Fichero;
import myBPMS.MyBPMSPackage;
import myBPMS.Tarea;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Actor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.impl.ActorImpl#getId_actor <em>Id actor</em>}</li>
 *   <li>{@link myBPMS.impl.ActorImpl#getNum_tareas <em>Num tareas</em>}</li>
 *   <li>{@link myBPMS.impl.ActorImpl#getTareas <em>Tareas</em>}</li>
 *   <li>{@link myBPMS.impl.ActorImpl#getFicheros <em>Ficheros</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ActorImpl extends EObjectImpl implements Actor {
	/**
	 * The default value of the '{@link #getId_actor() <em>Id actor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId_actor()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_ACTOR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getId_actor() <em>Id actor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId_actor()
	 * @generated
	 * @ordered
	 */
	protected String id_actor = ID_ACTOR_EDEFAULT;

	/**
	 * The cached setting delegate for the '{@link #getNum_tareas() <em>Num tareas</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNum_tareas()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate NUM_TAREAS__ESETTING_DELEGATE = ((EStructuralFeature.Internal)MyBPMSPackage.Literals.ACTOR__NUM_TAREAS).getSettingDelegate();

	/**
	 * The cached value of the '{@link #getTareas() <em>Tareas</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTareas()
	 * @generated
	 * @ordered
	 */
	protected EList<Tarea> tareas;

	/**
	 * The cached value of the '{@link #getFicheros() <em>Ficheros</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFicheros()
	 * @generated
	 * @ordered
	 */
	protected EList<Fichero> ficheros;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ActorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyBPMSPackage.Literals.ACTOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getId_actor() {
		return id_actor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId_actor(String newId_actor) {
		String oldId_actor = id_actor;
		id_actor = newId_actor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.ACTOR__ID_ACTOR, oldId_actor, id_actor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNum_tareas() {
		return (Integer)NUM_TAREAS__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNum_tareas(int newNum_tareas) {
		NUM_TAREAS__ESETTING_DELEGATE.dynamicSet(this, null, 0, newNum_tareas);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Tarea> getTareas() {
		if (tareas == null) {
			tareas = new EObjectContainmentEList<Tarea>(Tarea.class, this, MyBPMSPackage.ACTOR__TAREAS);
		}
		return tareas;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Fichero> getFicheros() {
		if (ficheros == null) {
			ficheros = new EObjectContainmentEList<Fichero>(Fichero.class, this, MyBPMSPackage.ACTOR__FICHEROS);
		}
		return ficheros;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case MyBPMSPackage.ACTOR__TAREAS:
				return ((InternalEList<?>)getTareas()).basicRemove(otherEnd, msgs);
			case MyBPMSPackage.ACTOR__FICHEROS:
				return ((InternalEList<?>)getFicheros()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MyBPMSPackage.ACTOR__ID_ACTOR:
				return getId_actor();
			case MyBPMSPackage.ACTOR__NUM_TAREAS:
				return getNum_tareas();
			case MyBPMSPackage.ACTOR__TAREAS:
				return getTareas();
			case MyBPMSPackage.ACTOR__FICHEROS:
				return getFicheros();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MyBPMSPackage.ACTOR__ID_ACTOR:
				setId_actor((String)newValue);
				return;
			case MyBPMSPackage.ACTOR__NUM_TAREAS:
				setNum_tareas((Integer)newValue);
				return;
			case MyBPMSPackage.ACTOR__TAREAS:
				getTareas().clear();
				getTareas().addAll((Collection<? extends Tarea>)newValue);
				return;
			case MyBPMSPackage.ACTOR__FICHEROS:
				getFicheros().clear();
				getFicheros().addAll((Collection<? extends Fichero>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.ACTOR__ID_ACTOR:
				setId_actor(ID_ACTOR_EDEFAULT);
				return;
			case MyBPMSPackage.ACTOR__NUM_TAREAS:
				NUM_TAREAS__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
				return;
			case MyBPMSPackage.ACTOR__TAREAS:
				getTareas().clear();
				return;
			case MyBPMSPackage.ACTOR__FICHEROS:
				getFicheros().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.ACTOR__ID_ACTOR:
				return ID_ACTOR_EDEFAULT == null ? id_actor != null : !ID_ACTOR_EDEFAULT.equals(id_actor);
			case MyBPMSPackage.ACTOR__NUM_TAREAS:
				return NUM_TAREAS__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
			case MyBPMSPackage.ACTOR__TAREAS:
				return tareas != null && !tareas.isEmpty();
			case MyBPMSPackage.ACTOR__FICHEROS:
				return ficheros != null && !ficheros.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (id_actor: ");
		result.append(id_actor);
		result.append(')');
		return result.toString();
	}

} //ActorImpl

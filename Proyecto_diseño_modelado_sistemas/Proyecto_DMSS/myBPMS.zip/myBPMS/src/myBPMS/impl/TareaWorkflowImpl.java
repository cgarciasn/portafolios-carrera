/**
 */
package myBPMS.impl;

import myBPMS.MyBPMSPackage;
import myBPMS.TareaWorkflow;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tarea Workflow</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.impl.TareaWorkflowImpl#getId_tareaworkflow <em>Id tareaworkflow</em>}</li>
 *   <li>{@link myBPMS.impl.TareaWorkflowImpl#getNombre_tarea <em>Nombre tarea</em>}</li>
 *   <li>{@link myBPMS.impl.TareaWorkflowImpl#getDescripcion <em>Descripcion</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class TareaWorkflowImpl extends TareaImpl implements TareaWorkflow {
	/**
	 * The default value of the '{@link #getId_tareaworkflow() <em>Id tareaworkflow</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId_tareaworkflow()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_TAREAWORKFLOW_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getId_tareaworkflow() <em>Id tareaworkflow</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId_tareaworkflow()
	 * @generated
	 * @ordered
	 */
	protected String id_tareaworkflow = ID_TAREAWORKFLOW_EDEFAULT;

	/**
	 * The default value of the '{@link #getNombre_tarea() <em>Nombre tarea</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNombre_tarea()
	 * @generated
	 * @ordered
	 */
	protected static final String NOMBRE_TAREA_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNombre_tarea() <em>Nombre tarea</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNombre_tarea()
	 * @generated
	 * @ordered
	 */
	protected String nombre_tarea = NOMBRE_TAREA_EDEFAULT;

	/**
	 * The default value of the '{@link #getDescripcion() <em>Descripcion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescripcion()
	 * @generated
	 * @ordered
	 */
	protected static final String DESCRIPCION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescripcion() <em>Descripcion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescripcion()
	 * @generated
	 * @ordered
	 */
	protected String descripcion = DESCRIPCION_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TareaWorkflowImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyBPMSPackage.Literals.TAREA_WORKFLOW;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getId_tareaworkflow() {
		return id_tareaworkflow;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId_tareaworkflow(String newId_tareaworkflow) {
		String oldId_tareaworkflow = id_tareaworkflow;
		id_tareaworkflow = newId_tareaworkflow;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.TAREA_WORKFLOW__ID_TAREAWORKFLOW, oldId_tareaworkflow, id_tareaworkflow));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNombre_tarea() {
		return nombre_tarea;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNombre_tarea(String newNombre_tarea) {
		String oldNombre_tarea = nombre_tarea;
		nombre_tarea = newNombre_tarea;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.TAREA_WORKFLOW__NOMBRE_TAREA, oldNombre_tarea, nombre_tarea));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDescripcion(String newDescripcion) {
		String oldDescripcion = descripcion;
		descripcion = newDescripcion;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.TAREA_WORKFLOW__DESCRIPCION, oldDescripcion, descripcion));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_WORKFLOW__ID_TAREAWORKFLOW:
				return getId_tareaworkflow();
			case MyBPMSPackage.TAREA_WORKFLOW__NOMBRE_TAREA:
				return getNombre_tarea();
			case MyBPMSPackage.TAREA_WORKFLOW__DESCRIPCION:
				return getDescripcion();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_WORKFLOW__ID_TAREAWORKFLOW:
				setId_tareaworkflow((String)newValue);
				return;
			case MyBPMSPackage.TAREA_WORKFLOW__NOMBRE_TAREA:
				setNombre_tarea((String)newValue);
				return;
			case MyBPMSPackage.TAREA_WORKFLOW__DESCRIPCION:
				setDescripcion((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_WORKFLOW__ID_TAREAWORKFLOW:
				setId_tareaworkflow(ID_TAREAWORKFLOW_EDEFAULT);
				return;
			case MyBPMSPackage.TAREA_WORKFLOW__NOMBRE_TAREA:
				setNombre_tarea(NOMBRE_TAREA_EDEFAULT);
				return;
			case MyBPMSPackage.TAREA_WORKFLOW__DESCRIPCION:
				setDescripcion(DESCRIPCION_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_WORKFLOW__ID_TAREAWORKFLOW:
				return ID_TAREAWORKFLOW_EDEFAULT == null ? id_tareaworkflow != null : !ID_TAREAWORKFLOW_EDEFAULT.equals(id_tareaworkflow);
			case MyBPMSPackage.TAREA_WORKFLOW__NOMBRE_TAREA:
				return NOMBRE_TAREA_EDEFAULT == null ? nombre_tarea != null : !NOMBRE_TAREA_EDEFAULT.equals(nombre_tarea);
			case MyBPMSPackage.TAREA_WORKFLOW__DESCRIPCION:
				return DESCRIPCION_EDEFAULT == null ? descripcion != null : !DESCRIPCION_EDEFAULT.equals(descripcion);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (id_tareaworkflow: ");
		result.append(id_tareaworkflow);
		result.append(", nombre_tarea: ");
		result.append(nombre_tarea);
		result.append(", descripcion: ");
		result.append(descripcion);
		result.append(')');
		return result.toString();
	}

} //TareaWorkflowImpl

/**
 */
package myBPMS.impl;

import java.util.Collection;

import myBPMS.Fichero;
import myBPMS.MyBPMSPackage;
import myBPMS.Tabla;
import myBPMS.TareaEnvioMsj;
import myBPMS.Tipo_codificacion;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tarea Envio Msj</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.impl.TareaEnvioMsjImpl#getEnvio_msj <em>Envio msj</em>}</li>
 *   <li>{@link myBPMS.impl.TareaEnvioMsjImpl#getCodificacion <em>Codificacion</em>}</li>
 *   <li>{@link myBPMS.impl.TareaEnvioMsjImpl#getAdjunta <em>Adjunta</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TareaEnvioMsjImpl extends TareaWorkflowImpl implements TareaEnvioMsj {
	/**
	 * The cached value of the '{@link #getEnvio_msj() <em>Envio msj</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnvio_msj()
	 * @generated
	 * @ordered
	 */
	protected EList<Tabla> envio_msj;

	/**
	 * The default value of the '{@link #getCodificacion() <em>Codificacion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCodificacion()
	 * @generated
	 * @ordered
	 */
	protected static final Tipo_codificacion CODIFICACION_EDEFAULT = Tipo_codificacion.JSON;

	/**
	 * The cached value of the '{@link #getCodificacion() <em>Codificacion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCodificacion()
	 * @generated
	 * @ordered
	 */
	protected Tipo_codificacion codificacion = CODIFICACION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAdjunta() <em>Adjunta</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAdjunta()
	 * @generated
	 * @ordered
	 */
	protected EList<Fichero> adjunta;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TareaEnvioMsjImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyBPMSPackage.Literals.TAREA_ENVIO_MSJ;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Tabla> getEnvio_msj() {
		if (envio_msj == null) {
			envio_msj = new EObjectResolvingEList<Tabla>(Tabla.class, this, MyBPMSPackage.TAREA_ENVIO_MSJ__ENVIO_MSJ);
		}
		return envio_msj;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tipo_codificacion getCodificacion() {
		return codificacion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCodificacion(Tipo_codificacion newCodificacion) {
		Tipo_codificacion oldCodificacion = codificacion;
		codificacion = newCodificacion == null ? CODIFICACION_EDEFAULT : newCodificacion;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.TAREA_ENVIO_MSJ__CODIFICACION, oldCodificacion, codificacion));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Fichero> getAdjunta() {
		if (adjunta == null) {
			adjunta = new EObjectResolvingEList<Fichero>(Fichero.class, this, MyBPMSPackage.TAREA_ENVIO_MSJ__ADJUNTA);
		}
		return adjunta;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_ENVIO_MSJ__ENVIO_MSJ:
				return getEnvio_msj();
			case MyBPMSPackage.TAREA_ENVIO_MSJ__CODIFICACION:
				return getCodificacion();
			case MyBPMSPackage.TAREA_ENVIO_MSJ__ADJUNTA:
				return getAdjunta();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_ENVIO_MSJ__ENVIO_MSJ:
				getEnvio_msj().clear();
				getEnvio_msj().addAll((Collection<? extends Tabla>)newValue);
				return;
			case MyBPMSPackage.TAREA_ENVIO_MSJ__CODIFICACION:
				setCodificacion((Tipo_codificacion)newValue);
				return;
			case MyBPMSPackage.TAREA_ENVIO_MSJ__ADJUNTA:
				getAdjunta().clear();
				getAdjunta().addAll((Collection<? extends Fichero>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_ENVIO_MSJ__ENVIO_MSJ:
				getEnvio_msj().clear();
				return;
			case MyBPMSPackage.TAREA_ENVIO_MSJ__CODIFICACION:
				setCodificacion(CODIFICACION_EDEFAULT);
				return;
			case MyBPMSPackage.TAREA_ENVIO_MSJ__ADJUNTA:
				getAdjunta().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_ENVIO_MSJ__ENVIO_MSJ:
				return envio_msj != null && !envio_msj.isEmpty();
			case MyBPMSPackage.TAREA_ENVIO_MSJ__CODIFICACION:
				return codificacion != CODIFICACION_EDEFAULT;
			case MyBPMSPackage.TAREA_ENVIO_MSJ__ADJUNTA:
				return adjunta != null && !adjunta.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (codificacion: ");
		result.append(codificacion);
		result.append(')');
		return result.toString();
	}

} //TareaEnvioMsjImpl

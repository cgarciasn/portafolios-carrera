/**
 */
package myBPMS.impl;

import myBPMS.Actor;
import myBPMS.Atributo;
import myBPMS.BaseDeDatos;
import myBPMS.Fichero;
import myBPMS.MyBPMSFactory;
import myBPMS.MyBPMSPackage;
import myBPMS.ProcesoDeNegocio;
import myBPMS.Tabla;
import myBPMS.Tarea;
import myBPMS.TareaBorrado;
import myBPMS.TareaConsulta;
import myBPMS.TareaEnvioMsj;
import myBPMS.TareaFin;
import myBPMS.TareaInicio;
import myBPMS.TareaRecepMsj;
import myBPMS.TareaServicio;
import myBPMS.TareaUsuario;
import myBPMS.TareaWorkflow;
import myBPMS.Tipo_atributo;
import myBPMS.Tipo_codificacion;

import myBPMS.util.MyBPMSValidator;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class MyBPMSPackageImpl extends EPackageImpl implements MyBPMSPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass procesoDeNegocioEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass actorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tareaInicioEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tareaFinEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tareaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tareaUsuarioEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tareaServicioEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tareaEnvioMsjEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tareaRecepMsjEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tareaConsultaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tareaBorradoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass baseDeDatosEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tablaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass atributoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tareaWorkflowEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ficheroEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum tipo_atributoEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum tipo_codificacionEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see myBPMS.MyBPMSPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private MyBPMSPackageImpl() {
		super(eNS_URI, MyBPMSFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link MyBPMSPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static MyBPMSPackage init() {
		if (isInited) return (MyBPMSPackage)EPackage.Registry.INSTANCE.getEPackage(MyBPMSPackage.eNS_URI);

		// Obtain or create and register package
		MyBPMSPackageImpl theMyBPMSPackage = (MyBPMSPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof MyBPMSPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new MyBPMSPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theMyBPMSPackage.createPackageContents();

		// Initialize created meta-data
		theMyBPMSPackage.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put
			(theMyBPMSPackage, 
			 new EValidator.Descriptor() {
				 public EValidator getEValidator() {
					 return MyBPMSValidator.INSTANCE;
				 }
			 });

		// Mark meta-data to indicate it can't be changed
		theMyBPMSPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(MyBPMSPackage.eNS_URI, theMyBPMSPackage);
		return theMyBPMSPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getProcesoDeNegocio() {
		return procesoDeNegocioEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProcesoDeNegocio_Actores() {
		return (EReference)procesoDeNegocioEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProcesoDeNegocio_Id_proceso() {
		return (EAttribute)procesoDeNegocioEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProcesoDeNegocio_Basesdedatos() {
		return (EReference)procesoDeNegocioEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getActor() {
		return actorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getActor_Id_actor() {
		return (EAttribute)actorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getActor_Num_tareas() {
		return (EAttribute)actorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getActor_Tareas() {
		return (EReference)actorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getActor_Ficheros() {
		return (EReference)actorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTareaInicio() {
		return tareaInicioEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTareaFin() {
		return tareaFinEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTarea() {
		return tareaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTarea_Predecesor() {
		return (EReference)tareaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTarea_Sucesor() {
		return (EReference)tareaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTareaUsuario() {
		return tareaUsuarioEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTareaUsuario_Formularios() {
		return (EReference)tareaUsuarioEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTareaServicio() {
		return tareaServicioEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTareaServicio_Servicio() {
		return (EReference)tareaServicioEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTareaServicio_Usa() {
		return (EReference)tareaServicioEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTareaServicio_Genera() {
		return (EReference)tareaServicioEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTareaEnvioMsj() {
		return tareaEnvioMsjEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTareaEnvioMsj_Envio_msj() {
		return (EReference)tareaEnvioMsjEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTareaEnvioMsj_Codificacion() {
		return (EAttribute)tareaEnvioMsjEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTareaEnvioMsj_Adjunta() {
		return (EReference)tareaEnvioMsjEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTareaRecepMsj() {
		return tareaRecepMsjEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTareaRecepMsj_Recepcion_msj() {
		return (EReference)tareaRecepMsjEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTareaRecepMsj_Codificacion() {
		return (EAttribute)tareaRecepMsjEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTareaConsulta() {
		return tareaConsultaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTareaConsulta_Consultar_atributo() {
		return (EReference)tareaConsultaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTareaBorrado() {
		return tareaBorradoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTareaBorrado_Borrar_atributo() {
		return (EReference)tareaBorradoEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBaseDeDatos() {
		return baseDeDatosEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBaseDeDatos_Tablas() {
		return (EReference)baseDeDatosEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBaseDeDatos_Id_basedatos() {
		return (EAttribute)baseDeDatosEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTabla() {
		return tablaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTabla_Atributos() {
		return (EReference)tablaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTabla_Id_tabla() {
		return (EAttribute)tablaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAtributo() {
		return atributoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAtributo_Id_atributo() {
		return (EAttribute)atributoEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAtributo_Tipo_atributo() {
		return (EAttribute)atributoEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAtributo_Clave_ajena() {
		return (EReference)atributoEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAtributo_Visible() {
		return (EAttribute)atributoEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAtributo_Clave_primaria() {
		return (EReference)atributoEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTareaWorkflow() {
		return tareaWorkflowEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTareaWorkflow_Id_tareaworkflow() {
		return (EAttribute)tareaWorkflowEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTareaWorkflow_Nombre_tarea() {
		return (EAttribute)tareaWorkflowEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTareaWorkflow_Descripcion() {
		return (EAttribute)tareaWorkflowEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFichero() {
		return ficheroEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFichero_Id_fichero() {
		return (EAttribute)ficheroEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTipo_atributo() {
		return tipo_atributoEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTipo_codificacion() {
		return tipo_codificacionEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MyBPMSFactory getMyBPMSFactory() {
		return (MyBPMSFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		procesoDeNegocioEClass = createEClass(PROCESO_DE_NEGOCIO);
		createEReference(procesoDeNegocioEClass, PROCESO_DE_NEGOCIO__ACTORES);
		createEAttribute(procesoDeNegocioEClass, PROCESO_DE_NEGOCIO__ID_PROCESO);
		createEReference(procesoDeNegocioEClass, PROCESO_DE_NEGOCIO__BASESDEDATOS);

		actorEClass = createEClass(ACTOR);
		createEAttribute(actorEClass, ACTOR__ID_ACTOR);
		createEAttribute(actorEClass, ACTOR__NUM_TAREAS);
		createEReference(actorEClass, ACTOR__TAREAS);
		createEReference(actorEClass, ACTOR__FICHEROS);

		tareaInicioEClass = createEClass(TAREA_INICIO);

		tareaFinEClass = createEClass(TAREA_FIN);

		tareaEClass = createEClass(TAREA);
		createEReference(tareaEClass, TAREA__PREDECESOR);
		createEReference(tareaEClass, TAREA__SUCESOR);

		tareaUsuarioEClass = createEClass(TAREA_USUARIO);
		createEReference(tareaUsuarioEClass, TAREA_USUARIO__FORMULARIOS);

		tareaServicioEClass = createEClass(TAREA_SERVICIO);
		createEReference(tareaServicioEClass, TAREA_SERVICIO__SERVICIO);
		createEReference(tareaServicioEClass, TAREA_SERVICIO__USA);
		createEReference(tareaServicioEClass, TAREA_SERVICIO__GENERA);

		tareaEnvioMsjEClass = createEClass(TAREA_ENVIO_MSJ);
		createEReference(tareaEnvioMsjEClass, TAREA_ENVIO_MSJ__ENVIO_MSJ);
		createEAttribute(tareaEnvioMsjEClass, TAREA_ENVIO_MSJ__CODIFICACION);
		createEReference(tareaEnvioMsjEClass, TAREA_ENVIO_MSJ__ADJUNTA);

		tareaRecepMsjEClass = createEClass(TAREA_RECEP_MSJ);
		createEReference(tareaRecepMsjEClass, TAREA_RECEP_MSJ__RECEPCION_MSJ);
		createEAttribute(tareaRecepMsjEClass, TAREA_RECEP_MSJ__CODIFICACION);

		tareaConsultaEClass = createEClass(TAREA_CONSULTA);
		createEReference(tareaConsultaEClass, TAREA_CONSULTA__CONSULTAR_ATRIBUTO);

		tareaBorradoEClass = createEClass(TAREA_BORRADO);
		createEReference(tareaBorradoEClass, TAREA_BORRADO__BORRAR_ATRIBUTO);

		baseDeDatosEClass = createEClass(BASE_DE_DATOS);
		createEReference(baseDeDatosEClass, BASE_DE_DATOS__TABLAS);
		createEAttribute(baseDeDatosEClass, BASE_DE_DATOS__ID_BASEDATOS);

		tablaEClass = createEClass(TABLA);
		createEReference(tablaEClass, TABLA__ATRIBUTOS);
		createEAttribute(tablaEClass, TABLA__ID_TABLA);

		atributoEClass = createEClass(ATRIBUTO);
		createEAttribute(atributoEClass, ATRIBUTO__ID_ATRIBUTO);
		createEAttribute(atributoEClass, ATRIBUTO__TIPO_ATRIBUTO);
		createEReference(atributoEClass, ATRIBUTO__CLAVE_AJENA);
		createEAttribute(atributoEClass, ATRIBUTO__VISIBLE);
		createEReference(atributoEClass, ATRIBUTO__CLAVE_PRIMARIA);

		tareaWorkflowEClass = createEClass(TAREA_WORKFLOW);
		createEAttribute(tareaWorkflowEClass, TAREA_WORKFLOW__ID_TAREAWORKFLOW);
		createEAttribute(tareaWorkflowEClass, TAREA_WORKFLOW__NOMBRE_TAREA);
		createEAttribute(tareaWorkflowEClass, TAREA_WORKFLOW__DESCRIPCION);

		ficheroEClass = createEClass(FICHERO);
		createEAttribute(ficheroEClass, FICHERO__ID_FICHERO);

		// Create enums
		tipo_atributoEEnum = createEEnum(TIPO_ATRIBUTO);
		tipo_codificacionEEnum = createEEnum(TIPO_CODIFICACION);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		tareaInicioEClass.getESuperTypes().add(this.getTarea());
		tareaFinEClass.getESuperTypes().add(this.getTarea());
		tareaUsuarioEClass.getESuperTypes().add(this.getTareaWorkflow());
		tareaServicioEClass.getESuperTypes().add(this.getTareaWorkflow());
		tareaEnvioMsjEClass.getESuperTypes().add(this.getTareaWorkflow());
		tareaRecepMsjEClass.getESuperTypes().add(this.getTareaWorkflow());
		tareaConsultaEClass.getESuperTypes().add(this.getTareaWorkflow());
		tareaBorradoEClass.getESuperTypes().add(this.getTareaWorkflow());
		tareaWorkflowEClass.getESuperTypes().add(this.getTarea());

		// Initialize classes and features; add operations and parameters
		initEClass(procesoDeNegocioEClass, ProcesoDeNegocio.class, "ProcesoDeNegocio", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getProcesoDeNegocio_Actores(), this.getActor(), null, "actores", null, 1, -1, ProcesoDeNegocio.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getProcesoDeNegocio_Id_proceso(), ecorePackage.getEString(), "id_proceso", null, 1, 1, ProcesoDeNegocio.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getProcesoDeNegocio_Basesdedatos(), this.getBaseDeDatos(), null, "basesdedatos", null, 1, -1, ProcesoDeNegocio.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(actorEClass, Actor.class, "Actor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getActor_Id_actor(), ecorePackage.getEString(), "id_actor", null, 1, 1, Actor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getActor_Num_tareas(), ecorePackage.getEInt(), "num_tareas", null, 1, 1, Actor.class, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getActor_Tareas(), this.getTarea(), null, "tareas", null, 1, -1, Actor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getActor_Ficheros(), this.getFichero(), null, "ficheros", null, 0, -1, Actor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tareaInicioEClass, TareaInicio.class, "TareaInicio", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(tareaFinEClass, TareaFin.class, "TareaFin", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(tareaEClass, Tarea.class, "Tarea", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTarea_Predecesor(), this.getTarea(), this.getTarea_Sucesor(), "predecesor", null, 0, 1, Tarea.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTarea_Sucesor(), this.getTarea(), this.getTarea_Predecesor(), "sucesor", null, 0, 1, Tarea.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tareaUsuarioEClass, TareaUsuario.class, "TareaUsuario", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTareaUsuario_Formularios(), this.getTabla(), null, "formularios", null, 1, -1, TareaUsuario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tareaServicioEClass, TareaServicio.class, "TareaServicio", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTareaServicio_Servicio(), this.getTabla(), null, "servicio", null, 1, -1, TareaServicio.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTareaServicio_Usa(), this.getFichero(), null, "usa", null, 0, -1, TareaServicio.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTareaServicio_Genera(), this.getFichero(), null, "genera", null, 0, -1, TareaServicio.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tareaEnvioMsjEClass, TareaEnvioMsj.class, "TareaEnvioMsj", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTareaEnvioMsj_Envio_msj(), this.getTabla(), null, "envio_msj", null, 1, -1, TareaEnvioMsj.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTareaEnvioMsj_Codificacion(), this.getTipo_codificacion(), "codificacion", null, 0, 1, TareaEnvioMsj.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTareaEnvioMsj_Adjunta(), this.getFichero(), null, "adjunta", null, 0, -1, TareaEnvioMsj.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tareaRecepMsjEClass, TareaRecepMsj.class, "TareaRecepMsj", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTareaRecepMsj_Recepcion_msj(), this.getTabla(), null, "recepcion_msj", null, 1, -1, TareaRecepMsj.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTareaRecepMsj_Codificacion(), this.getTipo_codificacion(), "codificacion", null, 0, 1, TareaRecepMsj.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tareaConsultaEClass, TareaConsulta.class, "TareaConsulta", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTareaConsulta_Consultar_atributo(), this.getAtributo(), null, "consultar_atributo", null, 1, -1, TareaConsulta.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tareaBorradoEClass, TareaBorrado.class, "TareaBorrado", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTareaBorrado_Borrar_atributo(), this.getAtributo(), null, "borrar_atributo", null, 1, -1, TareaBorrado.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(baseDeDatosEClass, BaseDeDatos.class, "BaseDeDatos", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBaseDeDatos_Tablas(), this.getTabla(), null, "tablas", null, 1, -1, BaseDeDatos.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getBaseDeDatos_Id_basedatos(), ecorePackage.getEString(), "id_basedatos", null, 1, 1, BaseDeDatos.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tablaEClass, Tabla.class, "Tabla", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTabla_Atributos(), this.getAtributo(), null, "atributos", null, 1, -1, Tabla.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTabla_Id_tabla(), ecorePackage.getEString(), "id_tabla", null, 1, 1, Tabla.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(atributoEClass, Atributo.class, "Atributo", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAtributo_Id_atributo(), ecorePackage.getEString(), "id_atributo", null, 1, 1, Atributo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAtributo_Tipo_atributo(), this.getTipo_atributo(), "tipo_atributo", null, 0, 1, Atributo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAtributo_Clave_ajena(), this.getTabla(), null, "clave_ajena", null, 0, -1, Atributo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAtributo_Visible(), ecorePackage.getEBoolean(), "visible", null, 0, 1, Atributo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAtributo_Clave_primaria(), this.getTabla(), null, "clave_primaria", null, 0, 1, Atributo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tareaWorkflowEClass, TareaWorkflow.class, "TareaWorkflow", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTareaWorkflow_Id_tareaworkflow(), ecorePackage.getEString(), "id_tareaworkflow", null, 1, 1, TareaWorkflow.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTareaWorkflow_Nombre_tarea(), ecorePackage.getEString(), "nombre_tarea", null, 1, 1, TareaWorkflow.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTareaWorkflow_Descripcion(), ecorePackage.getEString(), "descripcion", null, 0, 1, TareaWorkflow.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(ficheroEClass, Fichero.class, "Fichero", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFichero_Id_fichero(), ecorePackage.getEString(), "id_fichero", null, 1, 1, Fichero.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(tipo_atributoEEnum, Tipo_atributo.class, "Tipo_atributo");
		addEEnumLiteral(tipo_atributoEEnum, Tipo_atributo.INT);
		addEEnumLiteral(tipo_atributoEEnum, Tipo_atributo.CHAR);
		addEEnumLiteral(tipo_atributoEEnum, Tipo_atributo.BOOLEAN);
		addEEnumLiteral(tipo_atributoEEnum, Tipo_atributo.RUTA_ARCHIVO);

		initEEnum(tipo_codificacionEEnum, Tipo_codificacion.class, "Tipo_codificacion");
		addEEnumLiteral(tipo_codificacionEEnum, Tipo_codificacion.JSON);
		addEEnumLiteral(tipo_codificacionEEnum, Tipo_codificacion.XML);
		addEEnumLiteral(tipo_codificacionEEnum, Tipo_codificacion.YAML);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/OCL/Import
		createImportAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// gmf
		createGmfAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot
		createPivotAnnotations();
		// gmf.diagram
		createGmf_1Annotations();
		// gmf.compartment
		createGmf_2Annotations();
		// gmf.node
		createGmf_3Annotations();
		// gmf.link
		createGmf_4Annotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/OCL/Import</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createImportAnnotations() {
		String source = "http://www.eclipse.org/OCL/Import";	
		addAnnotation
		  (this, 
		   source, 
		   new String[] {
			 "ecore", "http://www.eclipse.org/emf/2002/Ecore"
		   });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore";	
		addAnnotation
		  (this, 
		   source, 
		   new String[] {
			 "invocationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
			 "settingDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
			 "validationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot"
		   });	
		addAnnotation
		  (procesoDeNegocioEClass, 
		   source, 
		   new String[] {
			 "constraints", "r1 r2"
		   });	
		addAnnotation
		  (actorEClass, 
		   source, 
		   new String[] {
			 "constraints", "r5"
		   });	
		addAnnotation
		  (tareaInicioEClass, 
		   source, 
		   new String[] {
			 "constraints", "r8tas"
		   });	
		addAnnotation
		  (tareaFinEClass, 
		   source, 
		   new String[] {
			 "constraints", "r8tfp"
		   });	
		addAnnotation
		  (tareaEClass, 
		   source, 
		   new String[] {
			 "constraints", "r3 r4 r6a r6b"
		   });	
		addAnnotation
		  (tareaUsuarioEClass, 
		   source, 
		   new String[] {
			 "constraints", "r8tus r8tup"
		   });	
		addAnnotation
		  (tareaServicioEClass, 
		   source, 
		   new String[] {
			 "constraints", "r8tss r8tsp"
		   });	
		addAnnotation
		  (tareaEnvioMsjEClass, 
		   source, 
		   new String[] {
			 "constraints", "r10 r8tes r8tep"
		   });	
		addAnnotation
		  (tareaRecepMsjEClass, 
		   source, 
		   new String[] {
			 "constraints", "r7 r8trs r8trp"
		   });	
		addAnnotation
		  (tareaConsultaEClass, 
		   source, 
		   new String[] {
			 "constraints", "r8tcs r8tcp"
		   });	
		addAnnotation
		  (tareaBorradoEClass, 
		   source, 
		   new String[] {
			 "constraints", "r8tbs r8tbp"
		   });	
		addAnnotation
		  (tareaWorkflowEClass, 
		   source, 
		   new String[] {
			 "constraints", "r9 r9b"
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmfAnnotations() {
		String source = "gmf";	
		addAnnotation
		  (this, 
		   source, 
		   new String[] {
		   });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createPivotAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot";	
		addAnnotation
		  (procesoDeNegocioEClass, 
		   source, 
		   new String[] {
			 "r1", "self.actores.tareas->selectByType(TareaInicio)->size() = 1",
			 "r2", "self.actores.tareas->selectByType(TareaFin)->size() = 1"
		   });	
		addAnnotation
		  (actorEClass, 
		   source, 
		   new String[] {
			 "r5", "self.tareas->selectByKind(TareaWorkflow)->size() >=1"
		   });	
		addAnnotation
		  (getActor_Num_tareas(), 
		   source, 
		   new String[] {
			 "derivation", "self.tareas->size()"
		   });	
		addAnnotation
		  (tareaInicioEClass, 
		   source, 
		   new String[] {
			 "r8tas", "self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor"
		   });	
		addAnnotation
		  (tareaFinEClass, 
		   source, 
		   new String[] {
			 "r8tfp", "self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor"
		   });	
		addAnnotation
		  (tareaEClass, 
		   source, 
		   new String[] {
			 "r3", "self.sucesor->selectByType(TareaInicio)->size() = 0",
			 "r4", "self.predecesor->selectByType(TareaFin)->size() = 0",
			 "r6a", "self.sucesor <> self",
			 "r6b", "self.predecesor <> self"
		   });	
		addAnnotation
		  (tareaUsuarioEClass, 
		   source, 
		   new String[] {
			 "r8tus", "self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor",
			 "r8tup", "self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor"
		   });	
		addAnnotation
		  (tareaServicioEClass, 
		   source, 
		   new String[] {
			 "r8tss", "self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor",
			 "r8tsp", "self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor"
		   });	
		addAnnotation
		  (tareaEnvioMsjEClass, 
		   source, 
		   new String[] {
			 "r10", "self.codificacion = self.sucesor.oclAsType(TareaRecepMsj).codificacion",
			 "r8tes", "self.oclContainer().oclAsType(Actor).id_actor <> self.sucesor.oclContainer().oclAsType(Actor).id_actor",
			 "r8tep", "self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor"
		   });	
		addAnnotation
		  (tareaRecepMsjEClass, 
		   source, 
		   new String[] {
			 "r7", "self.predecesor->selectByKind(TareaEnvioMsj)->size() = 1",
			 "r8trs", "self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor",
			 "r8trp", "self.oclContainer().oclAsType(Actor).id_actor <> self.predecesor.oclContainer().oclAsType(Actor).id_actor"
		   });	
		addAnnotation
		  (tareaConsultaEClass, 
		   source, 
		   new String[] {
			 "r8tcs", "self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor",
			 "r8tcp", "self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor"
		   });	
		addAnnotation
		  (tareaBorradoEClass, 
		   source, 
		   new String[] {
			 "r8tbs", "self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor",
			 "r8tbp", "self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor"
		   });	
		addAnnotation
		  (tareaWorkflowEClass, 
		   source, 
		   new String[] {
			 "r9", "self.sucesor->size() = 1",
			 "r9b", "self.predecesor->size() = 1"
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.diagram</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmf_1Annotations() {
		String source = "gmf.diagram";	
		addAnnotation
		  (procesoDeNegocioEClass, 
		   source, 
		   new String[] {
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.compartment</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmf_2Annotations() {
		String source = "gmf.compartment";	
		addAnnotation
		  (getProcesoDeNegocio_Actores(), 
		   source, 
		   new String[] {
		   });	
		addAnnotation
		  (getProcesoDeNegocio_Basesdedatos(), 
		   source, 
		   new String[] {
		   });	
		addAnnotation
		  (getActor_Tareas(), 
		   source, 
		   new String[] {
		   });	
		addAnnotation
		  (getActor_Ficheros(), 
		   source, 
		   new String[] {
		   });	
		addAnnotation
		  (getBaseDeDatos_Tablas(), 
		   source, 
		   new String[] {
		   });	
		addAnnotation
		  (getTabla_Atributos(), 
		   source, 
		   new String[] {
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.node</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmf_3Annotations() {
		String source = "gmf.node";	
		addAnnotation
		  (actorEClass, 
		   source, 
		   new String[] {
			 "label", "id_actor",
			 "color", "182,44,44",
			 "figure", "rectangle"
		   });	
		addAnnotation
		  (tareaInicioEClass, 
		   source, 
		   new String[] {
			 "label.placement", "none",
			 "color", "44,178,182",
			 "figure", "rectangle"
		   });	
		addAnnotation
		  (tareaFinEClass, 
		   source, 
		   new String[] {
			 "label.placement", "none",
			 "color", "4,255,217",
			 "figure", "rectangle"
		   });	
		addAnnotation
		  (tareaUsuarioEClass, 
		   source, 
		   new String[] {
			 "label", "id_tareaworkflow",
			 "color", "4,46,255",
			 "figure", "rectangle"
		   });	
		addAnnotation
		  (tareaServicioEClass, 
		   source, 
		   new String[] {
			 "label", "id_tareaworkflow",
			 "color", "4,46,255",
			 "figure", "rectangle"
		   });	
		addAnnotation
		  (tareaEnvioMsjEClass, 
		   source, 
		   new String[] {
			 "label", "id_tareaworkflow",
			 "color", "4,46,255",
			 "figure", "rectangle"
		   });	
		addAnnotation
		  (tareaRecepMsjEClass, 
		   source, 
		   new String[] {
			 "label", "id_tareaworkflow",
			 "color", "4,46,255",
			 "figure", "rectangle"
		   });	
		addAnnotation
		  (tareaConsultaEClass, 
		   source, 
		   new String[] {
			 "label", "id_tareaworkflow",
			 "color", "4,46,255",
			 "figure", "rectangle"
		   });	
		addAnnotation
		  (tareaBorradoEClass, 
		   source, 
		   new String[] {
			 "label", "id_tareaworkflow",
			 "color", "4,46,255",
			 "figure", "rectangle"
		   });	
		addAnnotation
		  (baseDeDatosEClass, 
		   source, 
		   new String[] {
			 "label", "id_basedatos",
			 "color", "51,255,252",
			 "figure", "rectangle"
		   });	
		addAnnotation
		  (tablaEClass, 
		   source, 
		   new String[] {
			 "label", "id_tabla",
			 "color", "88,51,255",
			 "figure", "rectangle"
		   });	
		addAnnotation
		  (atributoEClass, 
		   source, 
		   new String[] {
			 "label", "id_atributo",
			 "color", "100,44,182",
			 "figure", "rectangle"
		   });	
		addAnnotation
		  (ficheroEClass, 
		   source, 
		   new String[] {
			 "label", "id_fichero",
			 "color", "172,182,44",
			 "figure", "rectangle"
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.link</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmf_4Annotations() {
		String source = "gmf.link";	
		addAnnotation
		  (getTarea_Sucesor(), 
		   source, 
		   new String[] {
			 "target", "sucesor",
			 "target.decoration", "arrow",
			 "style", "dash"
		   });	
		addAnnotation
		  (getTareaUsuario_Formularios(), 
		   source, 
		   new String[] {
			 "target", "formularios",
			 "target.decoration", "square",
			 "style", "dash"
		   });	
		addAnnotation
		  (getTareaServicio_Servicio(), 
		   source, 
		   new String[] {
			 "target", "servicio",
			 "target.decoration", "rhomb",
			 "style", "solid"
		   });	
		addAnnotation
		  (getTareaServicio_Usa(), 
		   source, 
		   new String[] {
			 "target", "usa",
			 "target.decoration", "arrow",
			 "style", "solid"
		   });	
		addAnnotation
		  (getTareaServicio_Genera(), 
		   source, 
		   new String[] {
			 "target", "genera",
			 "target.decoration", "arrow",
			 "style", "solid"
		   });	
		addAnnotation
		  (getTareaEnvioMsj_Envio_msj(), 
		   source, 
		   new String[] {
			 "target", "envio_msj",
			 "target.decoration", "arrow",
			 "style", "dash"
		   });	
		addAnnotation
		  (getTareaEnvioMsj_Adjunta(), 
		   source, 
		   new String[] {
			 "taget", "adjunta",
			 "target.decoration", "rhomb",
			 "style", "dash"
		   });	
		addAnnotation
		  (getTareaRecepMsj_Recepcion_msj(), 
		   source, 
		   new String[] {
			 "target", "recepcion_msj",
			 "target.decoration", "square",
			 "style", "dash"
		   });	
		addAnnotation
		  (getTareaConsulta_Consultar_atributo(), 
		   source, 
		   new String[] {
			 "target", "consultar_atributo",
			 "target.decoration", "arrow",
			 "style", "solid"
		   });	
		addAnnotation
		  (getTareaBorrado_Borrar_atributo(), 
		   source, 
		   new String[] {
			 "target", "borrar_atributo",
			 "target.decoration", "rhomb",
			 "style", "solid"
		   });	
		addAnnotation
		  (getAtributo_Clave_ajena(), 
		   source, 
		   new String[] {
			 "target", "clave_ajena",
			 "target.decoration", "square",
			 "style", "dash"
		   });	
		addAnnotation
		  (getAtributo_Clave_primaria(), 
		   source, 
		   new String[] {
			 "taget", "clave_primaria",
			 "target.decoration", "arrow",
			 "style", "dash"
		   });
	}

} //MyBPMSPackageImpl

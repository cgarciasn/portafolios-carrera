/**
 */
package myBPMS.impl;

import myBPMS.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class MyBPMSFactoryImpl extends EFactoryImpl implements MyBPMSFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static MyBPMSFactory init() {
		try {
			MyBPMSFactory theMyBPMSFactory = (MyBPMSFactory)EPackage.Registry.INSTANCE.getEFactory(MyBPMSPackage.eNS_URI);
			if (theMyBPMSFactory != null) {
				return theMyBPMSFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new MyBPMSFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MyBPMSFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case MyBPMSPackage.PROCESO_DE_NEGOCIO: return createProcesoDeNegocio();
			case MyBPMSPackage.ACTOR: return createActor();
			case MyBPMSPackage.TAREA_INICIO: return createTareaInicio();
			case MyBPMSPackage.TAREA_FIN: return createTareaFin();
			case MyBPMSPackage.TAREA_USUARIO: return createTareaUsuario();
			case MyBPMSPackage.TAREA_SERVICIO: return createTareaServicio();
			case MyBPMSPackage.TAREA_ENVIO_MSJ: return createTareaEnvioMsj();
			case MyBPMSPackage.TAREA_RECEP_MSJ: return createTareaRecepMsj();
			case MyBPMSPackage.TAREA_CONSULTA: return createTareaConsulta();
			case MyBPMSPackage.TAREA_BORRADO: return createTareaBorrado();
			case MyBPMSPackage.BASE_DE_DATOS: return createBaseDeDatos();
			case MyBPMSPackage.TABLA: return createTabla();
			case MyBPMSPackage.ATRIBUTO: return createAtributo();
			case MyBPMSPackage.FICHERO: return createFichero();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case MyBPMSPackage.TIPO_ATRIBUTO:
				return createTipo_atributoFromString(eDataType, initialValue);
			case MyBPMSPackage.TIPO_CODIFICACION:
				return createTipo_codificacionFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case MyBPMSPackage.TIPO_ATRIBUTO:
				return convertTipo_atributoToString(eDataType, instanceValue);
			case MyBPMSPackage.TIPO_CODIFICACION:
				return convertTipo_codificacionToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProcesoDeNegocio createProcesoDeNegocio() {
		ProcesoDeNegocioImpl procesoDeNegocio = new ProcesoDeNegocioImpl();
		return procesoDeNegocio;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Actor createActor() {
		ActorImpl actor = new ActorImpl();
		return actor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TareaInicio createTareaInicio() {
		TareaInicioImpl tareaInicio = new TareaInicioImpl();
		return tareaInicio;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TareaFin createTareaFin() {
		TareaFinImpl tareaFin = new TareaFinImpl();
		return tareaFin;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TareaUsuario createTareaUsuario() {
		TareaUsuarioImpl tareaUsuario = new TareaUsuarioImpl();
		return tareaUsuario;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TareaServicio createTareaServicio() {
		TareaServicioImpl tareaServicio = new TareaServicioImpl();
		return tareaServicio;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TareaEnvioMsj createTareaEnvioMsj() {
		TareaEnvioMsjImpl tareaEnvioMsj = new TareaEnvioMsjImpl();
		return tareaEnvioMsj;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TareaRecepMsj createTareaRecepMsj() {
		TareaRecepMsjImpl tareaRecepMsj = new TareaRecepMsjImpl();
		return tareaRecepMsj;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TareaConsulta createTareaConsulta() {
		TareaConsultaImpl tareaConsulta = new TareaConsultaImpl();
		return tareaConsulta;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TareaBorrado createTareaBorrado() {
		TareaBorradoImpl tareaBorrado = new TareaBorradoImpl();
		return tareaBorrado;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BaseDeDatos createBaseDeDatos() {
		BaseDeDatosImpl baseDeDatos = new BaseDeDatosImpl();
		return baseDeDatos;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tabla createTabla() {
		TablaImpl tabla = new TablaImpl();
		return tabla;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Atributo createAtributo() {
		AtributoImpl atributo = new AtributoImpl();
		return atributo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Fichero createFichero() {
		FicheroImpl fichero = new FicheroImpl();
		return fichero;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tipo_atributo createTipo_atributoFromString(EDataType eDataType, String initialValue) {
		Tipo_atributo result = Tipo_atributo.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTipo_atributoToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tipo_codificacion createTipo_codificacionFromString(EDataType eDataType, String initialValue) {
		Tipo_codificacion result = Tipo_codificacion.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTipo_codificacionToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MyBPMSPackage getMyBPMSPackage() {
		return (MyBPMSPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static MyBPMSPackage getPackage() {
		return MyBPMSPackage.eINSTANCE;
	}

} //MyBPMSFactoryImpl

/**
 */
package myBPMS.impl;

import java.util.Collection;

import myBPMS.Atributo;
import myBPMS.MyBPMSPackage;
import myBPMS.TareaBorrado;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tarea Borrado</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.impl.TareaBorradoImpl#getBorrar_atributo <em>Borrar atributo</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TareaBorradoImpl extends TareaWorkflowImpl implements TareaBorrado {
	/**
	 * The cached value of the '{@link #getBorrar_atributo() <em>Borrar atributo</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBorrar_atributo()
	 * @generated
	 * @ordered
	 */
	protected EList<Atributo> borrar_atributo;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TareaBorradoImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyBPMSPackage.Literals.TAREA_BORRADO;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Atributo> getBorrar_atributo() {
		if (borrar_atributo == null) {
			borrar_atributo = new EObjectResolvingEList<Atributo>(Atributo.class, this, MyBPMSPackage.TAREA_BORRADO__BORRAR_ATRIBUTO);
		}
		return borrar_atributo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_BORRADO__BORRAR_ATRIBUTO:
				return getBorrar_atributo();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_BORRADO__BORRAR_ATRIBUTO:
				getBorrar_atributo().clear();
				getBorrar_atributo().addAll((Collection<? extends Atributo>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_BORRADO__BORRAR_ATRIBUTO:
				getBorrar_atributo().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_BORRADO__BORRAR_ATRIBUTO:
				return borrar_atributo != null && !borrar_atributo.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //TareaBorradoImpl

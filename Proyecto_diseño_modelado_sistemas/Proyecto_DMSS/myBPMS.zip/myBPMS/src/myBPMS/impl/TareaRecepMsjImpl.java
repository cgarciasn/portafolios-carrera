/**
 */
package myBPMS.impl;

import java.util.Collection;

import myBPMS.MyBPMSPackage;
import myBPMS.Tabla;
import myBPMS.TareaRecepMsj;
import myBPMS.Tipo_codificacion;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tarea Recep Msj</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.impl.TareaRecepMsjImpl#getRecepcion_msj <em>Recepcion msj</em>}</li>
 *   <li>{@link myBPMS.impl.TareaRecepMsjImpl#getCodificacion <em>Codificacion</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TareaRecepMsjImpl extends TareaWorkflowImpl implements TareaRecepMsj {
	/**
	 * The cached value of the '{@link #getRecepcion_msj() <em>Recepcion msj</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecepcion_msj()
	 * @generated
	 * @ordered
	 */
	protected EList<Tabla> recepcion_msj;

	/**
	 * The default value of the '{@link #getCodificacion() <em>Codificacion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCodificacion()
	 * @generated
	 * @ordered
	 */
	protected static final Tipo_codificacion CODIFICACION_EDEFAULT = Tipo_codificacion.JSON;

	/**
	 * The cached value of the '{@link #getCodificacion() <em>Codificacion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCodificacion()
	 * @generated
	 * @ordered
	 */
	protected Tipo_codificacion codificacion = CODIFICACION_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TareaRecepMsjImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyBPMSPackage.Literals.TAREA_RECEP_MSJ;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Tabla> getRecepcion_msj() {
		if (recepcion_msj == null) {
			recepcion_msj = new EObjectResolvingEList<Tabla>(Tabla.class, this, MyBPMSPackage.TAREA_RECEP_MSJ__RECEPCION_MSJ);
		}
		return recepcion_msj;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tipo_codificacion getCodificacion() {
		return codificacion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCodificacion(Tipo_codificacion newCodificacion) {
		Tipo_codificacion oldCodificacion = codificacion;
		codificacion = newCodificacion == null ? CODIFICACION_EDEFAULT : newCodificacion;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.TAREA_RECEP_MSJ__CODIFICACION, oldCodificacion, codificacion));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_RECEP_MSJ__RECEPCION_MSJ:
				return getRecepcion_msj();
			case MyBPMSPackage.TAREA_RECEP_MSJ__CODIFICACION:
				return getCodificacion();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_RECEP_MSJ__RECEPCION_MSJ:
				getRecepcion_msj().clear();
				getRecepcion_msj().addAll((Collection<? extends Tabla>)newValue);
				return;
			case MyBPMSPackage.TAREA_RECEP_MSJ__CODIFICACION:
				setCodificacion((Tipo_codificacion)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_RECEP_MSJ__RECEPCION_MSJ:
				getRecepcion_msj().clear();
				return;
			case MyBPMSPackage.TAREA_RECEP_MSJ__CODIFICACION:
				setCodificacion(CODIFICACION_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_RECEP_MSJ__RECEPCION_MSJ:
				return recepcion_msj != null && !recepcion_msj.isEmpty();
			case MyBPMSPackage.TAREA_RECEP_MSJ__CODIFICACION:
				return codificacion != CODIFICACION_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (codificacion: ");
		result.append(codificacion);
		result.append(')');
		return result.toString();
	}

} //TareaRecepMsjImpl

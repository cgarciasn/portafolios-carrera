/**
 */
package myBPMS.impl;

import java.util.Collection;

import myBPMS.Actor;
import myBPMS.BaseDeDatos;
import myBPMS.MyBPMSPackage;
import myBPMS.ProcesoDeNegocio;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Proceso De Negocio</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.impl.ProcesoDeNegocioImpl#getActores <em>Actores</em>}</li>
 *   <li>{@link myBPMS.impl.ProcesoDeNegocioImpl#getId_proceso <em>Id proceso</em>}</li>
 *   <li>{@link myBPMS.impl.ProcesoDeNegocioImpl#getBasesdedatos <em>Basesdedatos</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ProcesoDeNegocioImpl extends EObjectImpl implements ProcesoDeNegocio {
	/**
	 * The cached value of the '{@link #getActores() <em>Actores</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActores()
	 * @generated
	 * @ordered
	 */
	protected EList<Actor> actores;

	/**
	 * The default value of the '{@link #getId_proceso() <em>Id proceso</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId_proceso()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_PROCESO_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getId_proceso() <em>Id proceso</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId_proceso()
	 * @generated
	 * @ordered
	 */
	protected String id_proceso = ID_PROCESO_EDEFAULT;

	/**
	 * The cached value of the '{@link #getBasesdedatos() <em>Basesdedatos</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBasesdedatos()
	 * @generated
	 * @ordered
	 */
	protected EList<BaseDeDatos> basesdedatos;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProcesoDeNegocioImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyBPMSPackage.Literals.PROCESO_DE_NEGOCIO;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Actor> getActores() {
		if (actores == null) {
			actores = new EObjectContainmentEList<Actor>(Actor.class, this, MyBPMSPackage.PROCESO_DE_NEGOCIO__ACTORES);
		}
		return actores;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getId_proceso() {
		return id_proceso;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId_proceso(String newId_proceso) {
		String oldId_proceso = id_proceso;
		id_proceso = newId_proceso;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.PROCESO_DE_NEGOCIO__ID_PROCESO, oldId_proceso, id_proceso));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<BaseDeDatos> getBasesdedatos() {
		if (basesdedatos == null) {
			basesdedatos = new EObjectContainmentEList<BaseDeDatos>(BaseDeDatos.class, this, MyBPMSPackage.PROCESO_DE_NEGOCIO__BASESDEDATOS);
		}
		return basesdedatos;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case MyBPMSPackage.PROCESO_DE_NEGOCIO__ACTORES:
				return ((InternalEList<?>)getActores()).basicRemove(otherEnd, msgs);
			case MyBPMSPackage.PROCESO_DE_NEGOCIO__BASESDEDATOS:
				return ((InternalEList<?>)getBasesdedatos()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MyBPMSPackage.PROCESO_DE_NEGOCIO__ACTORES:
				return getActores();
			case MyBPMSPackage.PROCESO_DE_NEGOCIO__ID_PROCESO:
				return getId_proceso();
			case MyBPMSPackage.PROCESO_DE_NEGOCIO__BASESDEDATOS:
				return getBasesdedatos();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MyBPMSPackage.PROCESO_DE_NEGOCIO__ACTORES:
				getActores().clear();
				getActores().addAll((Collection<? extends Actor>)newValue);
				return;
			case MyBPMSPackage.PROCESO_DE_NEGOCIO__ID_PROCESO:
				setId_proceso((String)newValue);
				return;
			case MyBPMSPackage.PROCESO_DE_NEGOCIO__BASESDEDATOS:
				getBasesdedatos().clear();
				getBasesdedatos().addAll((Collection<? extends BaseDeDatos>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.PROCESO_DE_NEGOCIO__ACTORES:
				getActores().clear();
				return;
			case MyBPMSPackage.PROCESO_DE_NEGOCIO__ID_PROCESO:
				setId_proceso(ID_PROCESO_EDEFAULT);
				return;
			case MyBPMSPackage.PROCESO_DE_NEGOCIO__BASESDEDATOS:
				getBasesdedatos().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.PROCESO_DE_NEGOCIO__ACTORES:
				return actores != null && !actores.isEmpty();
			case MyBPMSPackage.PROCESO_DE_NEGOCIO__ID_PROCESO:
				return ID_PROCESO_EDEFAULT == null ? id_proceso != null : !ID_PROCESO_EDEFAULT.equals(id_proceso);
			case MyBPMSPackage.PROCESO_DE_NEGOCIO__BASESDEDATOS:
				return basesdedatos != null && !basesdedatos.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (id_proceso: ");
		result.append(id_proceso);
		result.append(')');
		return result.toString();
	}

} //ProcesoDeNegocioImpl

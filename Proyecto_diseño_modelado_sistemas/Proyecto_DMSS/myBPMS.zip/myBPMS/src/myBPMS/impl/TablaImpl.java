/**
 */
package myBPMS.impl;

import java.util.Collection;

import myBPMS.Atributo;
import myBPMS.MyBPMSPackage;
import myBPMS.Tabla;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tabla</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.impl.TablaImpl#getAtributos <em>Atributos</em>}</li>
 *   <li>{@link myBPMS.impl.TablaImpl#getId_tabla <em>Id tabla</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TablaImpl extends EObjectImpl implements Tabla {
	/**
	 * The cached value of the '{@link #getAtributos() <em>Atributos</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAtributos()
	 * @generated
	 * @ordered
	 */
	protected EList<Atributo> atributos;

	/**
	 * The default value of the '{@link #getId_tabla() <em>Id tabla</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId_tabla()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_TABLA_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getId_tabla() <em>Id tabla</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId_tabla()
	 * @generated
	 * @ordered
	 */
	protected String id_tabla = ID_TABLA_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TablaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyBPMSPackage.Literals.TABLA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Atributo> getAtributos() {
		if (atributos == null) {
			atributos = new EObjectContainmentEList<Atributo>(Atributo.class, this, MyBPMSPackage.TABLA__ATRIBUTOS);
		}
		return atributos;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getId_tabla() {
		return id_tabla;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId_tabla(String newId_tabla) {
		String oldId_tabla = id_tabla;
		id_tabla = newId_tabla;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.TABLA__ID_TABLA, oldId_tabla, id_tabla));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case MyBPMSPackage.TABLA__ATRIBUTOS:
				return ((InternalEList<?>)getAtributos()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MyBPMSPackage.TABLA__ATRIBUTOS:
				return getAtributos();
			case MyBPMSPackage.TABLA__ID_TABLA:
				return getId_tabla();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MyBPMSPackage.TABLA__ATRIBUTOS:
				getAtributos().clear();
				getAtributos().addAll((Collection<? extends Atributo>)newValue);
				return;
			case MyBPMSPackage.TABLA__ID_TABLA:
				setId_tabla((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.TABLA__ATRIBUTOS:
				getAtributos().clear();
				return;
			case MyBPMSPackage.TABLA__ID_TABLA:
				setId_tabla(ID_TABLA_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.TABLA__ATRIBUTOS:
				return atributos != null && !atributos.isEmpty();
			case MyBPMSPackage.TABLA__ID_TABLA:
				return ID_TABLA_EDEFAULT == null ? id_tabla != null : !ID_TABLA_EDEFAULT.equals(id_tabla);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (id_tabla: ");
		result.append(id_tabla);
		result.append(')');
		return result.toString();
	}

} //TablaImpl

/**
 */
package myBPMS.impl;

import java.util.Collection;

import myBPMS.Fichero;
import myBPMS.MyBPMSPackage;
import myBPMS.Tabla;
import myBPMS.TareaServicio;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tarea Servicio</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.impl.TareaServicioImpl#getServicio <em>Servicio</em>}</li>
 *   <li>{@link myBPMS.impl.TareaServicioImpl#getUsa <em>Usa</em>}</li>
 *   <li>{@link myBPMS.impl.TareaServicioImpl#getGenera <em>Genera</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TareaServicioImpl extends TareaWorkflowImpl implements TareaServicio {
	/**
	 * The cached value of the '{@link #getServicio() <em>Servicio</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getServicio()
	 * @generated
	 * @ordered
	 */
	protected EList<Tabla> servicio;

	/**
	 * The cached value of the '{@link #getUsa() <em>Usa</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUsa()
	 * @generated
	 * @ordered
	 */
	protected EList<Fichero> usa;

	/**
	 * The cached value of the '{@link #getGenera() <em>Genera</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGenera()
	 * @generated
	 * @ordered
	 */
	protected EList<Fichero> genera;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TareaServicioImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyBPMSPackage.Literals.TAREA_SERVICIO;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Tabla> getServicio() {
		if (servicio == null) {
			servicio = new EObjectResolvingEList<Tabla>(Tabla.class, this, MyBPMSPackage.TAREA_SERVICIO__SERVICIO);
		}
		return servicio;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Fichero> getUsa() {
		if (usa == null) {
			usa = new EObjectResolvingEList<Fichero>(Fichero.class, this, MyBPMSPackage.TAREA_SERVICIO__USA);
		}
		return usa;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Fichero> getGenera() {
		if (genera == null) {
			genera = new EObjectResolvingEList<Fichero>(Fichero.class, this, MyBPMSPackage.TAREA_SERVICIO__GENERA);
		}
		return genera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_SERVICIO__SERVICIO:
				return getServicio();
			case MyBPMSPackage.TAREA_SERVICIO__USA:
				return getUsa();
			case MyBPMSPackage.TAREA_SERVICIO__GENERA:
				return getGenera();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_SERVICIO__SERVICIO:
				getServicio().clear();
				getServicio().addAll((Collection<? extends Tabla>)newValue);
				return;
			case MyBPMSPackage.TAREA_SERVICIO__USA:
				getUsa().clear();
				getUsa().addAll((Collection<? extends Fichero>)newValue);
				return;
			case MyBPMSPackage.TAREA_SERVICIO__GENERA:
				getGenera().clear();
				getGenera().addAll((Collection<? extends Fichero>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_SERVICIO__SERVICIO:
				getServicio().clear();
				return;
			case MyBPMSPackage.TAREA_SERVICIO__USA:
				getUsa().clear();
				return;
			case MyBPMSPackage.TAREA_SERVICIO__GENERA:
				getGenera().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.TAREA_SERVICIO__SERVICIO:
				return servicio != null && !servicio.isEmpty();
			case MyBPMSPackage.TAREA_SERVICIO__USA:
				return usa != null && !usa.isEmpty();
			case MyBPMSPackage.TAREA_SERVICIO__GENERA:
				return genera != null && !genera.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //TareaServicioImpl

/**
 */
package myBPMS.impl;

import java.util.Collection;

import myBPMS.BaseDeDatos;
import myBPMS.MyBPMSPackage;
import myBPMS.Tabla;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Base De Datos</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.impl.BaseDeDatosImpl#getTablas <em>Tablas</em>}</li>
 *   <li>{@link myBPMS.impl.BaseDeDatosImpl#getId_basedatos <em>Id basedatos</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BaseDeDatosImpl extends EObjectImpl implements BaseDeDatos {
	/**
	 * The cached value of the '{@link #getTablas() <em>Tablas</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTablas()
	 * @generated
	 * @ordered
	 */
	protected EList<Tabla> tablas;

	/**
	 * The default value of the '{@link #getId_basedatos() <em>Id basedatos</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId_basedatos()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_BASEDATOS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getId_basedatos() <em>Id basedatos</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId_basedatos()
	 * @generated
	 * @ordered
	 */
	protected String id_basedatos = ID_BASEDATOS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BaseDeDatosImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyBPMSPackage.Literals.BASE_DE_DATOS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Tabla> getTablas() {
		if (tablas == null) {
			tablas = new EObjectContainmentEList<Tabla>(Tabla.class, this, MyBPMSPackage.BASE_DE_DATOS__TABLAS);
		}
		return tablas;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getId_basedatos() {
		return id_basedatos;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId_basedatos(String newId_basedatos) {
		String oldId_basedatos = id_basedatos;
		id_basedatos = newId_basedatos;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.BASE_DE_DATOS__ID_BASEDATOS, oldId_basedatos, id_basedatos));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case MyBPMSPackage.BASE_DE_DATOS__TABLAS:
				return ((InternalEList<?>)getTablas()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MyBPMSPackage.BASE_DE_DATOS__TABLAS:
				return getTablas();
			case MyBPMSPackage.BASE_DE_DATOS__ID_BASEDATOS:
				return getId_basedatos();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MyBPMSPackage.BASE_DE_DATOS__TABLAS:
				getTablas().clear();
				getTablas().addAll((Collection<? extends Tabla>)newValue);
				return;
			case MyBPMSPackage.BASE_DE_DATOS__ID_BASEDATOS:
				setId_basedatos((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.BASE_DE_DATOS__TABLAS:
				getTablas().clear();
				return;
			case MyBPMSPackage.BASE_DE_DATOS__ID_BASEDATOS:
				setId_basedatos(ID_BASEDATOS_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.BASE_DE_DATOS__TABLAS:
				return tablas != null && !tablas.isEmpty();
			case MyBPMSPackage.BASE_DE_DATOS__ID_BASEDATOS:
				return ID_BASEDATOS_EDEFAULT == null ? id_basedatos != null : !ID_BASEDATOS_EDEFAULT.equals(id_basedatos);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (id_basedatos: ");
		result.append(id_basedatos);
		result.append(')');
		return result.toString();
	}

} //BaseDeDatosImpl

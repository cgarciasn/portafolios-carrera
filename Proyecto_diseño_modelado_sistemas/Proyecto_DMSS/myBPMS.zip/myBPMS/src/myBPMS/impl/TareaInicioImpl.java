/**
 */
package myBPMS.impl;

import myBPMS.MyBPMSPackage;
import myBPMS.TareaInicio;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tarea Inicio</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TareaInicioImpl extends TareaImpl implements TareaInicio {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TareaInicioImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyBPMSPackage.Literals.TAREA_INICIO;
	}

} //TareaInicioImpl

/**
 */
package myBPMS.impl;

import myBPMS.Fichero;
import myBPMS.MyBPMSPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Fichero</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.impl.FicheroImpl#getId_fichero <em>Id fichero</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FicheroImpl extends EObjectImpl implements Fichero {
	/**
	 * The default value of the '{@link #getId_fichero() <em>Id fichero</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId_fichero()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_FICHERO_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getId_fichero() <em>Id fichero</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId_fichero()
	 * @generated
	 * @ordered
	 */
	protected String id_fichero = ID_FICHERO_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FicheroImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyBPMSPackage.Literals.FICHERO;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getId_fichero() {
		return id_fichero;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId_fichero(String newId_fichero) {
		String oldId_fichero = id_fichero;
		id_fichero = newId_fichero;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MyBPMSPackage.FICHERO__ID_FICHERO, oldId_fichero, id_fichero));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MyBPMSPackage.FICHERO__ID_FICHERO:
				return getId_fichero();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MyBPMSPackage.FICHERO__ID_FICHERO:
				setId_fichero((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.FICHERO__ID_FICHERO:
				setId_fichero(ID_FICHERO_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MyBPMSPackage.FICHERO__ID_FICHERO:
				return ID_FICHERO_EDEFAULT == null ? id_fichero != null : !ID_FICHERO_EDEFAULT.equals(id_fichero);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (id_fichero: ");
		result.append(id_fichero);
		result.append(')');
		return result.toString();
	}

} //FicheroImpl

/**
 */
package myBPMS;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tarea Consulta</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.TareaConsulta#getConsultar_atributo <em>Consultar atributo</em>}</li>
 * </ul>
 *
 * @see myBPMS.MyBPMSPackage#getTareaConsulta()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='r8tcs r8tcp'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot r8tcs='self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor' r8tcp='self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor'"
 *        annotation="gmf.node label='id_tareaworkflow' color='4,46,255' figure='rectangle'"
 * @generated
 */
public interface TareaConsulta extends TareaWorkflow {
	/**
	 * Returns the value of the '<em><b>Consultar atributo</b></em>' reference list.
	 * The list contents are of type {@link myBPMS.Atributo}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Consultar atributo</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Consultar atributo</em>' reference list.
	 * @see myBPMS.MyBPMSPackage#getTareaConsulta_Consultar_atributo()
	 * @model required="true"
	 *        annotation="gmf.link target='consultar_atributo' target.decoration='arrow' style='solid'"
	 * @generated
	 */
	EList<Atributo> getConsultar_atributo();

} // TareaConsulta

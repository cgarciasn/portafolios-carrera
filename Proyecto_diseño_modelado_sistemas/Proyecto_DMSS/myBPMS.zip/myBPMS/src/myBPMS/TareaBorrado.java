/**
 */
package myBPMS;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tarea Borrado</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.TareaBorrado#getBorrar_atributo <em>Borrar atributo</em>}</li>
 * </ul>
 *
 * @see myBPMS.MyBPMSPackage#getTareaBorrado()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='r8tbs r8tbp'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot r8tbs='self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor' r8tbp='self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor'"
 *        annotation="gmf.node label='id_tareaworkflow' color='4,46,255' figure='rectangle'"
 * @generated
 */
public interface TareaBorrado extends TareaWorkflow {
	/**
	 * Returns the value of the '<em><b>Borrar atributo</b></em>' reference list.
	 * The list contents are of type {@link myBPMS.Atributo}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Borrar atributo</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Borrar atributo</em>' reference list.
	 * @see myBPMS.MyBPMSPackage#getTareaBorrado_Borrar_atributo()
	 * @model required="true"
	 *        annotation="gmf.link target='borrar_atributo' target.decoration='rhomb' style='solid'"
	 * @generated
	 */
	EList<Atributo> getBorrar_atributo();

} // TareaBorrado

/**
 */
package myBPMS;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Base De Datos</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.BaseDeDatos#getTablas <em>Tablas</em>}</li>
 *   <li>{@link myBPMS.BaseDeDatos#getId_basedatos <em>Id basedatos</em>}</li>
 * </ul>
 *
 * @see myBPMS.MyBPMSPackage#getBaseDeDatos()
 * @model annotation="gmf.node label='id_basedatos' color='51,255,252' figure='rectangle'"
 * @generated
 */
public interface BaseDeDatos extends EObject {
	/**
	 * Returns the value of the '<em><b>Tablas</b></em>' containment reference list.
	 * The list contents are of type {@link myBPMS.Tabla}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tablas</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tablas</em>' containment reference list.
	 * @see myBPMS.MyBPMSPackage#getBaseDeDatos_Tablas()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Tabla> getTablas();

	/**
	 * Returns the value of the '<em><b>Id basedatos</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id basedatos</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id basedatos</em>' attribute.
	 * @see #setId_basedatos(String)
	 * @see myBPMS.MyBPMSPackage#getBaseDeDatos_Id_basedatos()
	 * @model required="true"
	 * @generated
	 */
	String getId_basedatos();

	/**
	 * Sets the value of the '{@link myBPMS.BaseDeDatos#getId_basedatos <em>Id basedatos</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id basedatos</em>' attribute.
	 * @see #getId_basedatos()
	 * @generated
	 */
	void setId_basedatos(String value);

} // BaseDeDatos

/**
 */
package myBPMS;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tarea Usuario</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.TareaUsuario#getFormularios <em>Formularios</em>}</li>
 * </ul>
 *
 * @see myBPMS.MyBPMSPackage#getTareaUsuario()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='r8tus r8tup'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot r8tus='self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor' r8tup='self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor'"
 *        annotation="gmf.node label='id_tareaworkflow' color='4,46,255' figure='rectangle'"
 * @generated
 */
public interface TareaUsuario extends TareaWorkflow {
	/**
	 * Returns the value of the '<em><b>Formularios</b></em>' reference list.
	 * The list contents are of type {@link myBPMS.Tabla}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Formularios</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Formularios</em>' reference list.
	 * @see myBPMS.MyBPMSPackage#getTareaUsuario_Formularios()
	 * @model required="true"
	 *        annotation="gmf.link target='formularios' target.decoration='square' style='dash'"
	 * @generated
	 */
	EList<Tabla> getFormularios();

} // TareaUsuario

/**
 */
package myBPMS;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fichero</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.Fichero#getId_fichero <em>Id fichero</em>}</li>
 * </ul>
 *
 * @see myBPMS.MyBPMSPackage#getFichero()
 * @model annotation="gmf.node label='id_fichero' color='172,182,44' figure='rectangle'"
 * @generated
 */
public interface Fichero extends EObject {
	/**
	 * Returns the value of the '<em><b>Id fichero</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id fichero</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id fichero</em>' attribute.
	 * @see #setId_fichero(String)
	 * @see myBPMS.MyBPMSPackage#getFichero_Id_fichero()
	 * @model required="true"
	 * @generated
	 */
	String getId_fichero();

	/**
	 * Sets the value of the '{@link myBPMS.Fichero#getId_fichero <em>Id fichero</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id fichero</em>' attribute.
	 * @see #getId_fichero()
	 * @generated
	 */
	void setId_fichero(String value);

} // Fichero

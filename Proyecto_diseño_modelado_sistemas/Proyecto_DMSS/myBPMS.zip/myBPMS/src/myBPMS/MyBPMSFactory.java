/**
 */
package myBPMS;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see myBPMS.MyBPMSPackage
 * @generated
 */
public interface MyBPMSFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	MyBPMSFactory eINSTANCE = myBPMS.impl.MyBPMSFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Proceso De Negocio</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Proceso De Negocio</em>'.
	 * @generated
	 */
	ProcesoDeNegocio createProcesoDeNegocio();

	/**
	 * Returns a new object of class '<em>Actor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Actor</em>'.
	 * @generated
	 */
	Actor createActor();

	/**
	 * Returns a new object of class '<em>Tarea Inicio</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tarea Inicio</em>'.
	 * @generated
	 */
	TareaInicio createTareaInicio();

	/**
	 * Returns a new object of class '<em>Tarea Fin</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tarea Fin</em>'.
	 * @generated
	 */
	TareaFin createTareaFin();

	/**
	 * Returns a new object of class '<em>Tarea Usuario</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tarea Usuario</em>'.
	 * @generated
	 */
	TareaUsuario createTareaUsuario();

	/**
	 * Returns a new object of class '<em>Tarea Servicio</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tarea Servicio</em>'.
	 * @generated
	 */
	TareaServicio createTareaServicio();

	/**
	 * Returns a new object of class '<em>Tarea Envio Msj</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tarea Envio Msj</em>'.
	 * @generated
	 */
	TareaEnvioMsj createTareaEnvioMsj();

	/**
	 * Returns a new object of class '<em>Tarea Recep Msj</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tarea Recep Msj</em>'.
	 * @generated
	 */
	TareaRecepMsj createTareaRecepMsj();

	/**
	 * Returns a new object of class '<em>Tarea Consulta</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tarea Consulta</em>'.
	 * @generated
	 */
	TareaConsulta createTareaConsulta();

	/**
	 * Returns a new object of class '<em>Tarea Borrado</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tarea Borrado</em>'.
	 * @generated
	 */
	TareaBorrado createTareaBorrado();

	/**
	 * Returns a new object of class '<em>Base De Datos</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Base De Datos</em>'.
	 * @generated
	 */
	BaseDeDatos createBaseDeDatos();

	/**
	 * Returns a new object of class '<em>Tabla</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tabla</em>'.
	 * @generated
	 */
	Tabla createTabla();

	/**
	 * Returns a new object of class '<em>Atributo</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Atributo</em>'.
	 * @generated
	 */
	Atributo createAtributo();

	/**
	 * Returns a new object of class '<em>Fichero</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fichero</em>'.
	 * @generated
	 */
	Fichero createFichero();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	MyBPMSPackage getMyBPMSPackage();

} //MyBPMSFactory

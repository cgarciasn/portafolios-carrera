/**
 */
package myBPMS.util;

import myBPMS.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see myBPMS.MyBPMSPackage
 * @generated
 */
public class MyBPMSAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static MyBPMSPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MyBPMSAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = MyBPMSPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MyBPMSSwitch<Adapter> modelSwitch =
		new MyBPMSSwitch<Adapter>() {
			@Override
			public Adapter caseProcesoDeNegocio(ProcesoDeNegocio object) {
				return createProcesoDeNegocioAdapter();
			}
			@Override
			public Adapter caseActor(Actor object) {
				return createActorAdapter();
			}
			@Override
			public Adapter caseTareaInicio(TareaInicio object) {
				return createTareaInicioAdapter();
			}
			@Override
			public Adapter caseTareaFin(TareaFin object) {
				return createTareaFinAdapter();
			}
			@Override
			public Adapter caseTarea(Tarea object) {
				return createTareaAdapter();
			}
			@Override
			public Adapter caseTareaUsuario(TareaUsuario object) {
				return createTareaUsuarioAdapter();
			}
			@Override
			public Adapter caseTareaServicio(TareaServicio object) {
				return createTareaServicioAdapter();
			}
			@Override
			public Adapter caseTareaEnvioMsj(TareaEnvioMsj object) {
				return createTareaEnvioMsjAdapter();
			}
			@Override
			public Adapter caseTareaRecepMsj(TareaRecepMsj object) {
				return createTareaRecepMsjAdapter();
			}
			@Override
			public Adapter caseTareaConsulta(TareaConsulta object) {
				return createTareaConsultaAdapter();
			}
			@Override
			public Adapter caseTareaBorrado(TareaBorrado object) {
				return createTareaBorradoAdapter();
			}
			@Override
			public Adapter caseBaseDeDatos(BaseDeDatos object) {
				return createBaseDeDatosAdapter();
			}
			@Override
			public Adapter caseTabla(Tabla object) {
				return createTablaAdapter();
			}
			@Override
			public Adapter caseAtributo(Atributo object) {
				return createAtributoAdapter();
			}
			@Override
			public Adapter caseTareaWorkflow(TareaWorkflow object) {
				return createTareaWorkflowAdapter();
			}
			@Override
			public Adapter caseFichero(Fichero object) {
				return createFicheroAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.ProcesoDeNegocio <em>Proceso De Negocio</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.ProcesoDeNegocio
	 * @generated
	 */
	public Adapter createProcesoDeNegocioAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.Actor <em>Actor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.Actor
	 * @generated
	 */
	public Adapter createActorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.TareaInicio <em>Tarea Inicio</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.TareaInicio
	 * @generated
	 */
	public Adapter createTareaInicioAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.TareaFin <em>Tarea Fin</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.TareaFin
	 * @generated
	 */
	public Adapter createTareaFinAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.Tarea <em>Tarea</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.Tarea
	 * @generated
	 */
	public Adapter createTareaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.TareaUsuario <em>Tarea Usuario</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.TareaUsuario
	 * @generated
	 */
	public Adapter createTareaUsuarioAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.TareaServicio <em>Tarea Servicio</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.TareaServicio
	 * @generated
	 */
	public Adapter createTareaServicioAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.TareaEnvioMsj <em>Tarea Envio Msj</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.TareaEnvioMsj
	 * @generated
	 */
	public Adapter createTareaEnvioMsjAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.TareaRecepMsj <em>Tarea Recep Msj</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.TareaRecepMsj
	 * @generated
	 */
	public Adapter createTareaRecepMsjAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.TareaConsulta <em>Tarea Consulta</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.TareaConsulta
	 * @generated
	 */
	public Adapter createTareaConsultaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.TareaBorrado <em>Tarea Borrado</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.TareaBorrado
	 * @generated
	 */
	public Adapter createTareaBorradoAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.BaseDeDatos <em>Base De Datos</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.BaseDeDatos
	 * @generated
	 */
	public Adapter createBaseDeDatosAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.Tabla <em>Tabla</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.Tabla
	 * @generated
	 */
	public Adapter createTablaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.Atributo <em>Atributo</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.Atributo
	 * @generated
	 */
	public Adapter createAtributoAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.TareaWorkflow <em>Tarea Workflow</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.TareaWorkflow
	 * @generated
	 */
	public Adapter createTareaWorkflowAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link myBPMS.Fichero <em>Fichero</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see myBPMS.Fichero
	 * @generated
	 */
	public Adapter createFicheroAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //MyBPMSAdapterFactory

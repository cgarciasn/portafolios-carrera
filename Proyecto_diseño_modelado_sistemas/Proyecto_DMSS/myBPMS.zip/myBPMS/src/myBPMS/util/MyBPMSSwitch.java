/**
 */
package myBPMS.util;

import myBPMS.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see myBPMS.MyBPMSPackage
 * @generated
 */
public class MyBPMSSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static MyBPMSPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MyBPMSSwitch() {
		if (modelPackage == null) {
			modelPackage = MyBPMSPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case MyBPMSPackage.PROCESO_DE_NEGOCIO: {
				ProcesoDeNegocio procesoDeNegocio = (ProcesoDeNegocio)theEObject;
				T result = caseProcesoDeNegocio(procesoDeNegocio);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MyBPMSPackage.ACTOR: {
				Actor actor = (Actor)theEObject;
				T result = caseActor(actor);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MyBPMSPackage.TAREA_INICIO: {
				TareaInicio tareaInicio = (TareaInicio)theEObject;
				T result = caseTareaInicio(tareaInicio);
				if (result == null) result = caseTarea(tareaInicio);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MyBPMSPackage.TAREA_FIN: {
				TareaFin tareaFin = (TareaFin)theEObject;
				T result = caseTareaFin(tareaFin);
				if (result == null) result = caseTarea(tareaFin);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MyBPMSPackage.TAREA: {
				Tarea tarea = (Tarea)theEObject;
				T result = caseTarea(tarea);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MyBPMSPackage.TAREA_USUARIO: {
				TareaUsuario tareaUsuario = (TareaUsuario)theEObject;
				T result = caseTareaUsuario(tareaUsuario);
				if (result == null) result = caseTareaWorkflow(tareaUsuario);
				if (result == null) result = caseTarea(tareaUsuario);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MyBPMSPackage.TAREA_SERVICIO: {
				TareaServicio tareaServicio = (TareaServicio)theEObject;
				T result = caseTareaServicio(tareaServicio);
				if (result == null) result = caseTareaWorkflow(tareaServicio);
				if (result == null) result = caseTarea(tareaServicio);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MyBPMSPackage.TAREA_ENVIO_MSJ: {
				TareaEnvioMsj tareaEnvioMsj = (TareaEnvioMsj)theEObject;
				T result = caseTareaEnvioMsj(tareaEnvioMsj);
				if (result == null) result = caseTareaWorkflow(tareaEnvioMsj);
				if (result == null) result = caseTarea(tareaEnvioMsj);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MyBPMSPackage.TAREA_RECEP_MSJ: {
				TareaRecepMsj tareaRecepMsj = (TareaRecepMsj)theEObject;
				T result = caseTareaRecepMsj(tareaRecepMsj);
				if (result == null) result = caseTareaWorkflow(tareaRecepMsj);
				if (result == null) result = caseTarea(tareaRecepMsj);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MyBPMSPackage.TAREA_CONSULTA: {
				TareaConsulta tareaConsulta = (TareaConsulta)theEObject;
				T result = caseTareaConsulta(tareaConsulta);
				if (result == null) result = caseTareaWorkflow(tareaConsulta);
				if (result == null) result = caseTarea(tareaConsulta);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MyBPMSPackage.TAREA_BORRADO: {
				TareaBorrado tareaBorrado = (TareaBorrado)theEObject;
				T result = caseTareaBorrado(tareaBorrado);
				if (result == null) result = caseTareaWorkflow(tareaBorrado);
				if (result == null) result = caseTarea(tareaBorrado);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MyBPMSPackage.BASE_DE_DATOS: {
				BaseDeDatos baseDeDatos = (BaseDeDatos)theEObject;
				T result = caseBaseDeDatos(baseDeDatos);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MyBPMSPackage.TABLA: {
				Tabla tabla = (Tabla)theEObject;
				T result = caseTabla(tabla);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MyBPMSPackage.ATRIBUTO: {
				Atributo atributo = (Atributo)theEObject;
				T result = caseAtributo(atributo);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MyBPMSPackage.TAREA_WORKFLOW: {
				TareaWorkflow tareaWorkflow = (TareaWorkflow)theEObject;
				T result = caseTareaWorkflow(tareaWorkflow);
				if (result == null) result = caseTarea(tareaWorkflow);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case MyBPMSPackage.FICHERO: {
				Fichero fichero = (Fichero)theEObject;
				T result = caseFichero(fichero);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Proceso De Negocio</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Proceso De Negocio</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseProcesoDeNegocio(ProcesoDeNegocio object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Actor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Actor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseActor(Actor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tarea Inicio</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tarea Inicio</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTareaInicio(TareaInicio object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tarea Fin</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tarea Fin</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTareaFin(TareaFin object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tarea</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tarea</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTarea(Tarea object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tarea Usuario</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tarea Usuario</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTareaUsuario(TareaUsuario object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tarea Servicio</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tarea Servicio</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTareaServicio(TareaServicio object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tarea Envio Msj</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tarea Envio Msj</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTareaEnvioMsj(TareaEnvioMsj object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tarea Recep Msj</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tarea Recep Msj</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTareaRecepMsj(TareaRecepMsj object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tarea Consulta</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tarea Consulta</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTareaConsulta(TareaConsulta object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tarea Borrado</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tarea Borrado</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTareaBorrado(TareaBorrado object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Base De Datos</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Base De Datos</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBaseDeDatos(BaseDeDatos object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tabla</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tabla</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTabla(Tabla object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Atributo</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Atributo</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAtributo(Atributo object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tarea Workflow</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tarea Workflow</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTareaWorkflow(TareaWorkflow object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Fichero</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Fichero</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFichero(Fichero object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //MyBPMSSwitch

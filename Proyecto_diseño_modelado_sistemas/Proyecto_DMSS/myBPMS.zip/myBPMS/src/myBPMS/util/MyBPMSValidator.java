/**
 */
package myBPMS.util;

import java.util.Map;

import myBPMS.*;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see myBPMS.MyBPMSPackage
 * @generated
 */
public class MyBPMSValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final MyBPMSValidator INSTANCE = new MyBPMSValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "myBPMS";

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MyBPMSValidator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
	  return MyBPMSPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map<Object, Object> context) {
		switch (classifierID) {
			case MyBPMSPackage.PROCESO_DE_NEGOCIO:
				return validateProcesoDeNegocio((ProcesoDeNegocio)value, diagnostics, context);
			case MyBPMSPackage.ACTOR:
				return validateActor((Actor)value, diagnostics, context);
			case MyBPMSPackage.TAREA_INICIO:
				return validateTareaInicio((TareaInicio)value, diagnostics, context);
			case MyBPMSPackage.TAREA_FIN:
				return validateTareaFin((TareaFin)value, diagnostics, context);
			case MyBPMSPackage.TAREA:
				return validateTarea((Tarea)value, diagnostics, context);
			case MyBPMSPackage.TAREA_USUARIO:
				return validateTareaUsuario((TareaUsuario)value, diagnostics, context);
			case MyBPMSPackage.TAREA_SERVICIO:
				return validateTareaServicio((TareaServicio)value, diagnostics, context);
			case MyBPMSPackage.TAREA_ENVIO_MSJ:
				return validateTareaEnvioMsj((TareaEnvioMsj)value, diagnostics, context);
			case MyBPMSPackage.TAREA_RECEP_MSJ:
				return validateTareaRecepMsj((TareaRecepMsj)value, diagnostics, context);
			case MyBPMSPackage.TAREA_CONSULTA:
				return validateTareaConsulta((TareaConsulta)value, diagnostics, context);
			case MyBPMSPackage.TAREA_BORRADO:
				return validateTareaBorrado((TareaBorrado)value, diagnostics, context);
			case MyBPMSPackage.BASE_DE_DATOS:
				return validateBaseDeDatos((BaseDeDatos)value, diagnostics, context);
			case MyBPMSPackage.TABLA:
				return validateTabla((Tabla)value, diagnostics, context);
			case MyBPMSPackage.ATRIBUTO:
				return validateAtributo((Atributo)value, diagnostics, context);
			case MyBPMSPackage.TAREA_WORKFLOW:
				return validateTareaWorkflow((TareaWorkflow)value, diagnostics, context);
			case MyBPMSPackage.FICHERO:
				return validateFichero((Fichero)value, diagnostics, context);
			case MyBPMSPackage.TIPO_ATRIBUTO:
				return validateTipo_atributo((Tipo_atributo)value, diagnostics, context);
			case MyBPMSPackage.TIPO_CODIFICACION:
				return validateTipo_codificacion((Tipo_codificacion)value, diagnostics, context);
			default:
				return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProcesoDeNegocio(ProcesoDeNegocio procesoDeNegocio, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(procesoDeNegocio, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(procesoDeNegocio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(procesoDeNegocio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(procesoDeNegocio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(procesoDeNegocio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(procesoDeNegocio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(procesoDeNegocio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(procesoDeNegocio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(procesoDeNegocio, diagnostics, context);
		if (result || diagnostics != null) result &= validateProcesoDeNegocio_r1(procesoDeNegocio, diagnostics, context);
		if (result || diagnostics != null) result &= validateProcesoDeNegocio_r2(procesoDeNegocio, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the r1 constraint of '<em>Proceso De Negocio</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PROCESO_DE_NEGOCIO__R1__EEXPRESSION = "self.actores.tareas->selectByType(TareaInicio)->size() = 1";

	/**
	 * Validates the r1 constraint of '<em>Proceso De Negocio</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProcesoDeNegocio_r1(ProcesoDeNegocio procesoDeNegocio, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.PROCESO_DE_NEGOCIO,
				 procesoDeNegocio,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r1",
				 PROCESO_DE_NEGOCIO__R1__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the r2 constraint of '<em>Proceso De Negocio</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PROCESO_DE_NEGOCIO__R2__EEXPRESSION = "self.actores.tareas->selectByType(TareaFin)->size() = 1";

	/**
	 * Validates the r2 constraint of '<em>Proceso De Negocio</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProcesoDeNegocio_r2(ProcesoDeNegocio procesoDeNegocio, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.PROCESO_DE_NEGOCIO,
				 procesoDeNegocio,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r2",
				 PROCESO_DE_NEGOCIO__R2__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateActor(Actor actor, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(actor, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(actor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(actor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(actor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(actor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(actor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(actor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(actor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(actor, diagnostics, context);
		if (result || diagnostics != null) result &= validateActor_r5(actor, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the r5 constraint of '<em>Actor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ACTOR__R5__EEXPRESSION = "self.tareas->selectByKind(TareaWorkflow)->size() >=1";

	/**
	 * Validates the r5 constraint of '<em>Actor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateActor_r5(Actor actor, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.ACTOR,
				 actor,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r5",
				 ACTOR__R5__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaInicio(TareaInicio tareaInicio, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(tareaInicio, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(tareaInicio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(tareaInicio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(tareaInicio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(tareaInicio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(tareaInicio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(tareaInicio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(tareaInicio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(tareaInicio, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r3(tareaInicio, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r4(tareaInicio, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6a(tareaInicio, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6b(tareaInicio, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaInicio_r8tas(tareaInicio, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the r8tas constraint of '<em>Tarea Inicio</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_INICIO__R8TAS__EEXPRESSION = "self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor";

	/**
	 * Validates the r8tas constraint of '<em>Tarea Inicio</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaInicio_r8tas(TareaInicio tareaInicio, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_INICIO,
				 tareaInicio,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r8tas",
				 TAREA_INICIO__R8TAS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaFin(TareaFin tareaFin, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(tareaFin, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(tareaFin, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(tareaFin, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(tareaFin, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(tareaFin, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(tareaFin, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(tareaFin, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(tareaFin, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(tareaFin, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r3(tareaFin, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r4(tareaFin, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6a(tareaFin, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6b(tareaFin, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaFin_r8tfp(tareaFin, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the r8tfp constraint of '<em>Tarea Fin</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_FIN__R8TFP__EEXPRESSION = "self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor";

	/**
	 * Validates the r8tfp constraint of '<em>Tarea Fin</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaFin_r8tfp(TareaFin tareaFin, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_FIN,
				 tareaFin,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r8tfp",
				 TAREA_FIN__R8TFP__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTarea(Tarea tarea, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(tarea, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(tarea, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(tarea, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(tarea, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(tarea, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(tarea, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(tarea, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(tarea, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(tarea, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r3(tarea, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r4(tarea, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6a(tarea, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6b(tarea, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the r3 constraint of '<em>Tarea</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA__R3__EEXPRESSION = "self.sucesor->selectByType(TareaInicio)->size() = 0";

	/**
	 * Validates the r3 constraint of '<em>Tarea</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTarea_r3(Tarea tarea, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA,
				 tarea,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r3",
				 TAREA__R3__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the r4 constraint of '<em>Tarea</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA__R4__EEXPRESSION = "self.predecesor->selectByType(TareaFin)->size() = 0";

	/**
	 * Validates the r4 constraint of '<em>Tarea</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTarea_r4(Tarea tarea, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA,
				 tarea,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r4",
				 TAREA__R4__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the r6a constraint of '<em>Tarea</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA__R6A__EEXPRESSION = "self.sucesor <> self";

	/**
	 * Validates the r6a constraint of '<em>Tarea</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTarea_r6a(Tarea tarea, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA,
				 tarea,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r6a",
				 TAREA__R6A__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the r6b constraint of '<em>Tarea</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA__R6B__EEXPRESSION = "self.predecesor <> self";

	/**
	 * Validates the r6b constraint of '<em>Tarea</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTarea_r6b(Tarea tarea, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA,
				 tarea,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r6b",
				 TAREA__R6B__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaUsuario(TareaUsuario tareaUsuario, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(tareaUsuario, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(tareaUsuario, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(tareaUsuario, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(tareaUsuario, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(tareaUsuario, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(tareaUsuario, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(tareaUsuario, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(tareaUsuario, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(tareaUsuario, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r3(tareaUsuario, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r4(tareaUsuario, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6a(tareaUsuario, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6b(tareaUsuario, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaWorkflow_r9(tareaUsuario, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaWorkflow_r9b(tareaUsuario, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaUsuario_r8tus(tareaUsuario, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaUsuario_r8tup(tareaUsuario, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the r8tus constraint of '<em>Tarea Usuario</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_USUARIO__R8TUS__EEXPRESSION = "self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor";

	/**
	 * Validates the r8tus constraint of '<em>Tarea Usuario</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaUsuario_r8tus(TareaUsuario tareaUsuario, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_USUARIO,
				 tareaUsuario,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r8tus",
				 TAREA_USUARIO__R8TUS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the r8tup constraint of '<em>Tarea Usuario</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_USUARIO__R8TUP__EEXPRESSION = "self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor";

	/**
	 * Validates the r8tup constraint of '<em>Tarea Usuario</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaUsuario_r8tup(TareaUsuario tareaUsuario, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_USUARIO,
				 tareaUsuario,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r8tup",
				 TAREA_USUARIO__R8TUP__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaServicio(TareaServicio tareaServicio, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(tareaServicio, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(tareaServicio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(tareaServicio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(tareaServicio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(tareaServicio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(tareaServicio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(tareaServicio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(tareaServicio, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(tareaServicio, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r3(tareaServicio, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r4(tareaServicio, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6a(tareaServicio, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6b(tareaServicio, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaWorkflow_r9(tareaServicio, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaWorkflow_r9b(tareaServicio, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaServicio_r8tss(tareaServicio, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaServicio_r8tsp(tareaServicio, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the r8tss constraint of '<em>Tarea Servicio</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_SERVICIO__R8TSS__EEXPRESSION = "self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor";

	/**
	 * Validates the r8tss constraint of '<em>Tarea Servicio</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaServicio_r8tss(TareaServicio tareaServicio, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_SERVICIO,
				 tareaServicio,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r8tss",
				 TAREA_SERVICIO__R8TSS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the r8tsp constraint of '<em>Tarea Servicio</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_SERVICIO__R8TSP__EEXPRESSION = "self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor";

	/**
	 * Validates the r8tsp constraint of '<em>Tarea Servicio</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaServicio_r8tsp(TareaServicio tareaServicio, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_SERVICIO,
				 tareaServicio,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r8tsp",
				 TAREA_SERVICIO__R8TSP__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaEnvioMsj(TareaEnvioMsj tareaEnvioMsj, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(tareaEnvioMsj, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r3(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r4(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6a(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6b(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaWorkflow_r9(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaWorkflow_r9b(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaEnvioMsj_r10(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaEnvioMsj_r8tes(tareaEnvioMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaEnvioMsj_r8tep(tareaEnvioMsj, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the r10 constraint of '<em>Tarea Envio Msj</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_ENVIO_MSJ__R10__EEXPRESSION = "self.codificacion = self.sucesor.oclAsType(TareaRecepMsj).codificacion";

	/**
	 * Validates the r10 constraint of '<em>Tarea Envio Msj</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaEnvioMsj_r10(TareaEnvioMsj tareaEnvioMsj, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_ENVIO_MSJ,
				 tareaEnvioMsj,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r10",
				 TAREA_ENVIO_MSJ__R10__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the r8tes constraint of '<em>Tarea Envio Msj</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_ENVIO_MSJ__R8TES__EEXPRESSION = "self.oclContainer().oclAsType(Actor).id_actor <> self.sucesor.oclContainer().oclAsType(Actor).id_actor";

	/**
	 * Validates the r8tes constraint of '<em>Tarea Envio Msj</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaEnvioMsj_r8tes(TareaEnvioMsj tareaEnvioMsj, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_ENVIO_MSJ,
				 tareaEnvioMsj,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r8tes",
				 TAREA_ENVIO_MSJ__R8TES__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the r8tep constraint of '<em>Tarea Envio Msj</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_ENVIO_MSJ__R8TEP__EEXPRESSION = "self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor";

	/**
	 * Validates the r8tep constraint of '<em>Tarea Envio Msj</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaEnvioMsj_r8tep(TareaEnvioMsj tareaEnvioMsj, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_ENVIO_MSJ,
				 tareaEnvioMsj,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r8tep",
				 TAREA_ENVIO_MSJ__R8TEP__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaRecepMsj(TareaRecepMsj tareaRecepMsj, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(tareaRecepMsj, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r3(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r4(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6a(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6b(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaWorkflow_r9(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaWorkflow_r9b(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaRecepMsj_r7(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaRecepMsj_r8trs(tareaRecepMsj, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaRecepMsj_r8trp(tareaRecepMsj, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the r7 constraint of '<em>Tarea Recep Msj</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_RECEP_MSJ__R7__EEXPRESSION = "self.predecesor->selectByKind(TareaEnvioMsj)->size() = 1";

	/**
	 * Validates the r7 constraint of '<em>Tarea Recep Msj</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaRecepMsj_r7(TareaRecepMsj tareaRecepMsj, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_RECEP_MSJ,
				 tareaRecepMsj,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r7",
				 TAREA_RECEP_MSJ__R7__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the r8trs constraint of '<em>Tarea Recep Msj</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_RECEP_MSJ__R8TRS__EEXPRESSION = "self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor";

	/**
	 * Validates the r8trs constraint of '<em>Tarea Recep Msj</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaRecepMsj_r8trs(TareaRecepMsj tareaRecepMsj, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_RECEP_MSJ,
				 tareaRecepMsj,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r8trs",
				 TAREA_RECEP_MSJ__R8TRS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the r8trp constraint of '<em>Tarea Recep Msj</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_RECEP_MSJ__R8TRP__EEXPRESSION = "self.oclContainer().oclAsType(Actor).id_actor <> self.predecesor.oclContainer().oclAsType(Actor).id_actor";

	/**
	 * Validates the r8trp constraint of '<em>Tarea Recep Msj</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaRecepMsj_r8trp(TareaRecepMsj tareaRecepMsj, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_RECEP_MSJ,
				 tareaRecepMsj,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r8trp",
				 TAREA_RECEP_MSJ__R8TRP__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaConsulta(TareaConsulta tareaConsulta, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(tareaConsulta, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(tareaConsulta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(tareaConsulta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(tareaConsulta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(tareaConsulta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(tareaConsulta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(tareaConsulta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(tareaConsulta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(tareaConsulta, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r3(tareaConsulta, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r4(tareaConsulta, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6a(tareaConsulta, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6b(tareaConsulta, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaWorkflow_r9(tareaConsulta, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaWorkflow_r9b(tareaConsulta, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaConsulta_r8tcs(tareaConsulta, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaConsulta_r8tcp(tareaConsulta, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the r8tcs constraint of '<em>Tarea Consulta</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_CONSULTA__R8TCS__EEXPRESSION = "self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor";

	/**
	 * Validates the r8tcs constraint of '<em>Tarea Consulta</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaConsulta_r8tcs(TareaConsulta tareaConsulta, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_CONSULTA,
				 tareaConsulta,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r8tcs",
				 TAREA_CONSULTA__R8TCS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the r8tcp constraint of '<em>Tarea Consulta</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_CONSULTA__R8TCP__EEXPRESSION = "self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor";

	/**
	 * Validates the r8tcp constraint of '<em>Tarea Consulta</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaConsulta_r8tcp(TareaConsulta tareaConsulta, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_CONSULTA,
				 tareaConsulta,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r8tcp",
				 TAREA_CONSULTA__R8TCP__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaBorrado(TareaBorrado tareaBorrado, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(tareaBorrado, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(tareaBorrado, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(tareaBorrado, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(tareaBorrado, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(tareaBorrado, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(tareaBorrado, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(tareaBorrado, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(tareaBorrado, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(tareaBorrado, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r3(tareaBorrado, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r4(tareaBorrado, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6a(tareaBorrado, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6b(tareaBorrado, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaWorkflow_r9(tareaBorrado, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaWorkflow_r9b(tareaBorrado, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaBorrado_r8tbs(tareaBorrado, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaBorrado_r8tbp(tareaBorrado, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the r8tbs constraint of '<em>Tarea Borrado</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_BORRADO__R8TBS__EEXPRESSION = "self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor";

	/**
	 * Validates the r8tbs constraint of '<em>Tarea Borrado</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaBorrado_r8tbs(TareaBorrado tareaBorrado, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_BORRADO,
				 tareaBorrado,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r8tbs",
				 TAREA_BORRADO__R8TBS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the r8tbp constraint of '<em>Tarea Borrado</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_BORRADO__R8TBP__EEXPRESSION = "self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor";

	/**
	 * Validates the r8tbp constraint of '<em>Tarea Borrado</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaBorrado_r8tbp(TareaBorrado tareaBorrado, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_BORRADO,
				 tareaBorrado,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r8tbp",
				 TAREA_BORRADO__R8TBP__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateBaseDeDatos(BaseDeDatos baseDeDatos, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(baseDeDatos, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTabla(Tabla tabla, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(tabla, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAtributo(Atributo atributo, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(atributo, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaWorkflow(TareaWorkflow tareaWorkflow, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(tareaWorkflow, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(tareaWorkflow, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(tareaWorkflow, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(tareaWorkflow, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(tareaWorkflow, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(tareaWorkflow, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(tareaWorkflow, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(tareaWorkflow, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(tareaWorkflow, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r3(tareaWorkflow, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r4(tareaWorkflow, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6a(tareaWorkflow, diagnostics, context);
		if (result || diagnostics != null) result &= validateTarea_r6b(tareaWorkflow, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaWorkflow_r9(tareaWorkflow, diagnostics, context);
		if (result || diagnostics != null) result &= validateTareaWorkflow_r9b(tareaWorkflow, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the r9 constraint of '<em>Tarea Workflow</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_WORKFLOW__R9__EEXPRESSION = "self.sucesor->size() = 1";

	/**
	 * Validates the r9 constraint of '<em>Tarea Workflow</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaWorkflow_r9(TareaWorkflow tareaWorkflow, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_WORKFLOW,
				 tareaWorkflow,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r9",
				 TAREA_WORKFLOW__R9__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the r9b constraint of '<em>Tarea Workflow</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TAREA_WORKFLOW__R9B__EEXPRESSION = "self.predecesor->size() = 1";

	/**
	 * Validates the r9b constraint of '<em>Tarea Workflow</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTareaWorkflow_r9b(TareaWorkflow tareaWorkflow, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(MyBPMSPackage.Literals.TAREA_WORKFLOW,
				 tareaWorkflow,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "r9b",
				 TAREA_WORKFLOW__R9B__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFichero(Fichero fichero, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(fichero, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTipo_atributo(Tipo_atributo tipo_atributo, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTipo_codificacion(Tipo_codificacion tipo_codificacion, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //MyBPMSValidator

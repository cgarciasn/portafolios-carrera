/**
 */
package myBPMS;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tarea Servicio</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.TareaServicio#getServicio <em>Servicio</em>}</li>
 *   <li>{@link myBPMS.TareaServicio#getUsa <em>Usa</em>}</li>
 *   <li>{@link myBPMS.TareaServicio#getGenera <em>Genera</em>}</li>
 * </ul>
 *
 * @see myBPMS.MyBPMSPackage#getTareaServicio()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='r8tss r8tsp'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot r8tss='self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor' r8tsp='self.oclContainer().oclAsType(Actor).id_actor = self.predecesor.oclContainer().oclAsType(Actor).id_actor'"
 *        annotation="gmf.node label='id_tareaworkflow' color='4,46,255' figure='rectangle'"
 * @generated
 */
public interface TareaServicio extends TareaWorkflow {
	/**
	 * Returns the value of the '<em><b>Servicio</b></em>' reference list.
	 * The list contents are of type {@link myBPMS.Tabla}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Servicio</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Servicio</em>' reference list.
	 * @see myBPMS.MyBPMSPackage#getTareaServicio_Servicio()
	 * @model required="true"
	 *        annotation="gmf.link target='servicio' target.decoration='rhomb' style='solid'"
	 * @generated
	 */
	EList<Tabla> getServicio();

	/**
	 * Returns the value of the '<em><b>Usa</b></em>' reference list.
	 * The list contents are of type {@link myBPMS.Fichero}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Usa</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Usa</em>' reference list.
	 * @see myBPMS.MyBPMSPackage#getTareaServicio_Usa()
	 * @model annotation="gmf.link target='usa' target.decoration='arrow' style='solid'"
	 * @generated
	 */
	EList<Fichero> getUsa();

	/**
	 * Returns the value of the '<em><b>Genera</b></em>' reference list.
	 * The list contents are of type {@link myBPMS.Fichero}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Genera</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Genera</em>' reference list.
	 * @see myBPMS.MyBPMSPackage#getTareaServicio_Genera()
	 * @model annotation="gmf.link target='genera' target.decoration='arrow' style='solid'"
	 * @generated
	 */
	EList<Fichero> getGenera();

} // TareaServicio

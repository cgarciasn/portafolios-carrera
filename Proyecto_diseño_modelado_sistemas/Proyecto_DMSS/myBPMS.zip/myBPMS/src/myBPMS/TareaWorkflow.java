/**
 */
package myBPMS;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tarea Workflow</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.TareaWorkflow#getId_tareaworkflow <em>Id tareaworkflow</em>}</li>
 *   <li>{@link myBPMS.TareaWorkflow#getNombre_tarea <em>Nombre tarea</em>}</li>
 *   <li>{@link myBPMS.TareaWorkflow#getDescripcion <em>Descripcion</em>}</li>
 * </ul>
 *
 * @see myBPMS.MyBPMSPackage#getTareaWorkflow()
 * @model abstract="true"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='r9 r9b'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot r9='self.sucesor->size() = 1' r9b='self.predecesor->size() = 1'"
 * @generated
 */
public interface TareaWorkflow extends Tarea {
	/**
	 * Returns the value of the '<em><b>Id tareaworkflow</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id tareaworkflow</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id tareaworkflow</em>' attribute.
	 * @see #setId_tareaworkflow(String)
	 * @see myBPMS.MyBPMSPackage#getTareaWorkflow_Id_tareaworkflow()
	 * @model required="true"
	 * @generated
	 */
	String getId_tareaworkflow();

	/**
	 * Sets the value of the '{@link myBPMS.TareaWorkflow#getId_tareaworkflow <em>Id tareaworkflow</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id tareaworkflow</em>' attribute.
	 * @see #getId_tareaworkflow()
	 * @generated
	 */
	void setId_tareaworkflow(String value);

	/**
	 * Returns the value of the '<em><b>Nombre tarea</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nombre tarea</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nombre tarea</em>' attribute.
	 * @see #setNombre_tarea(String)
	 * @see myBPMS.MyBPMSPackage#getTareaWorkflow_Nombre_tarea()
	 * @model required="true"
	 * @generated
	 */
	String getNombre_tarea();

	/**
	 * Sets the value of the '{@link myBPMS.TareaWorkflow#getNombre_tarea <em>Nombre tarea</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nombre tarea</em>' attribute.
	 * @see #getNombre_tarea()
	 * @generated
	 */
	void setNombre_tarea(String value);

	/**
	 * Returns the value of the '<em><b>Descripcion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Descripcion</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Descripcion</em>' attribute.
	 * @see #setDescripcion(String)
	 * @see myBPMS.MyBPMSPackage#getTareaWorkflow_Descripcion()
	 * @model
	 * @generated
	 */
	String getDescripcion();

	/**
	 * Sets the value of the '{@link myBPMS.TareaWorkflow#getDescripcion <em>Descripcion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Descripcion</em>' attribute.
	 * @see #getDescripcion()
	 * @generated
	 */
	void setDescripcion(String value);

} // TareaWorkflow

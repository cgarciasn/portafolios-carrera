/**
 */
package myBPMS;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tarea</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.Tarea#getPredecesor <em>Predecesor</em>}</li>
 *   <li>{@link myBPMS.Tarea#getSucesor <em>Sucesor</em>}</li>
 * </ul>
 *
 * @see myBPMS.MyBPMSPackage#getTarea()
 * @model abstract="true"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='r3 r4 r6a r6b'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot r3='self.sucesor->selectByType(TareaInicio)->size() = 0' r4='self.predecesor->selectByType(TareaFin)->size() = 0' r6a='self.sucesor <> self' r6b='self.predecesor <> self'"
 * @generated
 */
public interface Tarea extends EObject {
	/**
	 * Returns the value of the '<em><b>Predecesor</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link myBPMS.Tarea#getSucesor <em>Sucesor</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Predecesor</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Predecesor</em>' reference.
	 * @see #setPredecesor(Tarea)
	 * @see myBPMS.MyBPMSPackage#getTarea_Predecesor()
	 * @see myBPMS.Tarea#getSucesor
	 * @model opposite="sucesor"
	 * @generated
	 */
	Tarea getPredecesor();

	/**
	 * Sets the value of the '{@link myBPMS.Tarea#getPredecesor <em>Predecesor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Predecesor</em>' reference.
	 * @see #getPredecesor()
	 * @generated
	 */
	void setPredecesor(Tarea value);

	/**
	 * Returns the value of the '<em><b>Sucesor</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link myBPMS.Tarea#getPredecesor <em>Predecesor</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sucesor</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sucesor</em>' reference.
	 * @see #setSucesor(Tarea)
	 * @see myBPMS.MyBPMSPackage#getTarea_Sucesor()
	 * @see myBPMS.Tarea#getPredecesor
	 * @model opposite="predecesor"
	 *        annotation="gmf.link target='sucesor' target.decoration='arrow' style='dash'"
	 * @generated
	 */
	Tarea getSucesor();

	/**
	 * Sets the value of the '{@link myBPMS.Tarea#getSucesor <em>Sucesor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sucesor</em>' reference.
	 * @see #getSucesor()
	 * @generated
	 */
	void setSucesor(Tarea value);

} // Tarea

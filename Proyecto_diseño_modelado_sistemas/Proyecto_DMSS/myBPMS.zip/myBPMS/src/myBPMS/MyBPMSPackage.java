/**
 */
package myBPMS;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see myBPMS.MyBPMSFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/OCL/Import ecore='http://www.eclipse.org/emf/2002/Ecore'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore invocationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' settingDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' validationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot'"
 * @generated
 */
public interface MyBPMSPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "myBPMS";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/myBPMS";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "myBPMS";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	MyBPMSPackage eINSTANCE = myBPMS.impl.MyBPMSPackageImpl.init();

	/**
	 * The meta object id for the '{@link myBPMS.impl.ProcesoDeNegocioImpl <em>Proceso De Negocio</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.ProcesoDeNegocioImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getProcesoDeNegocio()
	 * @generated
	 */
	int PROCESO_DE_NEGOCIO = 0;

	/**
	 * The feature id for the '<em><b>Actores</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESO_DE_NEGOCIO__ACTORES = 0;

	/**
	 * The feature id for the '<em><b>Id proceso</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESO_DE_NEGOCIO__ID_PROCESO = 1;

	/**
	 * The feature id for the '<em><b>Basesdedatos</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESO_DE_NEGOCIO__BASESDEDATOS = 2;

	/**
	 * The number of structural features of the '<em>Proceso De Negocio</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESO_DE_NEGOCIO_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link myBPMS.impl.ActorImpl <em>Actor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.ActorImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getActor()
	 * @generated
	 */
	int ACTOR = 1;

	/**
	 * The feature id for the '<em><b>Id actor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__ID_ACTOR = 0;

	/**
	 * The feature id for the '<em><b>Num tareas</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__NUM_TAREAS = 1;

	/**
	 * The feature id for the '<em><b>Tareas</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__TAREAS = 2;

	/**
	 * The feature id for the '<em><b>Ficheros</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR__FICHEROS = 3;

	/**
	 * The number of structural features of the '<em>Actor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTOR_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link myBPMS.impl.TareaImpl <em>Tarea</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.TareaImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getTarea()
	 * @generated
	 */
	int TAREA = 4;

	/**
	 * The feature id for the '<em><b>Predecesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA__PREDECESOR = 0;

	/**
	 * The feature id for the '<em><b>Sucesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA__SUCESOR = 1;

	/**
	 * The number of structural features of the '<em>Tarea</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link myBPMS.impl.TareaInicioImpl <em>Tarea Inicio</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.TareaInicioImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaInicio()
	 * @generated
	 */
	int TAREA_INICIO = 2;

	/**
	 * The feature id for the '<em><b>Predecesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_INICIO__PREDECESOR = TAREA__PREDECESOR;

	/**
	 * The feature id for the '<em><b>Sucesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_INICIO__SUCESOR = TAREA__SUCESOR;

	/**
	 * The number of structural features of the '<em>Tarea Inicio</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_INICIO_FEATURE_COUNT = TAREA_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link myBPMS.impl.TareaFinImpl <em>Tarea Fin</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.TareaFinImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaFin()
	 * @generated
	 */
	int TAREA_FIN = 3;

	/**
	 * The feature id for the '<em><b>Predecesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_FIN__PREDECESOR = TAREA__PREDECESOR;

	/**
	 * The feature id for the '<em><b>Sucesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_FIN__SUCESOR = TAREA__SUCESOR;

	/**
	 * The number of structural features of the '<em>Tarea Fin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_FIN_FEATURE_COUNT = TAREA_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link myBPMS.impl.TareaWorkflowImpl <em>Tarea Workflow</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.TareaWorkflowImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaWorkflow()
	 * @generated
	 */
	int TAREA_WORKFLOW = 14;

	/**
	 * The feature id for the '<em><b>Predecesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_WORKFLOW__PREDECESOR = TAREA__PREDECESOR;

	/**
	 * The feature id for the '<em><b>Sucesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_WORKFLOW__SUCESOR = TAREA__SUCESOR;

	/**
	 * The feature id for the '<em><b>Id tareaworkflow</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_WORKFLOW__ID_TAREAWORKFLOW = TAREA_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Nombre tarea</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_WORKFLOW__NOMBRE_TAREA = TAREA_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Descripcion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_WORKFLOW__DESCRIPCION = TAREA_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Tarea Workflow</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_WORKFLOW_FEATURE_COUNT = TAREA_FEATURE_COUNT + 3;

	/**
	 * The meta object id for the '{@link myBPMS.impl.TareaUsuarioImpl <em>Tarea Usuario</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.TareaUsuarioImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaUsuario()
	 * @generated
	 */
	int TAREA_USUARIO = 5;

	/**
	 * The feature id for the '<em><b>Predecesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_USUARIO__PREDECESOR = TAREA_WORKFLOW__PREDECESOR;

	/**
	 * The feature id for the '<em><b>Sucesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_USUARIO__SUCESOR = TAREA_WORKFLOW__SUCESOR;

	/**
	 * The feature id for the '<em><b>Id tareaworkflow</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_USUARIO__ID_TAREAWORKFLOW = TAREA_WORKFLOW__ID_TAREAWORKFLOW;

	/**
	 * The feature id for the '<em><b>Nombre tarea</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_USUARIO__NOMBRE_TAREA = TAREA_WORKFLOW__NOMBRE_TAREA;

	/**
	 * The feature id for the '<em><b>Descripcion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_USUARIO__DESCRIPCION = TAREA_WORKFLOW__DESCRIPCION;

	/**
	 * The feature id for the '<em><b>Formularios</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_USUARIO__FORMULARIOS = TAREA_WORKFLOW_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Tarea Usuario</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_USUARIO_FEATURE_COUNT = TAREA_WORKFLOW_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link myBPMS.impl.TareaServicioImpl <em>Tarea Servicio</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.TareaServicioImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaServicio()
	 * @generated
	 */
	int TAREA_SERVICIO = 6;

	/**
	 * The feature id for the '<em><b>Predecesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_SERVICIO__PREDECESOR = TAREA_WORKFLOW__PREDECESOR;

	/**
	 * The feature id for the '<em><b>Sucesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_SERVICIO__SUCESOR = TAREA_WORKFLOW__SUCESOR;

	/**
	 * The feature id for the '<em><b>Id tareaworkflow</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_SERVICIO__ID_TAREAWORKFLOW = TAREA_WORKFLOW__ID_TAREAWORKFLOW;

	/**
	 * The feature id for the '<em><b>Nombre tarea</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_SERVICIO__NOMBRE_TAREA = TAREA_WORKFLOW__NOMBRE_TAREA;

	/**
	 * The feature id for the '<em><b>Descripcion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_SERVICIO__DESCRIPCION = TAREA_WORKFLOW__DESCRIPCION;

	/**
	 * The feature id for the '<em><b>Servicio</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_SERVICIO__SERVICIO = TAREA_WORKFLOW_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Usa</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_SERVICIO__USA = TAREA_WORKFLOW_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Genera</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_SERVICIO__GENERA = TAREA_WORKFLOW_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Tarea Servicio</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_SERVICIO_FEATURE_COUNT = TAREA_WORKFLOW_FEATURE_COUNT + 3;

	/**
	 * The meta object id for the '{@link myBPMS.impl.TareaEnvioMsjImpl <em>Tarea Envio Msj</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.TareaEnvioMsjImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaEnvioMsj()
	 * @generated
	 */
	int TAREA_ENVIO_MSJ = 7;

	/**
	 * The feature id for the '<em><b>Predecesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_ENVIO_MSJ__PREDECESOR = TAREA_WORKFLOW__PREDECESOR;

	/**
	 * The feature id for the '<em><b>Sucesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_ENVIO_MSJ__SUCESOR = TAREA_WORKFLOW__SUCESOR;

	/**
	 * The feature id for the '<em><b>Id tareaworkflow</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_ENVIO_MSJ__ID_TAREAWORKFLOW = TAREA_WORKFLOW__ID_TAREAWORKFLOW;

	/**
	 * The feature id for the '<em><b>Nombre tarea</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_ENVIO_MSJ__NOMBRE_TAREA = TAREA_WORKFLOW__NOMBRE_TAREA;

	/**
	 * The feature id for the '<em><b>Descripcion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_ENVIO_MSJ__DESCRIPCION = TAREA_WORKFLOW__DESCRIPCION;

	/**
	 * The feature id for the '<em><b>Envio msj</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_ENVIO_MSJ__ENVIO_MSJ = TAREA_WORKFLOW_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Codificacion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_ENVIO_MSJ__CODIFICACION = TAREA_WORKFLOW_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Adjunta</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_ENVIO_MSJ__ADJUNTA = TAREA_WORKFLOW_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Tarea Envio Msj</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_ENVIO_MSJ_FEATURE_COUNT = TAREA_WORKFLOW_FEATURE_COUNT + 3;

	/**
	 * The meta object id for the '{@link myBPMS.impl.TareaRecepMsjImpl <em>Tarea Recep Msj</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.TareaRecepMsjImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaRecepMsj()
	 * @generated
	 */
	int TAREA_RECEP_MSJ = 8;

	/**
	 * The feature id for the '<em><b>Predecesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_RECEP_MSJ__PREDECESOR = TAREA_WORKFLOW__PREDECESOR;

	/**
	 * The feature id for the '<em><b>Sucesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_RECEP_MSJ__SUCESOR = TAREA_WORKFLOW__SUCESOR;

	/**
	 * The feature id for the '<em><b>Id tareaworkflow</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_RECEP_MSJ__ID_TAREAWORKFLOW = TAREA_WORKFLOW__ID_TAREAWORKFLOW;

	/**
	 * The feature id for the '<em><b>Nombre tarea</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_RECEP_MSJ__NOMBRE_TAREA = TAREA_WORKFLOW__NOMBRE_TAREA;

	/**
	 * The feature id for the '<em><b>Descripcion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_RECEP_MSJ__DESCRIPCION = TAREA_WORKFLOW__DESCRIPCION;

	/**
	 * The feature id for the '<em><b>Recepcion msj</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_RECEP_MSJ__RECEPCION_MSJ = TAREA_WORKFLOW_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Codificacion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_RECEP_MSJ__CODIFICACION = TAREA_WORKFLOW_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Tarea Recep Msj</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_RECEP_MSJ_FEATURE_COUNT = TAREA_WORKFLOW_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link myBPMS.impl.TareaConsultaImpl <em>Tarea Consulta</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.TareaConsultaImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaConsulta()
	 * @generated
	 */
	int TAREA_CONSULTA = 9;

	/**
	 * The feature id for the '<em><b>Predecesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_CONSULTA__PREDECESOR = TAREA_WORKFLOW__PREDECESOR;

	/**
	 * The feature id for the '<em><b>Sucesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_CONSULTA__SUCESOR = TAREA_WORKFLOW__SUCESOR;

	/**
	 * The feature id for the '<em><b>Id tareaworkflow</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_CONSULTA__ID_TAREAWORKFLOW = TAREA_WORKFLOW__ID_TAREAWORKFLOW;

	/**
	 * The feature id for the '<em><b>Nombre tarea</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_CONSULTA__NOMBRE_TAREA = TAREA_WORKFLOW__NOMBRE_TAREA;

	/**
	 * The feature id for the '<em><b>Descripcion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_CONSULTA__DESCRIPCION = TAREA_WORKFLOW__DESCRIPCION;

	/**
	 * The feature id for the '<em><b>Consultar atributo</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_CONSULTA__CONSULTAR_ATRIBUTO = TAREA_WORKFLOW_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Tarea Consulta</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_CONSULTA_FEATURE_COUNT = TAREA_WORKFLOW_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link myBPMS.impl.TareaBorradoImpl <em>Tarea Borrado</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.TareaBorradoImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaBorrado()
	 * @generated
	 */
	int TAREA_BORRADO = 10;

	/**
	 * The feature id for the '<em><b>Predecesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_BORRADO__PREDECESOR = TAREA_WORKFLOW__PREDECESOR;

	/**
	 * The feature id for the '<em><b>Sucesor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_BORRADO__SUCESOR = TAREA_WORKFLOW__SUCESOR;

	/**
	 * The feature id for the '<em><b>Id tareaworkflow</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_BORRADO__ID_TAREAWORKFLOW = TAREA_WORKFLOW__ID_TAREAWORKFLOW;

	/**
	 * The feature id for the '<em><b>Nombre tarea</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_BORRADO__NOMBRE_TAREA = TAREA_WORKFLOW__NOMBRE_TAREA;

	/**
	 * The feature id for the '<em><b>Descripcion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_BORRADO__DESCRIPCION = TAREA_WORKFLOW__DESCRIPCION;

	/**
	 * The feature id for the '<em><b>Borrar atributo</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_BORRADO__BORRAR_ATRIBUTO = TAREA_WORKFLOW_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Tarea Borrado</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAREA_BORRADO_FEATURE_COUNT = TAREA_WORKFLOW_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link myBPMS.impl.BaseDeDatosImpl <em>Base De Datos</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.BaseDeDatosImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getBaseDeDatos()
	 * @generated
	 */
	int BASE_DE_DATOS = 11;

	/**
	 * The feature id for the '<em><b>Tablas</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_DE_DATOS__TABLAS = 0;

	/**
	 * The feature id for the '<em><b>Id basedatos</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_DE_DATOS__ID_BASEDATOS = 1;

	/**
	 * The number of structural features of the '<em>Base De Datos</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_DE_DATOS_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link myBPMS.impl.TablaImpl <em>Tabla</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.TablaImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getTabla()
	 * @generated
	 */
	int TABLA = 12;

	/**
	 * The feature id for the '<em><b>Atributos</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TABLA__ATRIBUTOS = 0;

	/**
	 * The feature id for the '<em><b>Id tabla</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TABLA__ID_TABLA = 1;

	/**
	 * The number of structural features of the '<em>Tabla</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TABLA_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link myBPMS.impl.AtributoImpl <em>Atributo</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.AtributoImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getAtributo()
	 * @generated
	 */
	int ATRIBUTO = 13;

	/**
	 * The feature id for the '<em><b>Id atributo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATRIBUTO__ID_ATRIBUTO = 0;

	/**
	 * The feature id for the '<em><b>Tipo atributo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATRIBUTO__TIPO_ATRIBUTO = 1;

	/**
	 * The feature id for the '<em><b>Clave ajena</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATRIBUTO__CLAVE_AJENA = 2;

	/**
	 * The feature id for the '<em><b>Visible</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATRIBUTO__VISIBLE = 3;

	/**
	 * The feature id for the '<em><b>Clave primaria</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATRIBUTO__CLAVE_PRIMARIA = 4;

	/**
	 * The number of structural features of the '<em>Atributo</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATRIBUTO_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link myBPMS.impl.FicheroImpl <em>Fichero</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.impl.FicheroImpl
	 * @see myBPMS.impl.MyBPMSPackageImpl#getFichero()
	 * @generated
	 */
	int FICHERO = 15;

	/**
	 * The feature id for the '<em><b>Id fichero</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FICHERO__ID_FICHERO = 0;

	/**
	 * The number of structural features of the '<em>Fichero</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FICHERO_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link myBPMS.Tipo_atributo <em>Tipo atributo</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.Tipo_atributo
	 * @see myBPMS.impl.MyBPMSPackageImpl#getTipo_atributo()
	 * @generated
	 */
	int TIPO_ATRIBUTO = 16;

	/**
	 * The meta object id for the '{@link myBPMS.Tipo_codificacion <em>Tipo codificacion</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see myBPMS.Tipo_codificacion
	 * @see myBPMS.impl.MyBPMSPackageImpl#getTipo_codificacion()
	 * @generated
	 */
	int TIPO_CODIFICACION = 17;


	/**
	 * Returns the meta object for class '{@link myBPMS.ProcesoDeNegocio <em>Proceso De Negocio</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Proceso De Negocio</em>'.
	 * @see myBPMS.ProcesoDeNegocio
	 * @generated
	 */
	EClass getProcesoDeNegocio();

	/**
	 * Returns the meta object for the containment reference list '{@link myBPMS.ProcesoDeNegocio#getActores <em>Actores</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Actores</em>'.
	 * @see myBPMS.ProcesoDeNegocio#getActores()
	 * @see #getProcesoDeNegocio()
	 * @generated
	 */
	EReference getProcesoDeNegocio_Actores();

	/**
	 * Returns the meta object for the attribute '{@link myBPMS.ProcesoDeNegocio#getId_proceso <em>Id proceso</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id proceso</em>'.
	 * @see myBPMS.ProcesoDeNegocio#getId_proceso()
	 * @see #getProcesoDeNegocio()
	 * @generated
	 */
	EAttribute getProcesoDeNegocio_Id_proceso();

	/**
	 * Returns the meta object for the containment reference list '{@link myBPMS.ProcesoDeNegocio#getBasesdedatos <em>Basesdedatos</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Basesdedatos</em>'.
	 * @see myBPMS.ProcesoDeNegocio#getBasesdedatos()
	 * @see #getProcesoDeNegocio()
	 * @generated
	 */
	EReference getProcesoDeNegocio_Basesdedatos();

	/**
	 * Returns the meta object for class '{@link myBPMS.Actor <em>Actor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Actor</em>'.
	 * @see myBPMS.Actor
	 * @generated
	 */
	EClass getActor();

	/**
	 * Returns the meta object for the attribute '{@link myBPMS.Actor#getId_actor <em>Id actor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id actor</em>'.
	 * @see myBPMS.Actor#getId_actor()
	 * @see #getActor()
	 * @generated
	 */
	EAttribute getActor_Id_actor();

	/**
	 * Returns the meta object for the attribute '{@link myBPMS.Actor#getNum_tareas <em>Num tareas</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Num tareas</em>'.
	 * @see myBPMS.Actor#getNum_tareas()
	 * @see #getActor()
	 * @generated
	 */
	EAttribute getActor_Num_tareas();

	/**
	 * Returns the meta object for the containment reference list '{@link myBPMS.Actor#getTareas <em>Tareas</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Tareas</em>'.
	 * @see myBPMS.Actor#getTareas()
	 * @see #getActor()
	 * @generated
	 */
	EReference getActor_Tareas();

	/**
	 * Returns the meta object for the containment reference list '{@link myBPMS.Actor#getFicheros <em>Ficheros</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Ficheros</em>'.
	 * @see myBPMS.Actor#getFicheros()
	 * @see #getActor()
	 * @generated
	 */
	EReference getActor_Ficheros();

	/**
	 * Returns the meta object for class '{@link myBPMS.TareaInicio <em>Tarea Inicio</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tarea Inicio</em>'.
	 * @see myBPMS.TareaInicio
	 * @generated
	 */
	EClass getTareaInicio();

	/**
	 * Returns the meta object for class '{@link myBPMS.TareaFin <em>Tarea Fin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tarea Fin</em>'.
	 * @see myBPMS.TareaFin
	 * @generated
	 */
	EClass getTareaFin();

	/**
	 * Returns the meta object for class '{@link myBPMS.Tarea <em>Tarea</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tarea</em>'.
	 * @see myBPMS.Tarea
	 * @generated
	 */
	EClass getTarea();

	/**
	 * Returns the meta object for the reference '{@link myBPMS.Tarea#getPredecesor <em>Predecesor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Predecesor</em>'.
	 * @see myBPMS.Tarea#getPredecesor()
	 * @see #getTarea()
	 * @generated
	 */
	EReference getTarea_Predecesor();

	/**
	 * Returns the meta object for the reference '{@link myBPMS.Tarea#getSucesor <em>Sucesor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Sucesor</em>'.
	 * @see myBPMS.Tarea#getSucesor()
	 * @see #getTarea()
	 * @generated
	 */
	EReference getTarea_Sucesor();

	/**
	 * Returns the meta object for class '{@link myBPMS.TareaUsuario <em>Tarea Usuario</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tarea Usuario</em>'.
	 * @see myBPMS.TareaUsuario
	 * @generated
	 */
	EClass getTareaUsuario();

	/**
	 * Returns the meta object for the reference list '{@link myBPMS.TareaUsuario#getFormularios <em>Formularios</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Formularios</em>'.
	 * @see myBPMS.TareaUsuario#getFormularios()
	 * @see #getTareaUsuario()
	 * @generated
	 */
	EReference getTareaUsuario_Formularios();

	/**
	 * Returns the meta object for class '{@link myBPMS.TareaServicio <em>Tarea Servicio</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tarea Servicio</em>'.
	 * @see myBPMS.TareaServicio
	 * @generated
	 */
	EClass getTareaServicio();

	/**
	 * Returns the meta object for the reference list '{@link myBPMS.TareaServicio#getServicio <em>Servicio</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Servicio</em>'.
	 * @see myBPMS.TareaServicio#getServicio()
	 * @see #getTareaServicio()
	 * @generated
	 */
	EReference getTareaServicio_Servicio();

	/**
	 * Returns the meta object for the reference list '{@link myBPMS.TareaServicio#getUsa <em>Usa</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Usa</em>'.
	 * @see myBPMS.TareaServicio#getUsa()
	 * @see #getTareaServicio()
	 * @generated
	 */
	EReference getTareaServicio_Usa();

	/**
	 * Returns the meta object for the reference list '{@link myBPMS.TareaServicio#getGenera <em>Genera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Genera</em>'.
	 * @see myBPMS.TareaServicio#getGenera()
	 * @see #getTareaServicio()
	 * @generated
	 */
	EReference getTareaServicio_Genera();

	/**
	 * Returns the meta object for class '{@link myBPMS.TareaEnvioMsj <em>Tarea Envio Msj</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tarea Envio Msj</em>'.
	 * @see myBPMS.TareaEnvioMsj
	 * @generated
	 */
	EClass getTareaEnvioMsj();

	/**
	 * Returns the meta object for the reference list '{@link myBPMS.TareaEnvioMsj#getEnvio_msj <em>Envio msj</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Envio msj</em>'.
	 * @see myBPMS.TareaEnvioMsj#getEnvio_msj()
	 * @see #getTareaEnvioMsj()
	 * @generated
	 */
	EReference getTareaEnvioMsj_Envio_msj();

	/**
	 * Returns the meta object for the attribute '{@link myBPMS.TareaEnvioMsj#getCodificacion <em>Codificacion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Codificacion</em>'.
	 * @see myBPMS.TareaEnvioMsj#getCodificacion()
	 * @see #getTareaEnvioMsj()
	 * @generated
	 */
	EAttribute getTareaEnvioMsj_Codificacion();

	/**
	 * Returns the meta object for the reference list '{@link myBPMS.TareaEnvioMsj#getAdjunta <em>Adjunta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Adjunta</em>'.
	 * @see myBPMS.TareaEnvioMsj#getAdjunta()
	 * @see #getTareaEnvioMsj()
	 * @generated
	 */
	EReference getTareaEnvioMsj_Adjunta();

	/**
	 * Returns the meta object for class '{@link myBPMS.TareaRecepMsj <em>Tarea Recep Msj</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tarea Recep Msj</em>'.
	 * @see myBPMS.TareaRecepMsj
	 * @generated
	 */
	EClass getTareaRecepMsj();

	/**
	 * Returns the meta object for the reference list '{@link myBPMS.TareaRecepMsj#getRecepcion_msj <em>Recepcion msj</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Recepcion msj</em>'.
	 * @see myBPMS.TareaRecepMsj#getRecepcion_msj()
	 * @see #getTareaRecepMsj()
	 * @generated
	 */
	EReference getTareaRecepMsj_Recepcion_msj();

	/**
	 * Returns the meta object for the attribute '{@link myBPMS.TareaRecepMsj#getCodificacion <em>Codificacion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Codificacion</em>'.
	 * @see myBPMS.TareaRecepMsj#getCodificacion()
	 * @see #getTareaRecepMsj()
	 * @generated
	 */
	EAttribute getTareaRecepMsj_Codificacion();

	/**
	 * Returns the meta object for class '{@link myBPMS.TareaConsulta <em>Tarea Consulta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tarea Consulta</em>'.
	 * @see myBPMS.TareaConsulta
	 * @generated
	 */
	EClass getTareaConsulta();

	/**
	 * Returns the meta object for the reference list '{@link myBPMS.TareaConsulta#getConsultar_atributo <em>Consultar atributo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Consultar atributo</em>'.
	 * @see myBPMS.TareaConsulta#getConsultar_atributo()
	 * @see #getTareaConsulta()
	 * @generated
	 */
	EReference getTareaConsulta_Consultar_atributo();

	/**
	 * Returns the meta object for class '{@link myBPMS.TareaBorrado <em>Tarea Borrado</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tarea Borrado</em>'.
	 * @see myBPMS.TareaBorrado
	 * @generated
	 */
	EClass getTareaBorrado();

	/**
	 * Returns the meta object for the reference list '{@link myBPMS.TareaBorrado#getBorrar_atributo <em>Borrar atributo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Borrar atributo</em>'.
	 * @see myBPMS.TareaBorrado#getBorrar_atributo()
	 * @see #getTareaBorrado()
	 * @generated
	 */
	EReference getTareaBorrado_Borrar_atributo();

	/**
	 * Returns the meta object for class '{@link myBPMS.BaseDeDatos <em>Base De Datos</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Base De Datos</em>'.
	 * @see myBPMS.BaseDeDatos
	 * @generated
	 */
	EClass getBaseDeDatos();

	/**
	 * Returns the meta object for the containment reference list '{@link myBPMS.BaseDeDatos#getTablas <em>Tablas</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Tablas</em>'.
	 * @see myBPMS.BaseDeDatos#getTablas()
	 * @see #getBaseDeDatos()
	 * @generated
	 */
	EReference getBaseDeDatos_Tablas();

	/**
	 * Returns the meta object for the attribute '{@link myBPMS.BaseDeDatos#getId_basedatos <em>Id basedatos</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id basedatos</em>'.
	 * @see myBPMS.BaseDeDatos#getId_basedatos()
	 * @see #getBaseDeDatos()
	 * @generated
	 */
	EAttribute getBaseDeDatos_Id_basedatos();

	/**
	 * Returns the meta object for class '{@link myBPMS.Tabla <em>Tabla</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tabla</em>'.
	 * @see myBPMS.Tabla
	 * @generated
	 */
	EClass getTabla();

	/**
	 * Returns the meta object for the containment reference list '{@link myBPMS.Tabla#getAtributos <em>Atributos</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Atributos</em>'.
	 * @see myBPMS.Tabla#getAtributos()
	 * @see #getTabla()
	 * @generated
	 */
	EReference getTabla_Atributos();

	/**
	 * Returns the meta object for the attribute '{@link myBPMS.Tabla#getId_tabla <em>Id tabla</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id tabla</em>'.
	 * @see myBPMS.Tabla#getId_tabla()
	 * @see #getTabla()
	 * @generated
	 */
	EAttribute getTabla_Id_tabla();

	/**
	 * Returns the meta object for class '{@link myBPMS.Atributo <em>Atributo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Atributo</em>'.
	 * @see myBPMS.Atributo
	 * @generated
	 */
	EClass getAtributo();

	/**
	 * Returns the meta object for the attribute '{@link myBPMS.Atributo#getId_atributo <em>Id atributo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id atributo</em>'.
	 * @see myBPMS.Atributo#getId_atributo()
	 * @see #getAtributo()
	 * @generated
	 */
	EAttribute getAtributo_Id_atributo();

	/**
	 * Returns the meta object for the attribute '{@link myBPMS.Atributo#getTipo_atributo <em>Tipo atributo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Tipo atributo</em>'.
	 * @see myBPMS.Atributo#getTipo_atributo()
	 * @see #getAtributo()
	 * @generated
	 */
	EAttribute getAtributo_Tipo_atributo();

	/**
	 * Returns the meta object for the reference list '{@link myBPMS.Atributo#getClave_ajena <em>Clave ajena</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Clave ajena</em>'.
	 * @see myBPMS.Atributo#getClave_ajena()
	 * @see #getAtributo()
	 * @generated
	 */
	EReference getAtributo_Clave_ajena();

	/**
	 * Returns the meta object for the attribute '{@link myBPMS.Atributo#isVisible <em>Visible</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Visible</em>'.
	 * @see myBPMS.Atributo#isVisible()
	 * @see #getAtributo()
	 * @generated
	 */
	EAttribute getAtributo_Visible();

	/**
	 * Returns the meta object for the reference '{@link myBPMS.Atributo#getClave_primaria <em>Clave primaria</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Clave primaria</em>'.
	 * @see myBPMS.Atributo#getClave_primaria()
	 * @see #getAtributo()
	 * @generated
	 */
	EReference getAtributo_Clave_primaria();

	/**
	 * Returns the meta object for class '{@link myBPMS.TareaWorkflow <em>Tarea Workflow</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tarea Workflow</em>'.
	 * @see myBPMS.TareaWorkflow
	 * @generated
	 */
	EClass getTareaWorkflow();

	/**
	 * Returns the meta object for the attribute '{@link myBPMS.TareaWorkflow#getId_tareaworkflow <em>Id tareaworkflow</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id tareaworkflow</em>'.
	 * @see myBPMS.TareaWorkflow#getId_tareaworkflow()
	 * @see #getTareaWorkflow()
	 * @generated
	 */
	EAttribute getTareaWorkflow_Id_tareaworkflow();

	/**
	 * Returns the meta object for the attribute '{@link myBPMS.TareaWorkflow#getNombre_tarea <em>Nombre tarea</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nombre tarea</em>'.
	 * @see myBPMS.TareaWorkflow#getNombre_tarea()
	 * @see #getTareaWorkflow()
	 * @generated
	 */
	EAttribute getTareaWorkflow_Nombre_tarea();

	/**
	 * Returns the meta object for the attribute '{@link myBPMS.TareaWorkflow#getDescripcion <em>Descripcion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Descripcion</em>'.
	 * @see myBPMS.TareaWorkflow#getDescripcion()
	 * @see #getTareaWorkflow()
	 * @generated
	 */
	EAttribute getTareaWorkflow_Descripcion();

	/**
	 * Returns the meta object for class '{@link myBPMS.Fichero <em>Fichero</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Fichero</em>'.
	 * @see myBPMS.Fichero
	 * @generated
	 */
	EClass getFichero();

	/**
	 * Returns the meta object for the attribute '{@link myBPMS.Fichero#getId_fichero <em>Id fichero</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id fichero</em>'.
	 * @see myBPMS.Fichero#getId_fichero()
	 * @see #getFichero()
	 * @generated
	 */
	EAttribute getFichero_Id_fichero();

	/**
	 * Returns the meta object for enum '{@link myBPMS.Tipo_atributo <em>Tipo atributo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Tipo atributo</em>'.
	 * @see myBPMS.Tipo_atributo
	 * @generated
	 */
	EEnum getTipo_atributo();

	/**
	 * Returns the meta object for enum '{@link myBPMS.Tipo_codificacion <em>Tipo codificacion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Tipo codificacion</em>'.
	 * @see myBPMS.Tipo_codificacion
	 * @generated
	 */
	EEnum getTipo_codificacion();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	MyBPMSFactory getMyBPMSFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link myBPMS.impl.ProcesoDeNegocioImpl <em>Proceso De Negocio</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.ProcesoDeNegocioImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getProcesoDeNegocio()
		 * @generated
		 */
		EClass PROCESO_DE_NEGOCIO = eINSTANCE.getProcesoDeNegocio();

		/**
		 * The meta object literal for the '<em><b>Actores</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESO_DE_NEGOCIO__ACTORES = eINSTANCE.getProcesoDeNegocio_Actores();

		/**
		 * The meta object literal for the '<em><b>Id proceso</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROCESO_DE_NEGOCIO__ID_PROCESO = eINSTANCE.getProcesoDeNegocio_Id_proceso();

		/**
		 * The meta object literal for the '<em><b>Basesdedatos</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESO_DE_NEGOCIO__BASESDEDATOS = eINSTANCE.getProcesoDeNegocio_Basesdedatos();

		/**
		 * The meta object literal for the '{@link myBPMS.impl.ActorImpl <em>Actor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.ActorImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getActor()
		 * @generated
		 */
		EClass ACTOR = eINSTANCE.getActor();

		/**
		 * The meta object literal for the '<em><b>Id actor</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTOR__ID_ACTOR = eINSTANCE.getActor_Id_actor();

		/**
		 * The meta object literal for the '<em><b>Num tareas</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTOR__NUM_TAREAS = eINSTANCE.getActor_Num_tareas();

		/**
		 * The meta object literal for the '<em><b>Tareas</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTOR__TAREAS = eINSTANCE.getActor_Tareas();

		/**
		 * The meta object literal for the '<em><b>Ficheros</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTOR__FICHEROS = eINSTANCE.getActor_Ficheros();

		/**
		 * The meta object literal for the '{@link myBPMS.impl.TareaInicioImpl <em>Tarea Inicio</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.TareaInicioImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaInicio()
		 * @generated
		 */
		EClass TAREA_INICIO = eINSTANCE.getTareaInicio();

		/**
		 * The meta object literal for the '{@link myBPMS.impl.TareaFinImpl <em>Tarea Fin</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.TareaFinImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaFin()
		 * @generated
		 */
		EClass TAREA_FIN = eINSTANCE.getTareaFin();

		/**
		 * The meta object literal for the '{@link myBPMS.impl.TareaImpl <em>Tarea</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.TareaImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getTarea()
		 * @generated
		 */
		EClass TAREA = eINSTANCE.getTarea();

		/**
		 * The meta object literal for the '<em><b>Predecesor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAREA__PREDECESOR = eINSTANCE.getTarea_Predecesor();

		/**
		 * The meta object literal for the '<em><b>Sucesor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAREA__SUCESOR = eINSTANCE.getTarea_Sucesor();

		/**
		 * The meta object literal for the '{@link myBPMS.impl.TareaUsuarioImpl <em>Tarea Usuario</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.TareaUsuarioImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaUsuario()
		 * @generated
		 */
		EClass TAREA_USUARIO = eINSTANCE.getTareaUsuario();

		/**
		 * The meta object literal for the '<em><b>Formularios</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAREA_USUARIO__FORMULARIOS = eINSTANCE.getTareaUsuario_Formularios();

		/**
		 * The meta object literal for the '{@link myBPMS.impl.TareaServicioImpl <em>Tarea Servicio</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.TareaServicioImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaServicio()
		 * @generated
		 */
		EClass TAREA_SERVICIO = eINSTANCE.getTareaServicio();

		/**
		 * The meta object literal for the '<em><b>Servicio</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAREA_SERVICIO__SERVICIO = eINSTANCE.getTareaServicio_Servicio();

		/**
		 * The meta object literal for the '<em><b>Usa</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAREA_SERVICIO__USA = eINSTANCE.getTareaServicio_Usa();

		/**
		 * The meta object literal for the '<em><b>Genera</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAREA_SERVICIO__GENERA = eINSTANCE.getTareaServicio_Genera();

		/**
		 * The meta object literal for the '{@link myBPMS.impl.TareaEnvioMsjImpl <em>Tarea Envio Msj</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.TareaEnvioMsjImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaEnvioMsj()
		 * @generated
		 */
		EClass TAREA_ENVIO_MSJ = eINSTANCE.getTareaEnvioMsj();

		/**
		 * The meta object literal for the '<em><b>Envio msj</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAREA_ENVIO_MSJ__ENVIO_MSJ = eINSTANCE.getTareaEnvioMsj_Envio_msj();

		/**
		 * The meta object literal for the '<em><b>Codificacion</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TAREA_ENVIO_MSJ__CODIFICACION = eINSTANCE.getTareaEnvioMsj_Codificacion();

		/**
		 * The meta object literal for the '<em><b>Adjunta</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAREA_ENVIO_MSJ__ADJUNTA = eINSTANCE.getTareaEnvioMsj_Adjunta();

		/**
		 * The meta object literal for the '{@link myBPMS.impl.TareaRecepMsjImpl <em>Tarea Recep Msj</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.TareaRecepMsjImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaRecepMsj()
		 * @generated
		 */
		EClass TAREA_RECEP_MSJ = eINSTANCE.getTareaRecepMsj();

		/**
		 * The meta object literal for the '<em><b>Recepcion msj</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAREA_RECEP_MSJ__RECEPCION_MSJ = eINSTANCE.getTareaRecepMsj_Recepcion_msj();

		/**
		 * The meta object literal for the '<em><b>Codificacion</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TAREA_RECEP_MSJ__CODIFICACION = eINSTANCE.getTareaRecepMsj_Codificacion();

		/**
		 * The meta object literal for the '{@link myBPMS.impl.TareaConsultaImpl <em>Tarea Consulta</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.TareaConsultaImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaConsulta()
		 * @generated
		 */
		EClass TAREA_CONSULTA = eINSTANCE.getTareaConsulta();

		/**
		 * The meta object literal for the '<em><b>Consultar atributo</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAREA_CONSULTA__CONSULTAR_ATRIBUTO = eINSTANCE.getTareaConsulta_Consultar_atributo();

		/**
		 * The meta object literal for the '{@link myBPMS.impl.TareaBorradoImpl <em>Tarea Borrado</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.TareaBorradoImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaBorrado()
		 * @generated
		 */
		EClass TAREA_BORRADO = eINSTANCE.getTareaBorrado();

		/**
		 * The meta object literal for the '<em><b>Borrar atributo</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAREA_BORRADO__BORRAR_ATRIBUTO = eINSTANCE.getTareaBorrado_Borrar_atributo();

		/**
		 * The meta object literal for the '{@link myBPMS.impl.BaseDeDatosImpl <em>Base De Datos</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.BaseDeDatosImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getBaseDeDatos()
		 * @generated
		 */
		EClass BASE_DE_DATOS = eINSTANCE.getBaseDeDatos();

		/**
		 * The meta object literal for the '<em><b>Tablas</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BASE_DE_DATOS__TABLAS = eINSTANCE.getBaseDeDatos_Tablas();

		/**
		 * The meta object literal for the '<em><b>Id basedatos</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASE_DE_DATOS__ID_BASEDATOS = eINSTANCE.getBaseDeDatos_Id_basedatos();

		/**
		 * The meta object literal for the '{@link myBPMS.impl.TablaImpl <em>Tabla</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.TablaImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getTabla()
		 * @generated
		 */
		EClass TABLA = eINSTANCE.getTabla();

		/**
		 * The meta object literal for the '<em><b>Atributos</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TABLA__ATRIBUTOS = eINSTANCE.getTabla_Atributos();

		/**
		 * The meta object literal for the '<em><b>Id tabla</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TABLA__ID_TABLA = eINSTANCE.getTabla_Id_tabla();

		/**
		 * The meta object literal for the '{@link myBPMS.impl.AtributoImpl <em>Atributo</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.AtributoImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getAtributo()
		 * @generated
		 */
		EClass ATRIBUTO = eINSTANCE.getAtributo();

		/**
		 * The meta object literal for the '<em><b>Id atributo</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATRIBUTO__ID_ATRIBUTO = eINSTANCE.getAtributo_Id_atributo();

		/**
		 * The meta object literal for the '<em><b>Tipo atributo</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATRIBUTO__TIPO_ATRIBUTO = eINSTANCE.getAtributo_Tipo_atributo();

		/**
		 * The meta object literal for the '<em><b>Clave ajena</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATRIBUTO__CLAVE_AJENA = eINSTANCE.getAtributo_Clave_ajena();

		/**
		 * The meta object literal for the '<em><b>Visible</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATRIBUTO__VISIBLE = eINSTANCE.getAtributo_Visible();

		/**
		 * The meta object literal for the '<em><b>Clave primaria</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATRIBUTO__CLAVE_PRIMARIA = eINSTANCE.getAtributo_Clave_primaria();

		/**
		 * The meta object literal for the '{@link myBPMS.impl.TareaWorkflowImpl <em>Tarea Workflow</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.TareaWorkflowImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getTareaWorkflow()
		 * @generated
		 */
		EClass TAREA_WORKFLOW = eINSTANCE.getTareaWorkflow();

		/**
		 * The meta object literal for the '<em><b>Id tareaworkflow</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TAREA_WORKFLOW__ID_TAREAWORKFLOW = eINSTANCE.getTareaWorkflow_Id_tareaworkflow();

		/**
		 * The meta object literal for the '<em><b>Nombre tarea</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TAREA_WORKFLOW__NOMBRE_TAREA = eINSTANCE.getTareaWorkflow_Nombre_tarea();

		/**
		 * The meta object literal for the '<em><b>Descripcion</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TAREA_WORKFLOW__DESCRIPCION = eINSTANCE.getTareaWorkflow_Descripcion();

		/**
		 * The meta object literal for the '{@link myBPMS.impl.FicheroImpl <em>Fichero</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.impl.FicheroImpl
		 * @see myBPMS.impl.MyBPMSPackageImpl#getFichero()
		 * @generated
		 */
		EClass FICHERO = eINSTANCE.getFichero();

		/**
		 * The meta object literal for the '<em><b>Id fichero</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FICHERO__ID_FICHERO = eINSTANCE.getFichero_Id_fichero();

		/**
		 * The meta object literal for the '{@link myBPMS.Tipo_atributo <em>Tipo atributo</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.Tipo_atributo
		 * @see myBPMS.impl.MyBPMSPackageImpl#getTipo_atributo()
		 * @generated
		 */
		EEnum TIPO_ATRIBUTO = eINSTANCE.getTipo_atributo();

		/**
		 * The meta object literal for the '{@link myBPMS.Tipo_codificacion <em>Tipo codificacion</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see myBPMS.Tipo_codificacion
		 * @see myBPMS.impl.MyBPMSPackageImpl#getTipo_codificacion()
		 * @generated
		 */
		EEnum TIPO_CODIFICACION = eINSTANCE.getTipo_codificacion();

	}

} //MyBPMSPackage

/**
 */
package myBPMS;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tarea Recep Msj</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.TareaRecepMsj#getRecepcion_msj <em>Recepcion msj</em>}</li>
 *   <li>{@link myBPMS.TareaRecepMsj#getCodificacion <em>Codificacion</em>}</li>
 * </ul>
 *
 * @see myBPMS.MyBPMSPackage#getTareaRecepMsj()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='r7 r8trs r8trp'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot r7='self.predecesor->selectByKind(TareaEnvioMsj)->size() = 1' r8trs='self.oclContainer().oclAsType(Actor).id_actor = self.sucesor.oclContainer().oclAsType(Actor).id_actor' r8trp='self.oclContainer().oclAsType(Actor).id_actor <> self.predecesor.oclContainer().oclAsType(Actor).id_actor'"
 *        annotation="gmf.node label='id_tareaworkflow' color='4,46,255' figure='rectangle'"
 * @generated
 */
public interface TareaRecepMsj extends TareaWorkflow {
	/**
	 * Returns the value of the '<em><b>Recepcion msj</b></em>' reference list.
	 * The list contents are of type {@link myBPMS.Tabla}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Recepcion msj</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Recepcion msj</em>' reference list.
	 * @see myBPMS.MyBPMSPackage#getTareaRecepMsj_Recepcion_msj()
	 * @model required="true"
	 *        annotation="gmf.link target='recepcion_msj' target.decoration='square' style='dash'"
	 * @generated
	 */
	EList<Tabla> getRecepcion_msj();

	/**
	 * Returns the value of the '<em><b>Codificacion</b></em>' attribute.
	 * The literals are from the enumeration {@link myBPMS.Tipo_codificacion}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Codificacion</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Codificacion</em>' attribute.
	 * @see myBPMS.Tipo_codificacion
	 * @see #setCodificacion(Tipo_codificacion)
	 * @see myBPMS.MyBPMSPackage#getTareaRecepMsj_Codificacion()
	 * @model
	 * @generated
	 */
	Tipo_codificacion getCodificacion();

	/**
	 * Sets the value of the '{@link myBPMS.TareaRecepMsj#getCodificacion <em>Codificacion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Codificacion</em>' attribute.
	 * @see myBPMS.Tipo_codificacion
	 * @see #getCodificacion()
	 * @generated
	 */
	void setCodificacion(Tipo_codificacion value);

} // TareaRecepMsj

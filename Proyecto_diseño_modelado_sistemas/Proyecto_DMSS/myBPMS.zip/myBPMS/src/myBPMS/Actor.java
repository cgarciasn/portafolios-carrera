/**
 */
package myBPMS;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Actor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link myBPMS.Actor#getId_actor <em>Id actor</em>}</li>
 *   <li>{@link myBPMS.Actor#getNum_tareas <em>Num tareas</em>}</li>
 *   <li>{@link myBPMS.Actor#getTareas <em>Tareas</em>}</li>
 *   <li>{@link myBPMS.Actor#getFicheros <em>Ficheros</em>}</li>
 * </ul>
 *
 * @see myBPMS.MyBPMSPackage#getActor()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='r5'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot r5='self.tareas->selectByKind(TareaWorkflow)->size() >=1'"
 *        annotation="gmf.node label='id_actor' color='182,44,44' figure='rectangle'"
 * @generated
 */
public interface Actor extends EObject {
	/**
	 * Returns the value of the '<em><b>Id actor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id actor</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id actor</em>' attribute.
	 * @see #setId_actor(String)
	 * @see myBPMS.MyBPMSPackage#getActor_Id_actor()
	 * @model required="true"
	 * @generated
	 */
	String getId_actor();

	/**
	 * Sets the value of the '{@link myBPMS.Actor#getId_actor <em>Id actor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id actor</em>' attribute.
	 * @see #getId_actor()
	 * @generated
	 */
	void setId_actor(String value);

	/**
	 * Returns the value of the '<em><b>Num tareas</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Num tareas</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Num tareas</em>' attribute.
	 * @see #setNum_tareas(int)
	 * @see myBPMS.MyBPMSPackage#getActor_Num_tareas()
	 * @model required="true" transient="true" volatile="true" derived="true"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot derivation='self.tareas->size()'"
	 * @generated
	 */
	int getNum_tareas();

	/**
	 * Sets the value of the '{@link myBPMS.Actor#getNum_tareas <em>Num tareas</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Num tareas</em>' attribute.
	 * @see #getNum_tareas()
	 * @generated
	 */
	void setNum_tareas(int value);

	/**
	 * Returns the value of the '<em><b>Tareas</b></em>' containment reference list.
	 * The list contents are of type {@link myBPMS.Tarea}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tareas</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tareas</em>' containment reference list.
	 * @see myBPMS.MyBPMSPackage#getActor_Tareas()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Tarea> getTareas();

	/**
	 * Returns the value of the '<em><b>Ficheros</b></em>' containment reference list.
	 * The list contents are of type {@link myBPMS.Fichero}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ficheros</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ficheros</em>' containment reference list.
	 * @see myBPMS.MyBPMSPackage#getActor_Ficheros()
	 * @model containment="true"
	 * @generated
	 */
	EList<Fichero> getFicheros();

} // Actor

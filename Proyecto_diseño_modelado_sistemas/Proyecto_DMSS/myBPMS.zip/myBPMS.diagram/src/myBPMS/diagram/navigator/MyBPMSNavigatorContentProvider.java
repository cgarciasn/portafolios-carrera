/*
* 
*/
package myBPMS.diagram.navigator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.edit.domain.AdapterFactoryEditingDomain;
import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.emf.workspace.util.WorkspaceSynchronizer;
import org.eclipse.gmf.runtime.emf.core.GMFEditingDomainFactory;
import org.eclipse.gmf.runtime.notation.Diagram;
import org.eclipse.gmf.runtime.notation.Edge;
import org.eclipse.gmf.runtime.notation.Node;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonContentProvider;

/**
 * @generated
 */
public class MyBPMSNavigatorContentProvider implements ICommonContentProvider {

	/**
	* @generated
	*/
	private static final Object[] EMPTY_ARRAY = new Object[0];

	/**
	* @generated
	*/
	private Viewer myViewer;

	/**
	* @generated
	*/
	private AdapterFactoryEditingDomain myEditingDomain;

	/**
	* @generated
	*/
	private WorkspaceSynchronizer myWorkspaceSynchronizer;

	/**
	* @generated
	*/
	private Runnable myViewerRefreshRunnable;

	/**
	* @generated
	*/
	@SuppressWarnings({ "unchecked", "serial", "rawtypes" })
	public MyBPMSNavigatorContentProvider() {
		TransactionalEditingDomain editingDomain = GMFEditingDomainFactory.INSTANCE.createEditingDomain();
		myEditingDomain = (AdapterFactoryEditingDomain) editingDomain;
		myEditingDomain.setResourceToReadOnlyMap(new HashMap() {
			public Object get(Object key) {
				if (!containsKey(key)) {
					put(key, Boolean.TRUE);
				}
				return super.get(key);
			}
		});
		myViewerRefreshRunnable = new Runnable() {
			public void run() {
				if (myViewer != null) {
					myViewer.refresh();
				}
			}
		};
		myWorkspaceSynchronizer = new WorkspaceSynchronizer(editingDomain, new WorkspaceSynchronizer.Delegate() {
			public void dispose() {
			}

			public boolean handleResourceChanged(final Resource resource) {
				unloadAllResources();
				asyncRefresh();
				return true;
			}

			public boolean handleResourceDeleted(Resource resource) {
				unloadAllResources();
				asyncRefresh();
				return true;
			}

			public boolean handleResourceMoved(Resource resource, final URI newURI) {
				unloadAllResources();
				asyncRefresh();
				return true;
			}
		});
	}

	/**
	* @generated
	*/
	public void dispose() {
		myWorkspaceSynchronizer.dispose();
		myWorkspaceSynchronizer = null;
		myViewerRefreshRunnable = null;
		myViewer = null;
		unloadAllResources();
		((TransactionalEditingDomain) myEditingDomain).dispose();
		myEditingDomain = null;
	}

	/**
	* @generated
	*/
	public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
		myViewer = viewer;
	}

	/**
	* @generated
	*/
	void unloadAllResources() {
		for (Resource nextResource : myEditingDomain.getResourceSet().getResources()) {
			nextResource.unload();
		}
	}

	/**
	* @generated
	*/
	void asyncRefresh() {
		if (myViewer != null && !myViewer.getControl().isDisposed()) {
			myViewer.getControl().getDisplay().asyncExec(myViewerRefreshRunnable);
		}
	}

	/**
	* @generated
	*/
	public Object[] getElements(Object inputElement) {
		return getChildren(inputElement);
	}

	/**
	* @generated
	*/
	public void restoreState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public void saveState(IMemento aMemento) {
	}

	/**
	* @generated
	*/
	public void init(ICommonContentExtensionSite aConfig) {
	}

	/**
	* @generated
	*/
	public Object[] getChildren(Object parentElement) {
		if (parentElement instanceof IFile) {
			IFile file = (IFile) parentElement;
			URI fileURI = URI.createPlatformResourceURI(file.getFullPath().toString(), true);
			Resource resource = myEditingDomain.getResourceSet().getResource(fileURI, true);
			ArrayList<myBPMS.diagram.navigator.MyBPMSNavigatorItem> result = new ArrayList<myBPMS.diagram.navigator.MyBPMSNavigatorItem>();
			ArrayList<View> topViews = new ArrayList<View>(resource.getContents().size());
			for (EObject o : resource.getContents()) {
				if (o instanceof View) {
					topViews.add((View) o);
				}
			}
			result.addAll(createNavigatorItems(
					selectViewsByType(topViews, myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.MODEL_ID), file,
					false));
			return result.toArray();
		}

		if (parentElement instanceof myBPMS.diagram.navigator.MyBPMSNavigatorGroup) {
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup group = (myBPMS.diagram.navigator.MyBPMSNavigatorGroup) parentElement;
			return group.getChildren();
		}

		if (parentElement instanceof myBPMS.diagram.navigator.MyBPMSNavigatorItem) {
			myBPMS.diagram.navigator.MyBPMSNavigatorItem navigatorItem = (myBPMS.diagram.navigator.MyBPMSNavigatorItem) parentElement;
			if (navigatorItem.isLeaf() || !isOwnView(navigatorItem.getView())) {
				return EMPTY_ARRAY;
			}
			return getViewChildren(navigatorItem.getView(), parentElement);
		}

		/*
		* Due to plugin.xml restrictions this code will be called only for views representing
		* shortcuts to this diagram elements created on other diagrams. 
		*/
		if (parentElement instanceof IAdaptable) {
			View view = (View) ((IAdaptable) parentElement).getAdapter(View.class);
			if (view != null) {
				return getViewChildren(view, parentElement);
			}
		}

		return EMPTY_ARRAY;
	}

	/**
	* @generated
	*/
	private Object[] getViewChildren(View view, Object parentElement) {
		switch (myBPMS.diagram.part.MyBPMSVisualIDRegistry.getVisualID(view)) {

		case myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			result.addAll(getForeignShortcuts((Diagram) view, parentElement));
			Diagram sv = (Diagram) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup links = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_ProcesoDeNegocio_1000_links,
					"icons/linksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getChildrenByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.ActorEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.BaseDeDatosEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaUsuarioFormulariosEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaServicioServicioEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaServicioUsaEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaServicioGeneraEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaEnvioMsjEnvio_msjEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaEnvioMsjAdjuntaEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaRecepMsjRecepcion_msjEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaConsultaConsultar_atributoEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaBorradoBorrar_atributoEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.AtributoClave_ajenaEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.AtributoClave_primariaEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			if (!links.isEmpty()) {
				result.add(links);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.ActorEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Node sv = (Node) view;
			Collection<View> connectedViews;
			connectedViews = getChildrenByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.ActorActorTareasCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.ActorActorTareasCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.ActorActorTareasCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.ActorActorTareasCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.ActorActorTareasCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.ActorActorTareasCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.ActorActorTareasCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaInicioEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.ActorActorTareasCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaFinEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.ActorActorFicherosCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.BaseDeDatosEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Node sv = (Node) view;
			Collection<View> connectedViews;
			connectedViews = getChildrenByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.BaseDeDatosBaseDeDatosTablasCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Node sv = (Node) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup incominglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaUsuario_3001_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup outgoinglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaUsuario_3001_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaUsuarioFormulariosEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Node sv = (Node) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup incominglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaServicio_3002_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup outgoinglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaServicio_3002_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaServicioServicioEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaServicioUsaEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaServicioGeneraEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Node sv = (Node) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup incominglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaEnvioMsj_3003_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup outgoinglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaEnvioMsj_3003_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaEnvioMsjEnvio_msjEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaEnvioMsjAdjuntaEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Node sv = (Node) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup incominglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaRecepMsj_3004_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup outgoinglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaRecepMsj_3004_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaRecepMsjRecepcion_msjEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Node sv = (Node) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup incominglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaConsulta_3005_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup outgoinglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaConsulta_3005_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaConsultaConsultar_atributoEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Node sv = (Node) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup incominglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaBorrado_3006_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup outgoinglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaBorrado_3006_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaBorradoBorrar_atributoEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaInicioEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Node sv = (Node) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup incominglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaInicio_3007_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup outgoinglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaInicio_3007_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaFinEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Node sv = (Node) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup incominglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaFin_3008_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup outgoinglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaFin_3008_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Node sv = (Node) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup incominglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_Fichero_3009_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaServicioUsaEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaServicioGeneraEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaEnvioMsjAdjuntaEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Node sv = (Node) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup incominglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_Tabla_3010_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getChildrenByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TablaTablaAtributosCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaUsuarioFormulariosEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaServicioServicioEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaEnvioMsjEnvio_msjEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaRecepMsjRecepcion_msjEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.AtributoClave_ajenaEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.AtributoClave_primariaEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Node sv = (Node) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup incominglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_Atributo_3011_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup outgoinglinks = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_Atributo_3011_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaConsultaConsultar_atributoEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.TareaBorradoBorrar_atributoEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.AtributoClave_ajenaEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					myBPMS.diagram.part.MyBPMSVisualIDRegistry
							.getType(myBPMS.diagram.edit.parts.AtributoClave_primariaEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaUsuarioFormulariosEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup target = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaUsuarioFormularios_4003_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup source = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaUsuarioFormularios_4003_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaServicioServicioEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup target = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaServicioServicio_4004_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup source = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaServicioServicio_4004_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaServicioUsaEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup target = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaServicioUsa_4005_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup source = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaServicioUsa_4005_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaServicioGeneraEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup target = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaServicioGenera_4006_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup source = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaServicioGenera_4006_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaEnvioMsjEnvio_msjEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup target = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaEnvioMsjEnvio_msj_4007_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup source = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaEnvioMsjEnvio_msj_4007_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaEnvioMsjAdjuntaEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup target = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaEnvioMsjAdjunta_4008_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup source = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaEnvioMsjAdjunta_4008_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaRecepMsjRecepcion_msjEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup target = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaRecepMsjRecepcion_msj_4009_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup source = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaRecepMsjRecepcion_msj_4009_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaConsultaConsultar_atributoEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup target = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaConsultaConsultar_atributo_4010_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup source = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaConsultaConsultar_atributo_4010_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaBorradoBorrar_atributoEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup target = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaBorradoBorrar_atributo_4011_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup source = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaBorradoBorrar_atributo_4011_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.AtributoClave_ajenaEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup target = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_AtributoClave_ajena_4012_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup source = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_AtributoClave_ajena_4012_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.AtributoClave_primariaEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup target = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_AtributoClave_primaria_4013_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup source = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_AtributoClave_primaria_4013_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID: {
			LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem> result = new LinkedList<myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup target = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaSucesor_4015_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup source = new myBPMS.diagram.navigator.MyBPMSNavigatorGroup(
					myBPMS.diagram.part.Messages.NavigatorGroupName_TareaSucesor_4015_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaInicioEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaFinEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaInicioEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv), myBPMS.diagram.part.MyBPMSVisualIDRegistry
					.getType(myBPMS.diagram.edit.parts.TareaFinEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}
		}
		return EMPTY_ARRAY;
	}

	/**
	* @generated
	*/
	private Collection<View> getLinksSourceByType(Collection<Edge> edges, String type) {
		LinkedList<View> result = new LinkedList<View>();
		for (Edge nextEdge : edges) {
			View nextEdgeSource = nextEdge.getSource();
			if (type.equals(nextEdgeSource.getType()) && isOwnView(nextEdgeSource)) {
				result.add(nextEdgeSource);
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<View> getLinksTargetByType(Collection<Edge> edges, String type) {
		LinkedList<View> result = new LinkedList<View>();
		for (Edge nextEdge : edges) {
			View nextEdgeTarget = nextEdge.getTarget();
			if (type.equals(nextEdgeTarget.getType()) && isOwnView(nextEdgeTarget)) {
				result.add(nextEdgeTarget);
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<View> getOutgoingLinksByType(Collection<? extends View> nodes, String type) {
		LinkedList<View> result = new LinkedList<View>();
		for (View nextNode : nodes) {
			result.addAll(selectViewsByType(nextNode.getSourceEdges(), type));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<View> getIncomingLinksByType(Collection<? extends View> nodes, String type) {
		LinkedList<View> result = new LinkedList<View>();
		for (View nextNode : nodes) {
			result.addAll(selectViewsByType(nextNode.getTargetEdges(), type));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<View> getChildrenByType(Collection<? extends View> nodes, String type) {
		LinkedList<View> result = new LinkedList<View>();
		for (View nextNode : nodes) {
			result.addAll(selectViewsByType(nextNode.getChildren(), type));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<View> getDiagramLinksByType(Collection<Diagram> diagrams, String type) {
		ArrayList<View> result = new ArrayList<View>();
		for (Diagram nextDiagram : diagrams) {
			result.addAll(selectViewsByType(nextDiagram.getEdges(), type));
		}
		return result;
	}

	// TODO refactor as static method
	/**
	 * @generated
	 */
	private Collection<View> selectViewsByType(Collection<View> views, String type) {
		ArrayList<View> result = new ArrayList<View>();
		for (View nextView : views) {
			if (type.equals(nextView.getType()) && isOwnView(nextView)) {
				result.add(nextView);
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private boolean isOwnView(View view) {
		return myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.MODEL_ID
				.equals(myBPMS.diagram.part.MyBPMSVisualIDRegistry.getModelID(view));
	}

	/**
	 * @generated
	 */
	private Collection<myBPMS.diagram.navigator.MyBPMSNavigatorItem> createNavigatorItems(Collection<View> views,
			Object parent, boolean isLeafs) {
		ArrayList<myBPMS.diagram.navigator.MyBPMSNavigatorItem> result = new ArrayList<myBPMS.diagram.navigator.MyBPMSNavigatorItem>(
				views.size());
		for (View nextView : views) {
			result.add(new myBPMS.diagram.navigator.MyBPMSNavigatorItem(nextView, parent, isLeafs));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<myBPMS.diagram.navigator.MyBPMSNavigatorItem> getForeignShortcuts(Diagram diagram,
			Object parent) {
		LinkedList<View> result = new LinkedList<View>();
		for (Iterator<View> it = diagram.getChildren().iterator(); it.hasNext();) {
			View nextView = it.next();
			if (!isOwnView(nextView) && nextView.getEAnnotation("Shortcut") != null) { //$NON-NLS-1$
				result.add(nextView);
			}
		}
		return createNavigatorItems(result, parent, false);
	}

	/**
	* @generated
	*/
	public Object getParent(Object element) {
		if (element instanceof myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem) {
			myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem abstractNavigatorItem = (myBPMS.diagram.navigator.MyBPMSAbstractNavigatorItem) element;
			return abstractNavigatorItem.getParent();
		}
		return null;
	}

	/**
	* @generated
	*/
	public boolean hasChildren(Object element) {
		return element instanceof IFile || getChildren(element).length > 0;
	}

}

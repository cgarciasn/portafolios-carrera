/*
* 
*/
package myBPMS.diagram.navigator;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.common.ui.services.parser.CommonParserHint;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserOptions;
import org.eclipse.gmf.runtime.emf.core.util.EObjectAdapter;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.viewers.ITreePathLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.ViewerLabel;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonLabelProvider;

/**
 * @generated
 */
public class MyBPMSNavigatorLabelProvider extends LabelProvider
		implements ICommonLabelProvider, ITreePathLabelProvider {

	/**
	* @generated
	*/
	static {
		myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance().getImageRegistry().put("Navigator?UnknownElement", //$NON-NLS-1$
				ImageDescriptor.getMissingImageDescriptor());
		myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance().getImageRegistry().put("Navigator?ImageNotFound", //$NON-NLS-1$
				ImageDescriptor.getMissingImageDescriptor());
	}

	/**
	* @generated
	*/
	public void updateLabel(ViewerLabel label, TreePath elementPath) {
		Object element = elementPath.getLastSegment();
		if (element instanceof myBPMS.diagram.navigator.MyBPMSNavigatorItem
				&& !isOwnView(((myBPMS.diagram.navigator.MyBPMSNavigatorItem) element).getView())) {
			return;
		}
		label.setText(getText(element));
		label.setImage(getImage(element));
	}

	/**
	* @generated
	*/
	public Image getImage(Object element) {
		if (element instanceof myBPMS.diagram.navigator.MyBPMSNavigatorGroup) {
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup group = (myBPMS.diagram.navigator.MyBPMSNavigatorGroup) element;
			return myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance().getBundledImage(group.getIcon());
		}

		if (element instanceof myBPMS.diagram.navigator.MyBPMSNavigatorItem) {
			myBPMS.diagram.navigator.MyBPMSNavigatorItem navigatorItem = (myBPMS.diagram.navigator.MyBPMSNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return super.getImage(element);
			}
			return getImage(navigatorItem.getView());
		}

		// Due to plugin.xml content will be called only for "own" views
		if (element instanceof IAdaptable) {
			View view = (View) ((IAdaptable) element).getAdapter(View.class);
			if (view != null && isOwnView(view)) {
				return getImage(view);
			}
		}

		return super.getImage(element);
	}

	/**
	* @generated
	*/
	public Image getImage(View view) {
		switch (myBPMS.diagram.part.MyBPMSVisualIDRegistry.getVisualID(view)) {
		case myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.VISUAL_ID:
			return getImage("Navigator?Diagram?http://www.example.org/myBPMS?ProcesoDeNegocio", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.ProcesoDeNegocio_1000);
		case myBPMS.diagram.edit.parts.ActorEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/myBPMS?Actor", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.Actor_2001);
		case myBPMS.diagram.edit.parts.BaseDeDatosEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/myBPMS?BaseDeDatos", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.BaseDeDatos_2002);
		case myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/myBPMS?TareaUsuario", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuario_3001);
		case myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/myBPMS?TareaServicio", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicio_3002);
		case myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/myBPMS?TareaEnvioMsj", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsj_3003);
		case myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/myBPMS?TareaRecepMsj", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsj_3004);
		case myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/myBPMS?TareaConsulta", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsulta_3005);
		case myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/myBPMS?TareaBorrado", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorrado_3006);
		case myBPMS.diagram.edit.parts.TareaInicioEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/myBPMS?TareaInicio", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaInicio_3007);
		case myBPMS.diagram.edit.parts.TareaFinEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/myBPMS?TareaFin", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaFin_3008);
		case myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/myBPMS?Fichero", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.Fichero_3009);
		case myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/myBPMS?Tabla", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.Tabla_3010);
		case myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/myBPMS?Atributo", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.Atributo_3011);
		case myBPMS.diagram.edit.parts.TareaUsuarioFormulariosEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/myBPMS?TareaUsuario?formularios", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuarioFormularios_4003);
		case myBPMS.diagram.edit.parts.TareaServicioServicioEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/myBPMS?TareaServicio?servicio", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioServicio_4004);
		case myBPMS.diagram.edit.parts.TareaServicioUsaEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/myBPMS?TareaServicio?usa", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioUsa_4005);
		case myBPMS.diagram.edit.parts.TareaServicioGeneraEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/myBPMS?TareaServicio?genera", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioGenera_4006);
		case myBPMS.diagram.edit.parts.TareaEnvioMsjEnvio_msjEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/myBPMS?TareaEnvioMsj?envio_msj", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjEnvio_msj_4007);
		case myBPMS.diagram.edit.parts.TareaEnvioMsjAdjuntaEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/myBPMS?TareaEnvioMsj?adjunta", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjAdjunta_4008);
		case myBPMS.diagram.edit.parts.TareaRecepMsjRecepcion_msjEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/myBPMS?TareaRecepMsj?recepcion_msj", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsjRecepcion_msj_4009);
		case myBPMS.diagram.edit.parts.TareaConsultaConsultar_atributoEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/myBPMS?TareaConsulta?consultar_atributo", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsultaConsultar_atributo_4010);
		case myBPMS.diagram.edit.parts.TareaBorradoBorrar_atributoEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/myBPMS?TareaBorrado?borrar_atributo", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorradoBorrar_atributo_4011);
		case myBPMS.diagram.edit.parts.AtributoClave_ajenaEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/myBPMS?Atributo?clave_ajena", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_ajena_4012);
		case myBPMS.diagram.edit.parts.AtributoClave_primariaEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/myBPMS?Atributo?clave_primaria", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_primaria_4013);
		case myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/myBPMS?Tarea?sucesor", //$NON-NLS-1$
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015);
		}
		return getImage("Navigator?UnknownElement", null); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Image getImage(String key, IElementType elementType) {
		ImageRegistry imageRegistry = myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance().getImageRegistry();
		Image image = imageRegistry.get(key);
		if (image == null && elementType != null
				&& myBPMS.diagram.providers.MyBPMSElementTypes.isKnownElementType(elementType)) {
			image = myBPMS.diagram.providers.MyBPMSElementTypes.getImage(elementType);
			imageRegistry.put(key, image);
		}

		if (image == null) {
			image = imageRegistry.get("Navigator?ImageNotFound"); //$NON-NLS-1$
			imageRegistry.put(key, image);
		}
		return image;
	}

	/**
	* @generated
	*/
	public String getText(Object element) {
		if (element instanceof myBPMS.diagram.navigator.MyBPMSNavigatorGroup) {
			myBPMS.diagram.navigator.MyBPMSNavigatorGroup group = (myBPMS.diagram.navigator.MyBPMSNavigatorGroup) element;
			return group.getGroupName();
		}

		if (element instanceof myBPMS.diagram.navigator.MyBPMSNavigatorItem) {
			myBPMS.diagram.navigator.MyBPMSNavigatorItem navigatorItem = (myBPMS.diagram.navigator.MyBPMSNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return null;
			}
			return getText(navigatorItem.getView());
		}

		// Due to plugin.xml content will be called only for "own" views
		if (element instanceof IAdaptable) {
			View view = (View) ((IAdaptable) element).getAdapter(View.class);
			if (view != null && isOwnView(view)) {
				return getText(view);
			}
		}

		return super.getText(element);
	}

	/**
	* @generated
	*/
	public String getText(View view) {
		if (view.getElement() != null && view.getElement().eIsProxy()) {
			return getUnresolvedDomainElementProxyText(view);
		}
		switch (myBPMS.diagram.part.MyBPMSVisualIDRegistry.getVisualID(view)) {
		case myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.VISUAL_ID:
			return getProcesoDeNegocio_1000Text(view);
		case myBPMS.diagram.edit.parts.ActorEditPart.VISUAL_ID:
			return getActor_2001Text(view);
		case myBPMS.diagram.edit.parts.BaseDeDatosEditPart.VISUAL_ID:
			return getBaseDeDatos_2002Text(view);
		case myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID:
			return getTareaUsuario_3001Text(view);
		case myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID:
			return getTareaServicio_3002Text(view);
		case myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID:
			return getTareaEnvioMsj_3003Text(view);
		case myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID:
			return getTareaRecepMsj_3004Text(view);
		case myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID:
			return getTareaConsulta_3005Text(view);
		case myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID:
			return getTareaBorrado_3006Text(view);
		case myBPMS.diagram.edit.parts.TareaInicioEditPart.VISUAL_ID:
			return getTareaInicio_3007Text(view);
		case myBPMS.diagram.edit.parts.TareaFinEditPart.VISUAL_ID:
			return getTareaFin_3008Text(view);
		case myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID:
			return getFichero_3009Text(view);
		case myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID:
			return getTabla_3010Text(view);
		case myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return getAtributo_3011Text(view);
		case myBPMS.diagram.edit.parts.TareaUsuarioFormulariosEditPart.VISUAL_ID:
			return getTareaUsuarioFormularios_4003Text(view);
		case myBPMS.diagram.edit.parts.TareaServicioServicioEditPart.VISUAL_ID:
			return getTareaServicioServicio_4004Text(view);
		case myBPMS.diagram.edit.parts.TareaServicioUsaEditPart.VISUAL_ID:
			return getTareaServicioUsa_4005Text(view);
		case myBPMS.diagram.edit.parts.TareaServicioGeneraEditPart.VISUAL_ID:
			return getTareaServicioGenera_4006Text(view);
		case myBPMS.diagram.edit.parts.TareaEnvioMsjEnvio_msjEditPart.VISUAL_ID:
			return getTareaEnvioMsjEnvio_msj_4007Text(view);
		case myBPMS.diagram.edit.parts.TareaEnvioMsjAdjuntaEditPart.VISUAL_ID:
			return getTareaEnvioMsjAdjunta_4008Text(view);
		case myBPMS.diagram.edit.parts.TareaRecepMsjRecepcion_msjEditPart.VISUAL_ID:
			return getTareaRecepMsjRecepcion_msj_4009Text(view);
		case myBPMS.diagram.edit.parts.TareaConsultaConsultar_atributoEditPart.VISUAL_ID:
			return getTareaConsultaConsultar_atributo_4010Text(view);
		case myBPMS.diagram.edit.parts.TareaBorradoBorrar_atributoEditPart.VISUAL_ID:
			return getTareaBorradoBorrar_atributo_4011Text(view);
		case myBPMS.diagram.edit.parts.AtributoClave_ajenaEditPart.VISUAL_ID:
			return getAtributoClave_ajena_4012Text(view);
		case myBPMS.diagram.edit.parts.AtributoClave_primariaEditPart.VISUAL_ID:
			return getAtributoClave_primaria_4013Text(view);
		case myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID:
			return getTareaSucesor_4015Text(view);
		}
		return getUnknownElementText(view);
	}

	/**
	* @generated
	*/
	private String getProcesoDeNegocio_1000Text(View view) {
		myBPMS.ProcesoDeNegocio domainModelElement = (myBPMS.ProcesoDeNegocio) view.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getId_proceso();
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("No domain element for view with visualID = " + 1000); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getActor_2001Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.Actor_2001,
				view.getElement() != null ? view.getElement() : view, myBPMS.diagram.part.MyBPMSVisualIDRegistry
						.getType(myBPMS.diagram.edit.parts.ActorId_actorEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5008); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getBaseDeDatos_2002Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.BaseDeDatos_2002,
				view.getElement() != null ? view.getElement() : view, myBPMS.diagram.part.MyBPMSVisualIDRegistry
						.getType(myBPMS.diagram.edit.parts.BaseDeDatosId_basedatosEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5011); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaUsuario_3001Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuario_3001,
				view.getElement() != null ? view.getElement() : view, myBPMS.diagram.part.MyBPMSVisualIDRegistry
						.getType(myBPMS.diagram.edit.parts.TareaUsuarioId_tareaworkflowEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaServicio_3002Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicio_3002,
				view.getElement() != null ? view.getElement() : view, myBPMS.diagram.part.MyBPMSVisualIDRegistry
						.getType(myBPMS.diagram.edit.parts.TareaServicioId_tareaworkflowEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaEnvioMsj_3003Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsj_3003,
				view.getElement() != null ? view.getElement() : view, myBPMS.diagram.part.MyBPMSVisualIDRegistry
						.getType(myBPMS.diagram.edit.parts.TareaEnvioMsjId_tareaworkflowEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaRecepMsj_3004Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsj_3004,
				view.getElement() != null ? view.getElement() : view, myBPMS.diagram.part.MyBPMSVisualIDRegistry
						.getType(myBPMS.diagram.edit.parts.TareaRecepMsjId_tareaworkflowEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaConsulta_3005Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsulta_3005,
				view.getElement() != null ? view.getElement() : view, myBPMS.diagram.part.MyBPMSVisualIDRegistry
						.getType(myBPMS.diagram.edit.parts.TareaConsultaId_tareaworkflowEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5005); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaBorrado_3006Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorrado_3006,
				view.getElement() != null ? view.getElement() : view, myBPMS.diagram.part.MyBPMSVisualIDRegistry
						.getType(myBPMS.diagram.edit.parts.TareaBorradoId_tareaworkflowEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5006); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaInicio_3007Text(View view) {
		return ""; //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private String getTareaFin_3008Text(View view) {
		return ""; //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private String getFichero_3009Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.Fichero_3009,
				view.getElement() != null ? view.getElement() : view, myBPMS.diagram.part.MyBPMSVisualIDRegistry
						.getType(myBPMS.diagram.edit.parts.FicheroId_ficheroEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5007); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTabla_3010Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.Tabla_3010,
				view.getElement() != null ? view.getElement() : view, myBPMS.diagram.part.MyBPMSVisualIDRegistry
						.getType(myBPMS.diagram.edit.parts.TablaId_tablaEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5010); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getAtributo_3011Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.Atributo_3011,
				view.getElement() != null ? view.getElement() : view, myBPMS.diagram.part.MyBPMSVisualIDRegistry
						.getType(myBPMS.diagram.edit.parts.AtributoId_atributoEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5009); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaUsuarioFormularios_4003Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuarioFormularios_4003,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaServicioServicio_4004Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioServicio_4004,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaServicioUsa_4005Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioUsa_4005,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6005); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaServicioGenera_4006Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioGenera_4006,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6006); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaEnvioMsjEnvio_msj_4007Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjEnvio_msj_4007,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6007); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaEnvioMsjAdjunta_4008Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjAdjunta_4008,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6008); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaRecepMsjRecepcion_msj_4009Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsjRecepcion_msj_4009,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6009); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaConsultaConsultar_atributo_4010Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsultaConsultar_atributo_4010,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6010); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaBorradoBorrar_atributo_4011Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorradoBorrar_atributo_4011,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6011); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getAtributoClave_ajena_4012Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_ajena_4012,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6012); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getAtributoClave_primaria_4013Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_primaria_4013,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6013); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTareaSucesor_4015Text(View view) {
		IParser parser = myBPMS.diagram.providers.MyBPMSParserProvider.getParser(
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6015); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getUnknownElementText(View view) {
		return "<UnknownElement Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	* @generated
	*/
	private String getUnresolvedDomainElementProxyText(View view) {
		return "<Unresolved domain element Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	* @generated
	*/
	public void init(ICommonContentExtensionSite aConfig) {
	}

	/**
	* @generated
	*/
	public void restoreState(IMemento aMemento) {
	}

	/**
	* @generated
	*/
	public void saveState(IMemento aMemento) {
	}

	/**
	* @generated
	*/
	public String getDescription(Object anElement) {
		return null;
	}

	/**
	* @generated
	*/
	private boolean isOwnView(View view) {
		return myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.MODEL_ID
				.equals(myBPMS.diagram.part.MyBPMSVisualIDRegistry.getModelID(view));
	}

}


/*
 * 
 */
package myBPMS.diagram.part;

import java.util.Collections;

import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteDrawer;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.tooling.runtime.part.DefaultLinkToolEntry;
import org.eclipse.gmf.tooling.runtime.part.DefaultNodeToolEntry;

/**
 * @generated
 */
public class MyBPMSPaletteFactory {

	/**
	* @generated
	*/
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createObjects1Group());
		paletteRoot.add(createConnections2Group());
	}

	/**
	* Creates "Objects" palette tool group
	* @generated
	*/
	private PaletteContainer createObjects1Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(myBPMS.diagram.part.Messages.Objects1Group_title);
		paletteContainer.setId("createObjects1Group"); //$NON-NLS-1$
		paletteContainer.add(createActor1CreationTool());
		paletteContainer.add(createAtributo2CreationTool());
		paletteContainer.add(createBaseDeDatos3CreationTool());
		paletteContainer.add(createFichero4CreationTool());
		paletteContainer.add(createTabla5CreationTool());
		paletteContainer.add(createTareaBorrado6CreationTool());
		paletteContainer.add(createTareaConsulta7CreationTool());
		paletteContainer.add(createTareaEnvioMsj8CreationTool());
		paletteContainer.add(createTareaFin9CreationTool());
		paletteContainer.add(createTareaInicio10CreationTool());
		paletteContainer.add(createTareaRecepMsj11CreationTool());
		paletteContainer.add(createTareaServicio12CreationTool());
		paletteContainer.add(createTareaUsuario13CreationTool());
		return paletteContainer;
	}

	/**
	* Creates "Connections" palette tool group
	* @generated
	*/
	private PaletteContainer createConnections2Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(myBPMS.diagram.part.Messages.Connections2Group_title);
		paletteContainer.setId("createConnections2Group"); //$NON-NLS-1$
		paletteContainer.add(createAdjunta1CreationTool());
		paletteContainer.add(createBorrar_atributo2CreationTool());
		paletteContainer.add(createClave_ajena3CreationTool());
		paletteContainer.add(createClave_primaria4CreationTool());
		paletteContainer.add(createConsultar_atributo5CreationTool());
		paletteContainer.add(createEnvio_msj6CreationTool());
		paletteContainer.add(createFormularios7CreationTool());
		paletteContainer.add(createGenera8CreationTool());
		paletteContainer.add(createRecepcion_msj9CreationTool());
		paletteContainer.add(createServicio10CreationTool());
		paletteContainer.add(createSucesor11CreationTool());
		paletteContainer.add(createUsa12CreationTool());
		return paletteContainer;
	}

	/**
	* @generated
	*/
	private ToolEntry createActor1CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(myBPMS.diagram.part.Messages.Actor1CreationTool_title,
				myBPMS.diagram.part.Messages.Actor1CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.Actor_2001));
		entry.setId("createActor1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.Actor_2001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createAtributo2CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(myBPMS.diagram.part.Messages.Atributo2CreationTool_title,
				myBPMS.diagram.part.Messages.Atributo2CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.Atributo_3011));
		entry.setId("createAtributo2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.Atributo_3011));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createBaseDeDatos3CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				myBPMS.diagram.part.Messages.BaseDeDatos3CreationTool_title,
				myBPMS.diagram.part.Messages.BaseDeDatos3CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.BaseDeDatos_2002));
		entry.setId("createBaseDeDatos3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.BaseDeDatos_2002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createFichero4CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(myBPMS.diagram.part.Messages.Fichero4CreationTool_title,
				myBPMS.diagram.part.Messages.Fichero4CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.Fichero_3009));
		entry.setId("createFichero4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.Fichero_3009));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTabla5CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(myBPMS.diagram.part.Messages.Tabla5CreationTool_title,
				myBPMS.diagram.part.Messages.Tabla5CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.Tabla_3010));
		entry.setId("createTabla5CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.Tabla_3010));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTareaBorrado6CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				myBPMS.diagram.part.Messages.TareaBorrado6CreationTool_title,
				myBPMS.diagram.part.Messages.TareaBorrado6CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorrado_3006));
		entry.setId("createTareaBorrado6CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorrado_3006));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTareaConsulta7CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				myBPMS.diagram.part.Messages.TareaConsulta7CreationTool_title,
				myBPMS.diagram.part.Messages.TareaConsulta7CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsulta_3005));
		entry.setId("createTareaConsulta7CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsulta_3005));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTareaEnvioMsj8CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				myBPMS.diagram.part.Messages.TareaEnvioMsj8CreationTool_title,
				myBPMS.diagram.part.Messages.TareaEnvioMsj8CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsj_3003));
		entry.setId("createTareaEnvioMsj8CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsj_3003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTareaFin9CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(myBPMS.diagram.part.Messages.TareaFin9CreationTool_title,
				myBPMS.diagram.part.Messages.TareaFin9CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaFin_3008));
		entry.setId("createTareaFin9CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaFin_3008));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTareaInicio10CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				myBPMS.diagram.part.Messages.TareaInicio10CreationTool_title,
				myBPMS.diagram.part.Messages.TareaInicio10CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaInicio_3007));
		entry.setId("createTareaInicio10CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaInicio_3007));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTareaRecepMsj11CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				myBPMS.diagram.part.Messages.TareaRecepMsj11CreationTool_title,
				myBPMS.diagram.part.Messages.TareaRecepMsj11CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsj_3004));
		entry.setId("createTareaRecepMsj11CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsj_3004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTareaServicio12CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				myBPMS.diagram.part.Messages.TareaServicio12CreationTool_title,
				myBPMS.diagram.part.Messages.TareaServicio12CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicio_3002));
		entry.setId("createTareaServicio12CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicio_3002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTareaUsuario13CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				myBPMS.diagram.part.Messages.TareaUsuario13CreationTool_title,
				myBPMS.diagram.part.Messages.TareaUsuario13CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuario_3001));
		entry.setId("createTareaUsuario13CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuario_3001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createAdjunta1CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(myBPMS.diagram.part.Messages.Adjunta1CreationTool_title,
				myBPMS.diagram.part.Messages.Adjunta1CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjAdjunta_4008));
		entry.setId("createAdjunta1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjAdjunta_4008));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createBorrar_atributo2CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				myBPMS.diagram.part.Messages.Borrar_atributo2CreationTool_title,
				myBPMS.diagram.part.Messages.Borrar_atributo2CreationTool_desc, Collections
						.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorradoBorrar_atributo_4011));
		entry.setId("createBorrar_atributo2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorradoBorrar_atributo_4011));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createClave_ajena3CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				myBPMS.diagram.part.Messages.Clave_ajena3CreationTool_title,
				myBPMS.diagram.part.Messages.Clave_ajena3CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_ajena_4012));
		entry.setId("createClave_ajena3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_ajena_4012));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createClave_primaria4CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				myBPMS.diagram.part.Messages.Clave_primaria4CreationTool_title,
				myBPMS.diagram.part.Messages.Clave_primaria4CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_primaria_4013));
		entry.setId("createClave_primaria4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_primaria_4013));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createConsultar_atributo5CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				myBPMS.diagram.part.Messages.Consultar_atributo5CreationTool_title,
				myBPMS.diagram.part.Messages.Consultar_atributo5CreationTool_desc, Collections.singletonList(
						myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsultaConsultar_atributo_4010));
		entry.setId("createConsultar_atributo5CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsultaConsultar_atributo_4010));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createEnvio_msj6CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(myBPMS.diagram.part.Messages.Envio_msj6CreationTool_title,
				myBPMS.diagram.part.Messages.Envio_msj6CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjEnvio_msj_4007));
		entry.setId("createEnvio_msj6CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjEnvio_msj_4007));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createFormularios7CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				myBPMS.diagram.part.Messages.Formularios7CreationTool_title,
				myBPMS.diagram.part.Messages.Formularios7CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuarioFormularios_4003));
		entry.setId("createFormularios7CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuarioFormularios_4003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createGenera8CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(myBPMS.diagram.part.Messages.Genera8CreationTool_title,
				myBPMS.diagram.part.Messages.Genera8CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioGenera_4006));
		entry.setId("createGenera8CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioGenera_4006));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createRecepcion_msj9CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				myBPMS.diagram.part.Messages.Recepcion_msj9CreationTool_title,
				myBPMS.diagram.part.Messages.Recepcion_msj9CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsjRecepcion_msj_4009));
		entry.setId("createRecepcion_msj9CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsjRecepcion_msj_4009));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createServicio10CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(myBPMS.diagram.part.Messages.Servicio10CreationTool_title,
				myBPMS.diagram.part.Messages.Servicio10CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioServicio_4004));
		entry.setId("createServicio10CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioServicio_4004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createSucesor11CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(myBPMS.diagram.part.Messages.Sucesor11CreationTool_title,
				myBPMS.diagram.part.Messages.Sucesor11CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015));
		entry.setId("createSucesor11CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createUsa12CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(myBPMS.diagram.part.Messages.Usa12CreationTool_title,
				myBPMS.diagram.part.Messages.Usa12CreationTool_desc,
				Collections.singletonList(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioUsa_4005));
		entry.setId("createUsa12CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(myBPMS.diagram.providers.MyBPMSElementTypes
				.getImageDescriptor(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioUsa_4005));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

}

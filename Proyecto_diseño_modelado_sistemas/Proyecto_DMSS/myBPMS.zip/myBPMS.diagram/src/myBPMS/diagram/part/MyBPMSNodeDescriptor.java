/*
* 
*/
package myBPMS.diagram.part;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.tooling.runtime.update.UpdaterNodeDescriptor;

/**
 * @generated
 */
public class MyBPMSNodeDescriptor extends UpdaterNodeDescriptor {
	/**
	* @generated
	*/
	public MyBPMSNodeDescriptor(EObject modelElement, int visualID) {
		super(modelElement, visualID);
	}

}

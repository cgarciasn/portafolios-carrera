/*
* 
*/
package myBPMS.diagram.part;

import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.notation.Diagram;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.structure.DiagramStructure;

/**
 * This registry is used to determine which type of visual object should be
 * created for the corresponding Diagram, Node, ChildNode or Link represented
 * by a domain model object.
 * 
 * @generated
 */
public class MyBPMSVisualIDRegistry {

	/**
	* @generated
	*/
	private static final String DEBUG_KEY = "myBPMS.diagram/debug/visualID"; //$NON-NLS-1$

	/**
	* @generated
	*/
	public static int getVisualID(View view) {
		if (view instanceof Diagram) {
			if (myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.MODEL_ID.equals(view.getType())) {
				return myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		return myBPMS.diagram.part.MyBPMSVisualIDRegistry.getVisualID(view.getType());
	}

	/**
	* @generated
	*/
	public static String getModelID(View view) {
		View diagram = view.getDiagram();
		while (view != diagram) {
			EAnnotation annotation = view.getEAnnotation("Shortcut"); //$NON-NLS-1$
			if (annotation != null) {
				return (String) annotation.getDetails().get("modelID"); //$NON-NLS-1$
			}
			view = (View) view.eContainer();
		}
		return diagram != null ? diagram.getType() : null;
	}

	/**
	* @generated
	*/
	public static int getVisualID(String type) {
		try {
			return Integer.parseInt(type);
		} catch (NumberFormatException e) {
			if (Boolean.TRUE.toString().equalsIgnoreCase(Platform.getDebugOption(DEBUG_KEY))) {
				myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance()
						.logError("Unable to parse view type as a visualID number: " + type);
			}
		}
		return -1;
	}

	/**
	* @generated
	*/
	public static String getType(int visualID) {
		return Integer.toString(visualID);
	}

	/**
	* @generated
	*/
	public static int getDiagramVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		if (myBPMS.MyBPMSPackage.eINSTANCE.getProcesoDeNegocio().isSuperTypeOf(domainElement.eClass())
				&& isDiagram((myBPMS.ProcesoDeNegocio) domainElement)) {
			return myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.VISUAL_ID;
		}
		return -1;
	}

	/**
	* @generated
	*/
	public static int getNodeVisualID(View containerView, EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		String containerModelID = myBPMS.diagram.part.MyBPMSVisualIDRegistry.getModelID(containerView);
		if (!myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.MODEL_ID.equals(containerModelID)
				&& !"myBPMS".equals(containerModelID)) { //$NON-NLS-1$
			return -1;
		}
		int containerVisualID;
		if (myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = myBPMS.diagram.part.MyBPMSVisualIDRegistry.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		switch (containerVisualID) {
		case myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.VISUAL_ID:
			if (myBPMS.MyBPMSPackage.eINSTANCE.getActor().isSuperTypeOf(domainElement.eClass())) {
				return myBPMS.diagram.edit.parts.ActorEditPart.VISUAL_ID;
			}
			if (myBPMS.MyBPMSPackage.eINSTANCE.getBaseDeDatos().isSuperTypeOf(domainElement.eClass())) {
				return myBPMS.diagram.edit.parts.BaseDeDatosEditPart.VISUAL_ID;
			}
			break;
		case myBPMS.diagram.edit.parts.ActorActorTareasCompartmentEditPart.VISUAL_ID:
			if (myBPMS.MyBPMSPackage.eINSTANCE.getTareaUsuario().isSuperTypeOf(domainElement.eClass())) {
				return myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID;
			}
			if (myBPMS.MyBPMSPackage.eINSTANCE.getTareaServicio().isSuperTypeOf(domainElement.eClass())) {
				return myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID;
			}
			if (myBPMS.MyBPMSPackage.eINSTANCE.getTareaEnvioMsj().isSuperTypeOf(domainElement.eClass())) {
				return myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID;
			}
			if (myBPMS.MyBPMSPackage.eINSTANCE.getTareaRecepMsj().isSuperTypeOf(domainElement.eClass())) {
				return myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID;
			}
			if (myBPMS.MyBPMSPackage.eINSTANCE.getTareaConsulta().isSuperTypeOf(domainElement.eClass())) {
				return myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID;
			}
			if (myBPMS.MyBPMSPackage.eINSTANCE.getTareaBorrado().isSuperTypeOf(domainElement.eClass())) {
				return myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID;
			}
			if (myBPMS.MyBPMSPackage.eINSTANCE.getTareaInicio().isSuperTypeOf(domainElement.eClass())) {
				return myBPMS.diagram.edit.parts.TareaInicioEditPart.VISUAL_ID;
			}
			if (myBPMS.MyBPMSPackage.eINSTANCE.getTareaFin().isSuperTypeOf(domainElement.eClass())) {
				return myBPMS.diagram.edit.parts.TareaFinEditPart.VISUAL_ID;
			}
			break;
		case myBPMS.diagram.edit.parts.ActorActorFicherosCompartmentEditPart.VISUAL_ID:
			if (myBPMS.MyBPMSPackage.eINSTANCE.getFichero().isSuperTypeOf(domainElement.eClass())) {
				return myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID;
			}
			break;
		case myBPMS.diagram.edit.parts.BaseDeDatosBaseDeDatosTablasCompartmentEditPart.VISUAL_ID:
			if (myBPMS.MyBPMSPackage.eINSTANCE.getTabla().isSuperTypeOf(domainElement.eClass())) {
				return myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID;
			}
			break;
		case myBPMS.diagram.edit.parts.TablaTablaAtributosCompartmentEditPart.VISUAL_ID:
			if (myBPMS.MyBPMSPackage.eINSTANCE.getAtributo().isSuperTypeOf(domainElement.eClass())) {
				return myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID;
			}
			break;
		}
		return -1;
	}

	/**
	* @generated
	*/
	public static boolean canCreateNode(View containerView, int nodeVisualID) {
		String containerModelID = myBPMS.diagram.part.MyBPMSVisualIDRegistry.getModelID(containerView);
		if (!myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.MODEL_ID.equals(containerModelID)
				&& !"myBPMS".equals(containerModelID)) { //$NON-NLS-1$
			return false;
		}
		int containerVisualID;
		if (myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = myBPMS.diagram.part.MyBPMSVisualIDRegistry.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.VISUAL_ID;
			} else {
				return false;
			}
		}
		switch (containerVisualID) {
		case myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.ActorEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (myBPMS.diagram.edit.parts.BaseDeDatosEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.ActorEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.ActorId_actorEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (myBPMS.diagram.edit.parts.ActorActorTareasCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (myBPMS.diagram.edit.parts.ActorActorFicherosCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.BaseDeDatosEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.BaseDeDatosId_basedatosEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (myBPMS.diagram.edit.parts.BaseDeDatosBaseDeDatosTablasCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.TareaUsuarioId_tareaworkflowEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.TareaServicioId_tareaworkflowEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.TareaEnvioMsjId_tareaworkflowEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.TareaRecepMsjId_tareaworkflowEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.TareaConsultaId_tareaworkflowEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.TareaBorradoId_tareaworkflowEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.FicheroId_ficheroEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.TablaId_tablaEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (myBPMS.diagram.edit.parts.TablaTablaAtributosCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.AtributoId_atributoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.ActorActorTareasCompartmentEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (myBPMS.diagram.edit.parts.TareaInicioEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (myBPMS.diagram.edit.parts.TareaFinEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.ActorActorFicherosCompartmentEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.BaseDeDatosBaseDeDatosTablasCompartmentEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TablaTablaAtributosCompartmentEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.WrappingLabelEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaUsuarioFormulariosEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.WrappingLabel2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaServicioServicioEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.WrappingLabel3EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaServicioUsaEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.WrappingLabel4EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaServicioGeneraEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.WrappingLabel5EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaEnvioMsjEnvio_msjEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.WrappingLabel6EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaEnvioMsjAdjuntaEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.WrappingLabel7EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaRecepMsjRecepcion_msjEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.WrappingLabel8EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaConsultaConsultar_atributoEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.WrappingLabel9EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.TareaBorradoBorrar_atributoEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.WrappingLabel10EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.AtributoClave_ajenaEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.WrappingLabel11EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case myBPMS.diagram.edit.parts.AtributoClave_primariaEditPart.VISUAL_ID:
			if (myBPMS.diagram.edit.parts.WrappingLabel12EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		}
		return false;
	}

	/**
	* @generated
	*/
	public static int getLinkWithClassVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		return -1;
	}

	/**
	* User can change implementation of this method to handle some specific
	* situations not covered by default logic.
	* 
	* @generated
	*/
	private static boolean isDiagram(myBPMS.ProcesoDeNegocio element) {
		return true;
	}

	/**
	* @generated
	*/
	public static boolean checkNodeVisualID(View containerView, EObject domainElement, int candidate) {
		if (candidate == -1) {
			//unrecognized id is always bad
			return false;
		}
		int basic = getNodeVisualID(containerView, domainElement);
		return basic == candidate;
	}

	/**
	* @generated
	*/
	public static boolean isCompartmentVisualID(int visualID) {
		switch (visualID) {
		case myBPMS.diagram.edit.parts.ActorActorTareasCompartmentEditPart.VISUAL_ID:
		case myBPMS.diagram.edit.parts.ActorActorFicherosCompartmentEditPart.VISUAL_ID:
		case myBPMS.diagram.edit.parts.BaseDeDatosBaseDeDatosTablasCompartmentEditPart.VISUAL_ID:
		case myBPMS.diagram.edit.parts.TablaTablaAtributosCompartmentEditPart.VISUAL_ID:
			return true;
		default:
			break;
		}
		return false;
	}

	/**
	* @generated
	*/
	public static boolean isSemanticLeafVisualID(int visualID) {
		switch (visualID) {
		case myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.VISUAL_ID:
			return false;
		case myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID:
		case myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID:
		case myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID:
		case myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID:
		case myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID:
		case myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID:
		case myBPMS.diagram.edit.parts.TareaInicioEditPart.VISUAL_ID:
		case myBPMS.diagram.edit.parts.TareaFinEditPart.VISUAL_ID:
		case myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID:
		case myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return true;
		default:
			break;
		}
		return false;
	}

	/**
	* @generated
	*/
	public static final DiagramStructure TYPED_INSTANCE = new DiagramStructure() {
		/**
		* @generated
		*/
		@Override

		public int getVisualID(View view) {
			return myBPMS.diagram.part.MyBPMSVisualIDRegistry.getVisualID(view);
		}

		/**
		* @generated
		*/
		@Override

		public String getModelID(View view) {
			return myBPMS.diagram.part.MyBPMSVisualIDRegistry.getModelID(view);
		}

		/**
		* @generated
		*/
		@Override

		public int getNodeVisualID(View containerView, EObject domainElement) {
			return myBPMS.diagram.part.MyBPMSVisualIDRegistry.getNodeVisualID(containerView, domainElement);
		}

		/**
		* @generated
		*/
		@Override

		public boolean checkNodeVisualID(View containerView, EObject domainElement, int candidate) {
			return myBPMS.diagram.part.MyBPMSVisualIDRegistry.checkNodeVisualID(containerView, domainElement,
					candidate);
		}

		/**
		* @generated
		*/
		@Override

		public boolean isCompartmentVisualID(int visualID) {
			return myBPMS.diagram.part.MyBPMSVisualIDRegistry.isCompartmentVisualID(visualID);
		}

		/**
		* @generated
		*/
		@Override

		public boolean isSemanticLeafVisualID(int visualID) {
			return myBPMS.diagram.part.MyBPMSVisualIDRegistry.isSemanticLeafVisualID(visualID);
		}
	};

}

/*
 * 
 */
package myBPMS.diagram.part;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.actions.WorkspaceModifyOperation;

/**
 * @generated
 */
public class MyBPMSCreationWizard extends Wizard implements INewWizard {

	/**
	* @generated
	*/
	private IWorkbench workbench;

	/**
	* @generated
	*/
	protected IStructuredSelection selection;

	/**
	* @generated
	*/
	protected myBPMS.diagram.part.MyBPMSCreationWizardPage diagramModelFilePage;

	/**
	* @generated
	*/
	protected myBPMS.diagram.part.MyBPMSCreationWizardPage domainModelFilePage;

	/**
	* @generated
	*/
	protected Resource diagram;

	/**
	* @generated
	*/
	private boolean openNewlyCreatedDiagramEditor = true;

	/**
	* @generated
	*/
	public IWorkbench getWorkbench() {
		return workbench;
	}

	/**
	* @generated
	*/
	public IStructuredSelection getSelection() {
		return selection;
	}

	/**
	* @generated
	*/
	public final Resource getDiagram() {
		return diagram;
	}

	/**
	* @generated
	*/
	public final boolean isOpenNewlyCreatedDiagramEditor() {
		return openNewlyCreatedDiagramEditor;
	}

	/**
	* @generated
	*/
	public void setOpenNewlyCreatedDiagramEditor(boolean openNewlyCreatedDiagramEditor) {
		this.openNewlyCreatedDiagramEditor = openNewlyCreatedDiagramEditor;
	}

	/**
	* @generated
	*/
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.workbench = workbench;
		this.selection = selection;
		setWindowTitle(myBPMS.diagram.part.Messages.MyBPMSCreationWizardTitle);
		setDefaultPageImageDescriptor(myBPMS.diagram.part.MyBPMSDiagramEditorPlugin
				.getBundledImageDescriptor("icons/wizban/NewMyBPMSWizard.gif")); //$NON-NLS-1$
		setNeedsProgressMonitor(true);
	}

	/**
	* @generated
	*/
	public void addPages() {
		diagramModelFilePage = new myBPMS.diagram.part.MyBPMSCreationWizardPage("DiagramModelFile", getSelection(), //$NON-NLS-1$
				"mybpms_diagram"); //$NON-NLS-1$
		diagramModelFilePage.setTitle(myBPMS.diagram.part.Messages.MyBPMSCreationWizard_DiagramModelFilePageTitle);
		diagramModelFilePage
				.setDescription(myBPMS.diagram.part.Messages.MyBPMSCreationWizard_DiagramModelFilePageDescription);
		addPage(diagramModelFilePage);

		domainModelFilePage = new myBPMS.diagram.part.MyBPMSCreationWizardPage("DomainModelFile", getSelection(), //$NON-NLS-1$
				"mybpms") { //$NON-NLS-1$

			public void setVisible(boolean visible) {
				if (visible) {
					String fileName = diagramModelFilePage.getFileName();
					fileName = fileName.substring(0, fileName.length() - ".mybpms_diagram".length()); //$NON-NLS-1$
					setFileName(myBPMS.diagram.part.MyBPMSDiagramEditorUtil.getUniqueFileName(getContainerFullPath(),
							fileName, "mybpms")); //$NON-NLS-1$
				}
				super.setVisible(visible);
			}
		};
		domainModelFilePage.setTitle(myBPMS.diagram.part.Messages.MyBPMSCreationWizard_DomainModelFilePageTitle);
		domainModelFilePage
				.setDescription(myBPMS.diagram.part.Messages.MyBPMSCreationWizard_DomainModelFilePageDescription);
		addPage(domainModelFilePage);
	}

	/**
	* @generated
	*/
	public boolean performFinish() {
		IRunnableWithProgress op = new WorkspaceModifyOperation(null) {

			protected void execute(IProgressMonitor monitor) throws CoreException, InterruptedException {
				diagram = myBPMS.diagram.part.MyBPMSDiagramEditorUtil.createDiagram(diagramModelFilePage.getURI(),
						domainModelFilePage.getURI(), monitor);
				if (isOpenNewlyCreatedDiagramEditor() && diagram != null) {
					try {
						myBPMS.diagram.part.MyBPMSDiagramEditorUtil.openDiagram(diagram);
					} catch (PartInitException e) {
						ErrorDialog.openError(getContainer().getShell(),
								myBPMS.diagram.part.Messages.MyBPMSCreationWizardOpenEditorError, null, e.getStatus());
					}
				}
			}
		};
		try {
			getContainer().run(false, true, op);
		} catch (InterruptedException e) {
			return false;
		} catch (InvocationTargetException e) {
			if (e.getTargetException() instanceof CoreException) {
				ErrorDialog.openError(getContainer().getShell(),
						myBPMS.diagram.part.Messages.MyBPMSCreationWizardCreationError, null,
						((CoreException) e.getTargetException()).getStatus());
			} else {
				myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance().logError("Error creating diagram", //$NON-NLS-1$
						e.getTargetException());
			}
			return false;
		}
		return diagram != null;
	}
}

/*
* 
*/
package myBPMS.diagram.part;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.update.DiagramUpdater;

/**
 * @generated
 */
public class MyBPMSDiagramUpdater {

	/**
	* @generated
	*/
	public static boolean isShortcutOrphaned(View view) {
		return !view.isSetElement() || view.getElement() == null || view.getElement().eIsProxy();
	}

	/**
	* @generated
	*/
	public static List<myBPMS.diagram.part.MyBPMSNodeDescriptor> getSemanticChildren(View view) {
		switch (myBPMS.diagram.part.MyBPMSVisualIDRegistry.getVisualID(view)) {
		case myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.VISUAL_ID:
			return getProcesoDeNegocio_1000SemanticChildren(view);
		case myBPMS.diagram.edit.parts.ActorActorTareasCompartmentEditPart.VISUAL_ID:
			return getActorActorTareasCompartment_7001SemanticChildren(view);
		case myBPMS.diagram.edit.parts.ActorActorFicherosCompartmentEditPart.VISUAL_ID:
			return getActorActorFicherosCompartment_7002SemanticChildren(view);
		case myBPMS.diagram.edit.parts.BaseDeDatosBaseDeDatosTablasCompartmentEditPart.VISUAL_ID:
			return getBaseDeDatosBaseDeDatosTablasCompartment_7003SemanticChildren(view);
		case myBPMS.diagram.edit.parts.TablaTablaAtributosCompartmentEditPart.VISUAL_ID:
			return getTablaTablaAtributosCompartment_7004SemanticChildren(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<myBPMS.diagram.part.MyBPMSNodeDescriptor> getProcesoDeNegocio_1000SemanticChildren(View view) {
		if (!view.isSetElement()) {
			return Collections.emptyList();
		}
		myBPMS.ProcesoDeNegocio modelElement = (myBPMS.ProcesoDeNegocio) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSNodeDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSNodeDescriptor>();
		for (Iterator<?> it = modelElement.getActores().iterator(); it.hasNext();) {
			myBPMS.Actor childElement = (myBPMS.Actor) it.next();
			int visualID = myBPMS.diagram.part.MyBPMSVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == myBPMS.diagram.edit.parts.ActorEditPart.VISUAL_ID) {
				result.add(new myBPMS.diagram.part.MyBPMSNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		for (Iterator<?> it = modelElement.getBasesdedatos().iterator(); it.hasNext();) {
			myBPMS.BaseDeDatos childElement = (myBPMS.BaseDeDatos) it.next();
			int visualID = myBPMS.diagram.part.MyBPMSVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == myBPMS.diagram.edit.parts.BaseDeDatosEditPart.VISUAL_ID) {
				result.add(new myBPMS.diagram.part.MyBPMSNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<myBPMS.diagram.part.MyBPMSNodeDescriptor> getActorActorTareasCompartment_7001SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		myBPMS.Actor modelElement = (myBPMS.Actor) containerView.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSNodeDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSNodeDescriptor>();
		for (Iterator<?> it = modelElement.getTareas().iterator(); it.hasNext();) {
			myBPMS.Tarea childElement = (myBPMS.Tarea) it.next();
			int visualID = myBPMS.diagram.part.MyBPMSVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID) {
				result.add(new myBPMS.diagram.part.MyBPMSNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID) {
				result.add(new myBPMS.diagram.part.MyBPMSNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID) {
				result.add(new myBPMS.diagram.part.MyBPMSNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID) {
				result.add(new myBPMS.diagram.part.MyBPMSNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID) {
				result.add(new myBPMS.diagram.part.MyBPMSNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID) {
				result.add(new myBPMS.diagram.part.MyBPMSNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == myBPMS.diagram.edit.parts.TareaInicioEditPart.VISUAL_ID) {
				result.add(new myBPMS.diagram.part.MyBPMSNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == myBPMS.diagram.edit.parts.TareaFinEditPart.VISUAL_ID) {
				result.add(new myBPMS.diagram.part.MyBPMSNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<myBPMS.diagram.part.MyBPMSNodeDescriptor> getActorActorFicherosCompartment_7002SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		myBPMS.Actor modelElement = (myBPMS.Actor) containerView.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSNodeDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSNodeDescriptor>();
		for (Iterator<?> it = modelElement.getFicheros().iterator(); it.hasNext();) {
			myBPMS.Fichero childElement = (myBPMS.Fichero) it.next();
			int visualID = myBPMS.diagram.part.MyBPMSVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID) {
				result.add(new myBPMS.diagram.part.MyBPMSNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<myBPMS.diagram.part.MyBPMSNodeDescriptor> getBaseDeDatosBaseDeDatosTablasCompartment_7003SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		myBPMS.BaseDeDatos modelElement = (myBPMS.BaseDeDatos) containerView.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSNodeDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSNodeDescriptor>();
		for (Iterator<?> it = modelElement.getTablas().iterator(); it.hasNext();) {
			myBPMS.Tabla childElement = (myBPMS.Tabla) it.next();
			int visualID = myBPMS.diagram.part.MyBPMSVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID) {
				result.add(new myBPMS.diagram.part.MyBPMSNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<myBPMS.diagram.part.MyBPMSNodeDescriptor> getTablaTablaAtributosCompartment_7004SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		myBPMS.Tabla modelElement = (myBPMS.Tabla) containerView.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSNodeDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSNodeDescriptor>();
		for (Iterator<?> it = modelElement.getAtributos().iterator(); it.hasNext();) {
			myBPMS.Atributo childElement = (myBPMS.Atributo) it.next();
			int visualID = myBPMS.diagram.part.MyBPMSVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID) {
				result.add(new myBPMS.diagram.part.MyBPMSNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getContainedLinks(View view) {
		switch (myBPMS.diagram.part.MyBPMSVisualIDRegistry.getVisualID(view)) {
		case myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.VISUAL_ID:
			return getProcesoDeNegocio_1000ContainedLinks(view);
		case myBPMS.diagram.edit.parts.ActorEditPart.VISUAL_ID:
			return getActor_2001ContainedLinks(view);
		case myBPMS.diagram.edit.parts.BaseDeDatosEditPart.VISUAL_ID:
			return getBaseDeDatos_2002ContainedLinks(view);
		case myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID:
			return getTareaUsuario_3001ContainedLinks(view);
		case myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID:
			return getTareaServicio_3002ContainedLinks(view);
		case myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID:
			return getTareaEnvioMsj_3003ContainedLinks(view);
		case myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID:
			return getTareaRecepMsj_3004ContainedLinks(view);
		case myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID:
			return getTareaConsulta_3005ContainedLinks(view);
		case myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID:
			return getTareaBorrado_3006ContainedLinks(view);
		case myBPMS.diagram.edit.parts.TareaInicioEditPart.VISUAL_ID:
			return getTareaInicio_3007ContainedLinks(view);
		case myBPMS.diagram.edit.parts.TareaFinEditPart.VISUAL_ID:
			return getTareaFin_3008ContainedLinks(view);
		case myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID:
			return getFichero_3009ContainedLinks(view);
		case myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID:
			return getTabla_3010ContainedLinks(view);
		case myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return getAtributo_3011ContainedLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getIncomingLinks(View view) {
		switch (myBPMS.diagram.part.MyBPMSVisualIDRegistry.getVisualID(view)) {
		case myBPMS.diagram.edit.parts.ActorEditPart.VISUAL_ID:
			return getActor_2001IncomingLinks(view);
		case myBPMS.diagram.edit.parts.BaseDeDatosEditPart.VISUAL_ID:
			return getBaseDeDatos_2002IncomingLinks(view);
		case myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID:
			return getTareaUsuario_3001IncomingLinks(view);
		case myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID:
			return getTareaServicio_3002IncomingLinks(view);
		case myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID:
			return getTareaEnvioMsj_3003IncomingLinks(view);
		case myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID:
			return getTareaRecepMsj_3004IncomingLinks(view);
		case myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID:
			return getTareaConsulta_3005IncomingLinks(view);
		case myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID:
			return getTareaBorrado_3006IncomingLinks(view);
		case myBPMS.diagram.edit.parts.TareaInicioEditPart.VISUAL_ID:
			return getTareaInicio_3007IncomingLinks(view);
		case myBPMS.diagram.edit.parts.TareaFinEditPart.VISUAL_ID:
			return getTareaFin_3008IncomingLinks(view);
		case myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID:
			return getFichero_3009IncomingLinks(view);
		case myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID:
			return getTabla_3010IncomingLinks(view);
		case myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return getAtributo_3011IncomingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getOutgoingLinks(View view) {
		switch (myBPMS.diagram.part.MyBPMSVisualIDRegistry.getVisualID(view)) {
		case myBPMS.diagram.edit.parts.ActorEditPart.VISUAL_ID:
			return getActor_2001OutgoingLinks(view);
		case myBPMS.diagram.edit.parts.BaseDeDatosEditPart.VISUAL_ID:
			return getBaseDeDatos_2002OutgoingLinks(view);
		case myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID:
			return getTareaUsuario_3001OutgoingLinks(view);
		case myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID:
			return getTareaServicio_3002OutgoingLinks(view);
		case myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID:
			return getTareaEnvioMsj_3003OutgoingLinks(view);
		case myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID:
			return getTareaRecepMsj_3004OutgoingLinks(view);
		case myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID:
			return getTareaConsulta_3005OutgoingLinks(view);
		case myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID:
			return getTareaBorrado_3006OutgoingLinks(view);
		case myBPMS.diagram.edit.parts.TareaInicioEditPart.VISUAL_ID:
			return getTareaInicio_3007OutgoingLinks(view);
		case myBPMS.diagram.edit.parts.TareaFinEditPart.VISUAL_ID:
			return getTareaFin_3008OutgoingLinks(view);
		case myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID:
			return getFichero_3009OutgoingLinks(view);
		case myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID:
			return getTabla_3010OutgoingLinks(view);
		case myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return getAtributo_3011OutgoingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getProcesoDeNegocio_1000ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getActor_2001ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getBaseDeDatos_2002ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaUsuario_3001ContainedLinks(View view) {
		myBPMS.TareaUsuario modelElement = (myBPMS.TareaUsuario) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaUsuario_Formularios_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaServicio_3002ContainedLinks(View view) {
		myBPMS.TareaServicio modelElement = (myBPMS.TareaServicio) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaServicio_Servicio_4004(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaServicio_Usa_4005(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaServicio_Genera_4006(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaEnvioMsj_3003ContainedLinks(View view) {
		myBPMS.TareaEnvioMsj modelElement = (myBPMS.TareaEnvioMsj) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaEnvioMsj_Envio_msj_4007(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaEnvioMsj_Adjunta_4008(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaRecepMsj_3004ContainedLinks(View view) {
		myBPMS.TareaRecepMsj modelElement = (myBPMS.TareaRecepMsj) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaRecepMsj_Recepcion_msj_4009(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaConsulta_3005ContainedLinks(View view) {
		myBPMS.TareaConsulta modelElement = (myBPMS.TareaConsulta) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaConsulta_Consultar_atributo_4010(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaBorrado_3006ContainedLinks(View view) {
		myBPMS.TareaBorrado modelElement = (myBPMS.TareaBorrado) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaBorrado_Borrar_atributo_4011(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaInicio_3007ContainedLinks(View view) {
		myBPMS.TareaInicio modelElement = (myBPMS.TareaInicio) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaFin_3008ContainedLinks(View view) {
		myBPMS.TareaFin modelElement = (myBPMS.TareaFin) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getFichero_3009ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTabla_3010ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getAtributo_3011ContainedLinks(View view) {
		myBPMS.Atributo modelElement = (myBPMS.Atributo) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Atributo_Clave_ajena_4012(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_Atributo_Clave_primaria_4013(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getActor_2001IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getBaseDeDatos_2002IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaUsuario_3001IncomingLinks(View view) {
		myBPMS.TareaUsuario modelElement = (myBPMS.TareaUsuario) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaServicio_3002IncomingLinks(View view) {
		myBPMS.TareaServicio modelElement = (myBPMS.TareaServicio) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaEnvioMsj_3003IncomingLinks(View view) {
		myBPMS.TareaEnvioMsj modelElement = (myBPMS.TareaEnvioMsj) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaRecepMsj_3004IncomingLinks(View view) {
		myBPMS.TareaRecepMsj modelElement = (myBPMS.TareaRecepMsj) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaConsulta_3005IncomingLinks(View view) {
		myBPMS.TareaConsulta modelElement = (myBPMS.TareaConsulta) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaBorrado_3006IncomingLinks(View view) {
		myBPMS.TareaBorrado modelElement = (myBPMS.TareaBorrado) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaInicio_3007IncomingLinks(View view) {
		myBPMS.TareaInicio modelElement = (myBPMS.TareaInicio) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaFin_3008IncomingLinks(View view) {
		myBPMS.TareaFin modelElement = (myBPMS.TareaFin) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getFichero_3009IncomingLinks(View view) {
		myBPMS.Fichero modelElement = (myBPMS.Fichero) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_TareaServicio_Usa_4005(modelElement, crossReferences));
		result.addAll(getIncomingFeatureModelFacetLinks_TareaServicio_Genera_4006(modelElement, crossReferences));
		result.addAll(getIncomingFeatureModelFacetLinks_TareaEnvioMsj_Adjunta_4008(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTabla_3010IncomingLinks(View view) {
		myBPMS.Tabla modelElement = (myBPMS.Tabla) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_TareaUsuario_Formularios_4003(modelElement, crossReferences));
		result.addAll(getIncomingFeatureModelFacetLinks_TareaServicio_Servicio_4004(modelElement, crossReferences));
		result.addAll(getIncomingFeatureModelFacetLinks_TareaEnvioMsj_Envio_msj_4007(modelElement, crossReferences));
		result.addAll(
				getIncomingFeatureModelFacetLinks_TareaRecepMsj_Recepcion_msj_4009(modelElement, crossReferences));
		result.addAll(getIncomingFeatureModelFacetLinks_Atributo_Clave_ajena_4012(modelElement, crossReferences));
		result.addAll(getIncomingFeatureModelFacetLinks_Atributo_Clave_primaria_4013(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getAtributo_3011IncomingLinks(View view) {
		myBPMS.Atributo modelElement = (myBPMS.Atributo) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(
				getIncomingFeatureModelFacetLinks_TareaConsulta_Consultar_atributo_4010(modelElement, crossReferences));
		result.addAll(
				getIncomingFeatureModelFacetLinks_TareaBorrado_Borrar_atributo_4011(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getActor_2001OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getBaseDeDatos_2002OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaUsuario_3001OutgoingLinks(View view) {
		myBPMS.TareaUsuario modelElement = (myBPMS.TareaUsuario) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaUsuario_Formularios_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaServicio_3002OutgoingLinks(View view) {
		myBPMS.TareaServicio modelElement = (myBPMS.TareaServicio) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaServicio_Servicio_4004(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaServicio_Usa_4005(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaServicio_Genera_4006(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaEnvioMsj_3003OutgoingLinks(View view) {
		myBPMS.TareaEnvioMsj modelElement = (myBPMS.TareaEnvioMsj) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaEnvioMsj_Envio_msj_4007(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaEnvioMsj_Adjunta_4008(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaRecepMsj_3004OutgoingLinks(View view) {
		myBPMS.TareaRecepMsj modelElement = (myBPMS.TareaRecepMsj) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaRecepMsj_Recepcion_msj_4009(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaConsulta_3005OutgoingLinks(View view) {
		myBPMS.TareaConsulta modelElement = (myBPMS.TareaConsulta) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaConsulta_Consultar_atributo_4010(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaBorrado_3006OutgoingLinks(View view) {
		myBPMS.TareaBorrado modelElement = (myBPMS.TareaBorrado) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_TareaBorrado_Borrar_atributo_4011(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaInicio_3007OutgoingLinks(View view) {
		myBPMS.TareaInicio modelElement = (myBPMS.TareaInicio) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTareaFin_3008OutgoingLinks(View view) {
		myBPMS.TareaFin modelElement = (myBPMS.TareaFin) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getFichero_3009OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getTabla_3010OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getAtributo_3011OutgoingLinks(View view) {
		myBPMS.Atributo modelElement = (myBPMS.Atributo) view.getElement();
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Atributo_Clave_ajena_4012(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_Atributo_Clave_primaria_4013(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getIncomingFeatureModelFacetLinks_Tarea_Sucesor_4015(
			myBPMS.Tarea target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == myBPMS.MyBPMSPackage.eINSTANCE.getTarea_Sucesor()) {
				result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(setting.getEObject(), target,
						myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015,
						myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getIncomingFeatureModelFacetLinks_TareaUsuario_Formularios_4003(
			myBPMS.Tabla target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == myBPMS.MyBPMSPackage.eINSTANCE.getTareaUsuario_Formularios()) {
				result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(setting.getEObject(), target,
						myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuarioFormularios_4003,
						myBPMS.diagram.edit.parts.TareaUsuarioFormulariosEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getIncomingFeatureModelFacetLinks_TareaServicio_Servicio_4004(
			myBPMS.Tabla target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == myBPMS.MyBPMSPackage.eINSTANCE.getTareaServicio_Servicio()) {
				result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(setting.getEObject(), target,
						myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioServicio_4004,
						myBPMS.diagram.edit.parts.TareaServicioServicioEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getIncomingFeatureModelFacetLinks_TareaServicio_Usa_4005(
			myBPMS.Fichero target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == myBPMS.MyBPMSPackage.eINSTANCE.getTareaServicio_Usa()) {
				result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(setting.getEObject(), target,
						myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioUsa_4005,
						myBPMS.diagram.edit.parts.TareaServicioUsaEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getIncomingFeatureModelFacetLinks_TareaServicio_Genera_4006(
			myBPMS.Fichero target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == myBPMS.MyBPMSPackage.eINSTANCE.getTareaServicio_Genera()) {
				result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(setting.getEObject(), target,
						myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioGenera_4006,
						myBPMS.diagram.edit.parts.TareaServicioGeneraEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getIncomingFeatureModelFacetLinks_TareaEnvioMsj_Envio_msj_4007(
			myBPMS.Tabla target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == myBPMS.MyBPMSPackage.eINSTANCE.getTareaEnvioMsj_Envio_msj()) {
				result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(setting.getEObject(), target,
						myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjEnvio_msj_4007,
						myBPMS.diagram.edit.parts.TareaEnvioMsjEnvio_msjEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getIncomingFeatureModelFacetLinks_TareaEnvioMsj_Adjunta_4008(
			myBPMS.Fichero target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == myBPMS.MyBPMSPackage.eINSTANCE.getTareaEnvioMsj_Adjunta()) {
				result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(setting.getEObject(), target,
						myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjAdjunta_4008,
						myBPMS.diagram.edit.parts.TareaEnvioMsjAdjuntaEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getIncomingFeatureModelFacetLinks_TareaRecepMsj_Recepcion_msj_4009(
			myBPMS.Tabla target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == myBPMS.MyBPMSPackage.eINSTANCE.getTareaRecepMsj_Recepcion_msj()) {
				result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(setting.getEObject(), target,
						myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsjRecepcion_msj_4009,
						myBPMS.diagram.edit.parts.TareaRecepMsjRecepcion_msjEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getIncomingFeatureModelFacetLinks_TareaConsulta_Consultar_atributo_4010(
			myBPMS.Atributo target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == myBPMS.MyBPMSPackage.eINSTANCE
					.getTareaConsulta_Consultar_atributo()) {
				result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(setting.getEObject(), target,
						myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsultaConsultar_atributo_4010,
						myBPMS.diagram.edit.parts.TareaConsultaConsultar_atributoEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getIncomingFeatureModelFacetLinks_TareaBorrado_Borrar_atributo_4011(
			myBPMS.Atributo target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == myBPMS.MyBPMSPackage.eINSTANCE.getTareaBorrado_Borrar_atributo()) {
				result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(setting.getEObject(), target,
						myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorradoBorrar_atributo_4011,
						myBPMS.diagram.edit.parts.TareaBorradoBorrar_atributoEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getIncomingFeatureModelFacetLinks_Atributo_Clave_ajena_4012(
			myBPMS.Tabla target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == myBPMS.MyBPMSPackage.eINSTANCE.getAtributo_Clave_ajena()) {
				result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(setting.getEObject(), target,
						myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_ajena_4012,
						myBPMS.diagram.edit.parts.AtributoClave_ajenaEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getIncomingFeatureModelFacetLinks_Atributo_Clave_primaria_4013(
			myBPMS.Tabla target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == myBPMS.MyBPMSPackage.eINSTANCE.getAtributo_Clave_primaria()) {
				result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(setting.getEObject(), target,
						myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_primaria_4013,
						myBPMS.diagram.edit.parts.AtributoClave_primariaEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getOutgoingFeatureModelFacetLinks_Tarea_Sucesor_4015(
			myBPMS.Tarea source) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		myBPMS.Tarea destination = source.getSucesor();
		if (destination == null) {
			return result;
		}
		result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(source, destination,
				myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015,
				myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID));
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getOutgoingFeatureModelFacetLinks_TareaUsuario_Formularios_4003(
			myBPMS.TareaUsuario source) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		for (Iterator<?> destinations = source.getFormularios().iterator(); destinations.hasNext();) {
			myBPMS.Tabla destination = (myBPMS.Tabla) destinations.next();
			result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(source, destination,
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuarioFormularios_4003,
					myBPMS.diagram.edit.parts.TareaUsuarioFormulariosEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getOutgoingFeatureModelFacetLinks_TareaServicio_Servicio_4004(
			myBPMS.TareaServicio source) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		for (Iterator<?> destinations = source.getServicio().iterator(); destinations.hasNext();) {
			myBPMS.Tabla destination = (myBPMS.Tabla) destinations.next();
			result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(source, destination,
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioServicio_4004,
					myBPMS.diagram.edit.parts.TareaServicioServicioEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getOutgoingFeatureModelFacetLinks_TareaServicio_Usa_4005(
			myBPMS.TareaServicio source) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		for (Iterator<?> destinations = source.getUsa().iterator(); destinations.hasNext();) {
			myBPMS.Fichero destination = (myBPMS.Fichero) destinations.next();
			result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(source, destination,
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioUsa_4005,
					myBPMS.diagram.edit.parts.TareaServicioUsaEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getOutgoingFeatureModelFacetLinks_TareaServicio_Genera_4006(
			myBPMS.TareaServicio source) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		for (Iterator<?> destinations = source.getGenera().iterator(); destinations.hasNext();) {
			myBPMS.Fichero destination = (myBPMS.Fichero) destinations.next();
			result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(source, destination,
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioGenera_4006,
					myBPMS.diagram.edit.parts.TareaServicioGeneraEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getOutgoingFeatureModelFacetLinks_TareaEnvioMsj_Envio_msj_4007(
			myBPMS.TareaEnvioMsj source) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		for (Iterator<?> destinations = source.getEnvio_msj().iterator(); destinations.hasNext();) {
			myBPMS.Tabla destination = (myBPMS.Tabla) destinations.next();
			result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(source, destination,
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjEnvio_msj_4007,
					myBPMS.diagram.edit.parts.TareaEnvioMsjEnvio_msjEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getOutgoingFeatureModelFacetLinks_TareaEnvioMsj_Adjunta_4008(
			myBPMS.TareaEnvioMsj source) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		for (Iterator<?> destinations = source.getAdjunta().iterator(); destinations.hasNext();) {
			myBPMS.Fichero destination = (myBPMS.Fichero) destinations.next();
			result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(source, destination,
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjAdjunta_4008,
					myBPMS.diagram.edit.parts.TareaEnvioMsjAdjuntaEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getOutgoingFeatureModelFacetLinks_TareaRecepMsj_Recepcion_msj_4009(
			myBPMS.TareaRecepMsj source) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		for (Iterator<?> destinations = source.getRecepcion_msj().iterator(); destinations.hasNext();) {
			myBPMS.Tabla destination = (myBPMS.Tabla) destinations.next();
			result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(source, destination,
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsjRecepcion_msj_4009,
					myBPMS.diagram.edit.parts.TareaRecepMsjRecepcion_msjEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getOutgoingFeatureModelFacetLinks_TareaConsulta_Consultar_atributo_4010(
			myBPMS.TareaConsulta source) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		for (Iterator<?> destinations = source.getConsultar_atributo().iterator(); destinations.hasNext();) {
			myBPMS.Atributo destination = (myBPMS.Atributo) destinations.next();
			result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(source, destination,
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsultaConsultar_atributo_4010,
					myBPMS.diagram.edit.parts.TareaConsultaConsultar_atributoEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getOutgoingFeatureModelFacetLinks_TareaBorrado_Borrar_atributo_4011(
			myBPMS.TareaBorrado source) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		for (Iterator<?> destinations = source.getBorrar_atributo().iterator(); destinations.hasNext();) {
			myBPMS.Atributo destination = (myBPMS.Atributo) destinations.next();
			result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(source, destination,
					myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorradoBorrar_atributo_4011,
					myBPMS.diagram.edit.parts.TareaBorradoBorrar_atributoEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getOutgoingFeatureModelFacetLinks_Atributo_Clave_ajena_4012(
			myBPMS.Atributo source) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		for (Iterator<?> destinations = source.getClave_ajena().iterator(); destinations.hasNext();) {
			myBPMS.Tabla destination = (myBPMS.Tabla) destinations.next();
			result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(source, destination,
					myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_ajena_4012,
					myBPMS.diagram.edit.parts.AtributoClave_ajenaEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<myBPMS.diagram.part.MyBPMSLinkDescriptor> getOutgoingFeatureModelFacetLinks_Atributo_Clave_primaria_4013(
			myBPMS.Atributo source) {
		LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor> result = new LinkedList<myBPMS.diagram.part.MyBPMSLinkDescriptor>();
		myBPMS.Tabla destination = source.getClave_primaria();
		if (destination == null) {
			return result;
		}
		result.add(new myBPMS.diagram.part.MyBPMSLinkDescriptor(source, destination,
				myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_primaria_4013,
				myBPMS.diagram.edit.parts.AtributoClave_primariaEditPart.VISUAL_ID));
		return result;
	}

	/**
	* @generated
	*/
	public static final DiagramUpdater TYPED_INSTANCE = new DiagramUpdater() {
		/**
		* @generated
		*/
		@Override

		public List<myBPMS.diagram.part.MyBPMSNodeDescriptor> getSemanticChildren(View view) {
			return MyBPMSDiagramUpdater.getSemanticChildren(view);
		}

		/**
		* @generated
		*/
		@Override

		public List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getContainedLinks(View view) {
			return MyBPMSDiagramUpdater.getContainedLinks(view);
		}

		/**
		* @generated
		*/
		@Override

		public List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getIncomingLinks(View view) {
			return MyBPMSDiagramUpdater.getIncomingLinks(view);
		}

		/**
		* @generated
		*/
		@Override

		public List<myBPMS.diagram.part.MyBPMSLinkDescriptor> getOutgoingLinks(View view) {
			return MyBPMSDiagramUpdater.getOutgoingLinks(view);
		}
	};

}

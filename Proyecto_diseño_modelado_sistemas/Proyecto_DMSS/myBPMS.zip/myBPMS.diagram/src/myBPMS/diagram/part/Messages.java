/*
 * 
 */
package myBPMS.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	* @generated
	*/
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Messages() {
	}

	/**
	* @generated
	*/
	public static String MyBPMSCreationWizardTitle;

	/**
	* @generated
	*/
	public static String MyBPMSCreationWizard_DiagramModelFilePageTitle;

	/**
	* @generated
	*/
	public static String MyBPMSCreationWizard_DiagramModelFilePageDescription;

	/**
	* @generated
	*/
	public static String MyBPMSCreationWizard_DomainModelFilePageTitle;

	/**
	* @generated
	*/
	public static String MyBPMSCreationWizard_DomainModelFilePageDescription;

	/**
	* @generated
	*/
	public static String MyBPMSCreationWizardOpenEditorError;

	/**
	* @generated
	*/
	public static String MyBPMSCreationWizardCreationError;

	/**
	* @generated
	*/
	public static String MyBPMSCreationWizardPageExtensionError;

	/**
	* @generated
	*/
	public static String MyBPMSDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String MyBPMSDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String MyBPMSDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	* @generated
	*/
	public static String MyBPMSDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	* @generated
	*/
	public static String MyBPMSDocumentProvider_isModifiable;

	/**
	* @generated
	*/
	public static String MyBPMSDocumentProvider_handleElementContentChanged;

	/**
	* @generated
	*/
	public static String MyBPMSDocumentProvider_IncorrectInputError;

	/**
	* @generated
	*/
	public static String MyBPMSDocumentProvider_NoDiagramInResourceError;

	/**
	* @generated
	*/
	public static String MyBPMSDocumentProvider_DiagramLoadingError;

	/**
	* @generated
	*/
	public static String MyBPMSDocumentProvider_UnsynchronizedFileSaveError;

	/**
	* @generated
	*/
	public static String MyBPMSDocumentProvider_SaveDiagramTask;

	/**
	* @generated
	*/
	public static String MyBPMSDocumentProvider_SaveNextResourceTask;

	/**
	* @generated
	*/
	public static String MyBPMSDocumentProvider_SaveAsOperation;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String InitDiagramFile_WizardTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	* @generated
	*/
	public static String MyBPMSNewDiagramFileWizard_CreationPageName;

	/**
	* @generated
	*/
	public static String MyBPMSNewDiagramFileWizard_CreationPageTitle;

	/**
	* @generated
	*/
	public static String MyBPMSNewDiagramFileWizard_CreationPageDescription;

	/**
	* @generated
	*/
	public static String MyBPMSNewDiagramFileWizard_RootSelectionPageName;

	/**
	* @generated
	*/
	public static String MyBPMSNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	* @generated
	*/
	public static String MyBPMSNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	* @generated
	*/
	public static String MyBPMSNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	* @generated
	*/
	public static String MyBPMSNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	* @generated
	*/
	public static String MyBPMSNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	* @generated
	*/
	public static String MyBPMSNewDiagramFileWizard_InitDiagramCommand;

	/**
	* @generated
	*/
	public static String MyBPMSNewDiagramFileWizard_IncorrectRootError;

	/**
	* @generated
	*/
	public static String MyBPMSDiagramEditor_SavingDeletedFile;

	/**
	* @generated
	*/
	public static String MyBPMSDiagramEditor_SaveAsErrorTitle;

	/**
	* @generated
	*/
	public static String MyBPMSDiagramEditor_SaveAsErrorMessage;

	/**
	* @generated
	*/
	public static String MyBPMSDiagramEditor_SaveErrorTitle;

	/**
	* @generated
	*/
	public static String MyBPMSDiagramEditor_SaveErrorMessage;

	/**
	* @generated
	*/
	public static String MyBPMSElementChooserDialog_SelectModelElementTitle;

	/**
	* @generated
	*/
	public static String ModelElementSelectionPageMessage;

	/**
	* @generated
	*/
	public static String ValidateActionMessage;

	/**
	* @generated
	*/
	public static String Objects1Group_title;

	/**
	* @generated
	*/
	public static String Connections2Group_title;

	/**
	* @generated
	*/
	public static String Actor1CreationTool_title;

	/**
	* @generated
	*/
	public static String Actor1CreationTool_desc;

	/**
	* @generated
	*/
	public static String Atributo2CreationTool_title;

	/**
	* @generated
	*/
	public static String Atributo2CreationTool_desc;

	/**
	* @generated
	*/
	public static String BaseDeDatos3CreationTool_title;

	/**
	* @generated
	*/
	public static String BaseDeDatos3CreationTool_desc;

	/**
	* @generated
	*/
	public static String Fichero4CreationTool_title;

	/**
	* @generated
	*/
	public static String Fichero4CreationTool_desc;

	/**
	* @generated
	*/
	public static String Tabla5CreationTool_title;

	/**
	* @generated
	*/
	public static String Tabla5CreationTool_desc;

	/**
	* @generated
	*/
	public static String TareaBorrado6CreationTool_title;

	/**
	* @generated
	*/
	public static String TareaBorrado6CreationTool_desc;

	/**
	* @generated
	*/
	public static String TareaConsulta7CreationTool_title;

	/**
	* @generated
	*/
	public static String TareaConsulta7CreationTool_desc;

	/**
	* @generated
	*/
	public static String TareaEnvioMsj8CreationTool_title;

	/**
	* @generated
	*/
	public static String TareaEnvioMsj8CreationTool_desc;

	/**
	* @generated
	*/
	public static String TareaFin9CreationTool_title;

	/**
	* @generated
	*/
	public static String TareaFin9CreationTool_desc;

	/**
	* @generated
	*/
	public static String TareaInicio10CreationTool_title;

	/**
	* @generated
	*/
	public static String TareaInicio10CreationTool_desc;

	/**
	* @generated
	*/
	public static String TareaRecepMsj11CreationTool_title;

	/**
	* @generated
	*/
	public static String TareaRecepMsj11CreationTool_desc;

	/**
	* @generated
	*/
	public static String TareaServicio12CreationTool_title;

	/**
	* @generated
	*/
	public static String TareaServicio12CreationTool_desc;

	/**
	* @generated
	*/
	public static String TareaUsuario13CreationTool_title;

	/**
	* @generated
	*/
	public static String TareaUsuario13CreationTool_desc;

	/**
	* @generated
	*/
	public static String Adjunta1CreationTool_title;

	/**
	* @generated
	*/
	public static String Adjunta1CreationTool_desc;

	/**
	* @generated
	*/
	public static String Borrar_atributo2CreationTool_title;

	/**
	* @generated
	*/
	public static String Borrar_atributo2CreationTool_desc;

	/**
	* @generated
	*/
	public static String Clave_ajena3CreationTool_title;

	/**
	* @generated
	*/
	public static String Clave_ajena3CreationTool_desc;

	/**
	* @generated
	*/
	public static String Clave_primaria4CreationTool_title;

	/**
	* @generated
	*/
	public static String Clave_primaria4CreationTool_desc;

	/**
	* @generated
	*/
	public static String Consultar_atributo5CreationTool_title;

	/**
	* @generated
	*/
	public static String Consultar_atributo5CreationTool_desc;

	/**
	* @generated
	*/
	public static String Envio_msj6CreationTool_title;

	/**
	* @generated
	*/
	public static String Envio_msj6CreationTool_desc;

	/**
	* @generated
	*/
	public static String Formularios7CreationTool_title;

	/**
	* @generated
	*/
	public static String Formularios7CreationTool_desc;

	/**
	* @generated
	*/
	public static String Genera8CreationTool_title;

	/**
	* @generated
	*/
	public static String Genera8CreationTool_desc;

	/**
	* @generated
	*/
	public static String Recepcion_msj9CreationTool_title;

	/**
	* @generated
	*/
	public static String Recepcion_msj9CreationTool_desc;

	/**
	* @generated
	*/
	public static String Servicio10CreationTool_title;

	/**
	* @generated
	*/
	public static String Servicio10CreationTool_desc;

	/**
	* @generated
	*/
	public static String Sucesor11CreationTool_title;

	/**
	* @generated
	*/
	public static String Sucesor11CreationTool_desc;

	/**
	* @generated
	*/
	public static String Usa12CreationTool_title;

	/**
	* @generated
	*/
	public static String Usa12CreationTool_desc;

	/**
	* @generated
	*/
	public static String ActorActorTareasCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String ActorActorFicherosCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String BaseDeDatosBaseDeDatosTablasCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String TablaTablaAtributosCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String CommandName_OpenDiagram;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_ProcesoDeNegocio_1000_links;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaUsuario_3001_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaUsuario_3001_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaServicio_3002_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaServicio_3002_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaEnvioMsj_3003_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaEnvioMsj_3003_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaRecepMsj_3004_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaRecepMsj_3004_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaConsulta_3005_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaConsulta_3005_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaBorrado_3006_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaBorrado_3006_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaInicio_3007_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaInicio_3007_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaFin_3008_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaFin_3008_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Fichero_3009_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Tabla_3010_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Atributo_3011_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Atributo_3011_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaUsuarioFormularios_4003_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaUsuarioFormularios_4003_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaServicioServicio_4004_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaServicioServicio_4004_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaServicioUsa_4005_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaServicioUsa_4005_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaServicioGenera_4006_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaServicioGenera_4006_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaEnvioMsjEnvio_msj_4007_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaEnvioMsjEnvio_msj_4007_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaEnvioMsjAdjunta_4008_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaEnvioMsjAdjunta_4008_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaRecepMsjRecepcion_msj_4009_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaRecepMsjRecepcion_msj_4009_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaConsultaConsultar_atributo_4010_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaConsultaConsultar_atributo_4010_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaBorradoBorrar_atributo_4011_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaBorradoBorrar_atributo_4011_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_AtributoClave_ajena_4012_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_AtributoClave_ajena_4012_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_AtributoClave_primaria_4013_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_AtributoClave_primaria_4013_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaSucesor_4015_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TareaSucesor_4015_source;

	/**
	* @generated
	*/
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	* @generated
	*/
	public static String MessageFormatParser_InvalidInputError;

	/**
	* @generated
	*/
	public static String MyBPMSModelingAssistantProviderTitle;

	/**
	* @generated
	*/
	public static String MyBPMSModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}

/*
 * 
 */
package myBPMS.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	* @generated
	*/
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}

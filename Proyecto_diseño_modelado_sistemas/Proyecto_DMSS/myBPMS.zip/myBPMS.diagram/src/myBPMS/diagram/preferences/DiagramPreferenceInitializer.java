/*
 * 
 */
package myBPMS.diagram.preferences;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

/**
 * @generated
 */
public class DiagramPreferenceInitializer extends AbstractPreferenceInitializer {

	/**
	* @generated
	*/
	public void initializeDefaultPreferences() {
		IPreferenceStore store = getPreferenceStore();
		myBPMS.diagram.preferences.DiagramGeneralPreferencePage.initDefaults(store);
		myBPMS.diagram.preferences.DiagramAppearancePreferencePage.initDefaults(store);
		myBPMS.diagram.preferences.DiagramConnectionsPreferencePage.initDefaults(store);
		myBPMS.diagram.preferences.DiagramPrintingPreferencePage.initDefaults(store);
		myBPMS.diagram.preferences.DiagramRulersAndGridPreferencePage.initDefaults(store);

	}

	/**
	* @generated
	*/
	protected IPreferenceStore getPreferenceStore() {
		return myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance().getPreferenceStore();
	}
}

/*
 * 
 */
package myBPMS.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	* @generated
	*/
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}

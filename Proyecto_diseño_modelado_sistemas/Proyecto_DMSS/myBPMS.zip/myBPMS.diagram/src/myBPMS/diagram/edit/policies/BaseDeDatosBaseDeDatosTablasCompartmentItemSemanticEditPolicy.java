/*
* 
*/
package myBPMS.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class BaseDeDatosBaseDeDatosTablasCompartmentItemSemanticEditPolicy
		extends myBPMS.diagram.edit.policies.MyBPMSBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public BaseDeDatosBaseDeDatosTablasCompartmentItemSemanticEditPolicy() {
		super(myBPMS.diagram.providers.MyBPMSElementTypes.BaseDeDatos_2002);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (myBPMS.diagram.providers.MyBPMSElementTypes.Tabla_3010 == req.getElementType()) {
			return getGEFWrapper(new myBPMS.diagram.edit.commands.TablaCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}

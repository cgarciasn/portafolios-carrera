/*
 * 
 */
package myBPMS.diagram.edit.helpers;

/**
 * @generated
 */
public class BaseDeDatosEditHelper extends myBPMS.diagram.edit.helpers.MyBPMSBaseEditHelper {
}

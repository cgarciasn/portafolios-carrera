/*
 * 
 */
package myBPMS.diagram.edit.helpers;

/**
 * @generated
 */
public class TareaRecepMsjEditHelper extends myBPMS.diagram.edit.helpers.MyBPMSBaseEditHelper {
}

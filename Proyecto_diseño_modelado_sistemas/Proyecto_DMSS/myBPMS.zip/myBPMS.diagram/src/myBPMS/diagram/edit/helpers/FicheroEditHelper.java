/*
 * 
 */
package myBPMS.diagram.edit.helpers;

/**
 * @generated
 */
public class FicheroEditHelper extends myBPMS.diagram.edit.helpers.MyBPMSBaseEditHelper {
}

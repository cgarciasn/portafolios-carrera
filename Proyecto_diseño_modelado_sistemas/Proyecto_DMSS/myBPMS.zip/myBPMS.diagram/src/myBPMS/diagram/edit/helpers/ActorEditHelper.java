/*
 * 
 */
package myBPMS.diagram.edit.helpers;

/**
 * @generated
 */
public class ActorEditHelper extends myBPMS.diagram.edit.helpers.MyBPMSBaseEditHelper {
}

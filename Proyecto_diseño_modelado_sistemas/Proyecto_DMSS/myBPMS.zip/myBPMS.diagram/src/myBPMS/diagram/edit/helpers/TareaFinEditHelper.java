/*
 * 
 */
package myBPMS.diagram.edit.helpers;

/**
 * @generated
 */
public class TareaFinEditHelper extends myBPMS.diagram.edit.helpers.MyBPMSBaseEditHelper {
}

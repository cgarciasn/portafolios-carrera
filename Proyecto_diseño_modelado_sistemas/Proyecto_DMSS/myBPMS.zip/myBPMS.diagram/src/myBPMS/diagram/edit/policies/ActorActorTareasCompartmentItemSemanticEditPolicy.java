/*
* 
*/
package myBPMS.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class ActorActorTareasCompartmentItemSemanticEditPolicy
		extends myBPMS.diagram.edit.policies.MyBPMSBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public ActorActorTareasCompartmentItemSemanticEditPolicy() {
		super(myBPMS.diagram.providers.MyBPMSElementTypes.Actor_2001);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuario_3001 == req.getElementType()) {
			return getGEFWrapper(new myBPMS.diagram.edit.commands.TareaUsuarioCreateCommand(req));
		}
		if (myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicio_3002 == req.getElementType()) {
			return getGEFWrapper(new myBPMS.diagram.edit.commands.TareaServicioCreateCommand(req));
		}
		if (myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsj_3003 == req.getElementType()) {
			return getGEFWrapper(new myBPMS.diagram.edit.commands.TareaEnvioMsjCreateCommand(req));
		}
		if (myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsj_3004 == req.getElementType()) {
			return getGEFWrapper(new myBPMS.diagram.edit.commands.TareaRecepMsjCreateCommand(req));
		}
		if (myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsulta_3005 == req.getElementType()) {
			return getGEFWrapper(new myBPMS.diagram.edit.commands.TareaConsultaCreateCommand(req));
		}
		if (myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorrado_3006 == req.getElementType()) {
			return getGEFWrapper(new myBPMS.diagram.edit.commands.TareaBorradoCreateCommand(req));
		}
		if (myBPMS.diagram.providers.MyBPMSElementTypes.TareaInicio_3007 == req.getElementType()) {
			return getGEFWrapper(new myBPMS.diagram.edit.commands.TareaInicioCreateCommand(req));
		}
		if (myBPMS.diagram.providers.MyBPMSElementTypes.TareaFin_3008 == req.getElementType()) {
			return getGEFWrapper(new myBPMS.diagram.edit.commands.TareaFinCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}

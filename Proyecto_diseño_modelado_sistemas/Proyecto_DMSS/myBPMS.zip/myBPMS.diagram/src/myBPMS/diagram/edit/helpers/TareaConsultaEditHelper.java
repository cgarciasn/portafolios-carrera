/*
 * 
 */
package myBPMS.diagram.edit.helpers;

/**
 * @generated
 */
public class TareaConsultaEditHelper extends myBPMS.diagram.edit.helpers.MyBPMSBaseEditHelper {
}

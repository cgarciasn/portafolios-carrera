/*
 * 
 */
package myBPMS.diagram.edit.parts;

import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.gef.tools.CellEditorLocator;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ITextAwareEditPart;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.directedit.locator.CellEditorLocatorAccess;

/**
 * @generated
 */
public class MyBPMSEditPartFactory implements EditPartFactory {

	/**
	* @generated
	*/
	public EditPart createEditPart(EditPart context, Object model) {
		if (model instanceof View) {
			View view = (View) model;
			switch (myBPMS.diagram.part.MyBPMSVisualIDRegistry.getVisualID(view)) {

			case myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart(view);

			case myBPMS.diagram.edit.parts.ActorEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.ActorEditPart(view);

			case myBPMS.diagram.edit.parts.ActorId_actorEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.ActorId_actorEditPart(view);

			case myBPMS.diagram.edit.parts.BaseDeDatosEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.BaseDeDatosEditPart(view);

			case myBPMS.diagram.edit.parts.BaseDeDatosId_basedatosEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.BaseDeDatosId_basedatosEditPart(view);

			case myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaUsuarioEditPart(view);

			case myBPMS.diagram.edit.parts.TareaUsuarioId_tareaworkflowEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaUsuarioId_tareaworkflowEditPart(view);

			case myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaServicioEditPart(view);

			case myBPMS.diagram.edit.parts.TareaServicioId_tareaworkflowEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaServicioId_tareaworkflowEditPart(view);

			case myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart(view);

			case myBPMS.diagram.edit.parts.TareaEnvioMsjId_tareaworkflowEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaEnvioMsjId_tareaworkflowEditPart(view);

			case myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaRecepMsjEditPart(view);

			case myBPMS.diagram.edit.parts.TareaRecepMsjId_tareaworkflowEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaRecepMsjId_tareaworkflowEditPart(view);

			case myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaConsultaEditPart(view);

			case myBPMS.diagram.edit.parts.TareaConsultaId_tareaworkflowEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaConsultaId_tareaworkflowEditPart(view);

			case myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaBorradoEditPart(view);

			case myBPMS.diagram.edit.parts.TareaBorradoId_tareaworkflowEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaBorradoId_tareaworkflowEditPart(view);

			case myBPMS.diagram.edit.parts.TareaInicioEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaInicioEditPart(view);

			case myBPMS.diagram.edit.parts.TareaFinEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaFinEditPart(view);

			case myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.FicheroEditPart(view);

			case myBPMS.diagram.edit.parts.FicheroId_ficheroEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.FicheroId_ficheroEditPart(view);

			case myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TablaEditPart(view);

			case myBPMS.diagram.edit.parts.TablaId_tablaEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TablaId_tablaEditPart(view);

			case myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.AtributoEditPart(view);

			case myBPMS.diagram.edit.parts.AtributoId_atributoEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.AtributoId_atributoEditPart(view);

			case myBPMS.diagram.edit.parts.ActorActorTareasCompartmentEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.ActorActorTareasCompartmentEditPart(view);

			case myBPMS.diagram.edit.parts.ActorActorFicherosCompartmentEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.ActorActorFicherosCompartmentEditPart(view);

			case myBPMS.diagram.edit.parts.BaseDeDatosBaseDeDatosTablasCompartmentEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.BaseDeDatosBaseDeDatosTablasCompartmentEditPart(view);

			case myBPMS.diagram.edit.parts.TablaTablaAtributosCompartmentEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TablaTablaAtributosCompartmentEditPart(view);

			case myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaSucesorEditPart(view);

			case myBPMS.diagram.edit.parts.WrappingLabelEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.WrappingLabelEditPart(view);

			case myBPMS.diagram.edit.parts.TareaUsuarioFormulariosEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaUsuarioFormulariosEditPart(view);

			case myBPMS.diagram.edit.parts.WrappingLabel2EditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.WrappingLabel2EditPart(view);

			case myBPMS.diagram.edit.parts.TareaServicioServicioEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaServicioServicioEditPart(view);

			case myBPMS.diagram.edit.parts.WrappingLabel3EditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.WrappingLabel3EditPart(view);

			case myBPMS.diagram.edit.parts.TareaServicioUsaEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaServicioUsaEditPart(view);

			case myBPMS.diagram.edit.parts.WrappingLabel4EditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.WrappingLabel4EditPart(view);

			case myBPMS.diagram.edit.parts.TareaServicioGeneraEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaServicioGeneraEditPart(view);

			case myBPMS.diagram.edit.parts.WrappingLabel5EditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.WrappingLabel5EditPart(view);

			case myBPMS.diagram.edit.parts.TareaEnvioMsjEnvio_msjEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaEnvioMsjEnvio_msjEditPart(view);

			case myBPMS.diagram.edit.parts.WrappingLabel6EditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.WrappingLabel6EditPart(view);

			case myBPMS.diagram.edit.parts.TareaEnvioMsjAdjuntaEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaEnvioMsjAdjuntaEditPart(view);

			case myBPMS.diagram.edit.parts.WrappingLabel7EditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.WrappingLabel7EditPart(view);

			case myBPMS.diagram.edit.parts.TareaRecepMsjRecepcion_msjEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaRecepMsjRecepcion_msjEditPart(view);

			case myBPMS.diagram.edit.parts.WrappingLabel8EditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.WrappingLabel8EditPart(view);

			case myBPMS.diagram.edit.parts.TareaConsultaConsultar_atributoEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaConsultaConsultar_atributoEditPart(view);

			case myBPMS.diagram.edit.parts.WrappingLabel9EditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.WrappingLabel9EditPart(view);

			case myBPMS.diagram.edit.parts.TareaBorradoBorrar_atributoEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.TareaBorradoBorrar_atributoEditPart(view);

			case myBPMS.diagram.edit.parts.WrappingLabel10EditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.WrappingLabel10EditPart(view);

			case myBPMS.diagram.edit.parts.AtributoClave_ajenaEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.AtributoClave_ajenaEditPart(view);

			case myBPMS.diagram.edit.parts.WrappingLabel11EditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.WrappingLabel11EditPart(view);

			case myBPMS.diagram.edit.parts.AtributoClave_primariaEditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.AtributoClave_primariaEditPart(view);

			case myBPMS.diagram.edit.parts.WrappingLabel12EditPart.VISUAL_ID:
				return new myBPMS.diagram.edit.parts.WrappingLabel12EditPart(view);

			}
		}
		return createUnrecognizedEditPart(context, model);
	}

	/**
	* @generated
	*/
	private EditPart createUnrecognizedEditPart(EditPart context, Object model) {
		// Handle creation of unrecognized child node EditParts here
		return null;
	}

	/**
	* @generated
	*/
	public static CellEditorLocator getTextCellEditorLocator(ITextAwareEditPart source) {
		return CellEditorLocatorAccess.INSTANCE.getTextCellEditorLocator(source);
	}

}

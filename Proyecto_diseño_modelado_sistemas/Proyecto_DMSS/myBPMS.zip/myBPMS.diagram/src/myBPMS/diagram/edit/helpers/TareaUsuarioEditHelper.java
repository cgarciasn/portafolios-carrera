/*
 * 
 */
package myBPMS.diagram.edit.helpers;

/**
 * @generated
 */
public class TareaUsuarioEditHelper extends myBPMS.diagram.edit.helpers.MyBPMSBaseEditHelper {
}

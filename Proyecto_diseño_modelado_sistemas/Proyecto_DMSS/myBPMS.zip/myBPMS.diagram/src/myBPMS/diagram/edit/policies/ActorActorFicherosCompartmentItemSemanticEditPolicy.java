/*
* 
*/
package myBPMS.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class ActorActorFicherosCompartmentItemSemanticEditPolicy
		extends myBPMS.diagram.edit.policies.MyBPMSBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public ActorActorFicherosCompartmentItemSemanticEditPolicy() {
		super(myBPMS.diagram.providers.MyBPMSElementTypes.Actor_2001);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (myBPMS.diagram.providers.MyBPMSElementTypes.Fichero_3009 == req.getElementType()) {
			return getGEFWrapper(new myBPMS.diagram.edit.commands.FicheroCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}

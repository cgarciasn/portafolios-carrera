/*
 * 
 */
package myBPMS.diagram.edit.helpers;

/**
 * @generated
 */
public class TareaInicioEditHelper extends myBPMS.diagram.edit.helpers.MyBPMSBaseEditHelper {
}

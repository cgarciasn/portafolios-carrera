/*
* 
*/
package myBPMS.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class TablaTablaAtributosCompartmentItemSemanticEditPolicy
		extends myBPMS.diagram.edit.policies.MyBPMSBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public TablaTablaAtributosCompartmentItemSemanticEditPolicy() {
		super(myBPMS.diagram.providers.MyBPMSElementTypes.Tabla_3010);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (myBPMS.diagram.providers.MyBPMSElementTypes.Atributo_3011 == req.getElementType()) {
			return getGEFWrapper(new myBPMS.diagram.edit.commands.AtributoCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}

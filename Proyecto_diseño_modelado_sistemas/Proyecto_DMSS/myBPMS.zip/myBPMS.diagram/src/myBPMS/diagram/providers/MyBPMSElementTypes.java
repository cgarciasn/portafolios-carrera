/*
 * 
 */
package myBPMS.diagram.providers;

import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.gmf.runtime.emf.type.core.ElementTypeRegistry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.tooling.runtime.providers.DiagramElementTypeImages;
import org.eclipse.gmf.tooling.runtime.providers.DiagramElementTypes;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Image;

/**
 * @generated
 */
public class MyBPMSElementTypes {

	/**
	* @generated
	*/
	private MyBPMSElementTypes() {
	}

	/**
	* @generated
	*/
	private static Map<IElementType, ENamedElement> elements;

	/**
	* @generated
	*/
	private static DiagramElementTypeImages elementTypeImages = new DiagramElementTypeImages(
			myBPMS.diagram.part.MyBPMSDiagramEditorPlugin.getInstance().getItemProvidersAdapterFactory());

	/**
	* @generated
	*/
	private static Set<IElementType> KNOWN_ELEMENT_TYPES;

	/**
	* @generated
	*/
	public static final IElementType ProcesoDeNegocio_1000 = getElementType("myBPMS.diagram.ProcesoDeNegocio_1000"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Actor_2001 = getElementType("myBPMS.diagram.Actor_2001"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType BaseDeDatos_2002 = getElementType("myBPMS.diagram.BaseDeDatos_2002"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaUsuario_3001 = getElementType("myBPMS.diagram.TareaUsuario_3001"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaServicio_3002 = getElementType("myBPMS.diagram.TareaServicio_3002"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaEnvioMsj_3003 = getElementType("myBPMS.diagram.TareaEnvioMsj_3003"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaRecepMsj_3004 = getElementType("myBPMS.diagram.TareaRecepMsj_3004"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaConsulta_3005 = getElementType("myBPMS.diagram.TareaConsulta_3005"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaBorrado_3006 = getElementType("myBPMS.diagram.TareaBorrado_3006"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaInicio_3007 = getElementType("myBPMS.diagram.TareaInicio_3007"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaFin_3008 = getElementType("myBPMS.diagram.TareaFin_3008"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Fichero_3009 = getElementType("myBPMS.diagram.Fichero_3009"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Tabla_3010 = getElementType("myBPMS.diagram.Tabla_3010"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Atributo_3011 = getElementType("myBPMS.diagram.Atributo_3011"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaSucesor_4015 = getElementType("myBPMS.diagram.TareaSucesor_4015"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaUsuarioFormularios_4003 = getElementType(
			"myBPMS.diagram.TareaUsuarioFormularios_4003"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaServicioServicio_4004 = getElementType(
			"myBPMS.diagram.TareaServicioServicio_4004"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaServicioUsa_4005 = getElementType("myBPMS.diagram.TareaServicioUsa_4005"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaServicioGenera_4006 = getElementType(
			"myBPMS.diagram.TareaServicioGenera_4006"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaEnvioMsjEnvio_msj_4007 = getElementType(
			"myBPMS.diagram.TareaEnvioMsjEnvio_msj_4007"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaEnvioMsjAdjunta_4008 = getElementType(
			"myBPMS.diagram.TareaEnvioMsjAdjunta_4008"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaRecepMsjRecepcion_msj_4009 = getElementType(
			"myBPMS.diagram.TareaRecepMsjRecepcion_msj_4009"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaConsultaConsultar_atributo_4010 = getElementType(
			"myBPMS.diagram.TareaConsultaConsultar_atributo_4010"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TareaBorradoBorrar_atributo_4011 = getElementType(
			"myBPMS.diagram.TareaBorradoBorrar_atributo_4011"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType AtributoClave_ajena_4012 = getElementType(
			"myBPMS.diagram.AtributoClave_ajena_4012"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType AtributoClave_primaria_4013 = getElementType(
			"myBPMS.diagram.AtributoClave_primaria_4013"); //$NON-NLS-1$

	/**
	* @generated
	*/
	public static ImageDescriptor getImageDescriptor(ENamedElement element) {
		return elementTypeImages.getImageDescriptor(element);
	}

	/**
	* @generated
	*/
	public static Image getImage(ENamedElement element) {
		return elementTypeImages.getImage(element);
	}

	/**
	* @generated
	*/
	public static ImageDescriptor getImageDescriptor(IAdaptable hint) {
		return getImageDescriptor(getElement(hint));
	}

	/**
	* @generated
	*/
	public static Image getImage(IAdaptable hint) {
		return getImage(getElement(hint));
	}

	/**
	* Returns 'type' of the ecore object associated with the hint.
	* 
	* @generated
	*/
	public static ENamedElement getElement(IAdaptable hint) {
		Object type = hint.getAdapter(IElementType.class);
		if (elements == null) {
			elements = new IdentityHashMap<IElementType, ENamedElement>();

			elements.put(ProcesoDeNegocio_1000, myBPMS.MyBPMSPackage.eINSTANCE.getProcesoDeNegocio());

			elements.put(Actor_2001, myBPMS.MyBPMSPackage.eINSTANCE.getActor());

			elements.put(BaseDeDatos_2002, myBPMS.MyBPMSPackage.eINSTANCE.getBaseDeDatos());

			elements.put(TareaUsuario_3001, myBPMS.MyBPMSPackage.eINSTANCE.getTareaUsuario());

			elements.put(TareaServicio_3002, myBPMS.MyBPMSPackage.eINSTANCE.getTareaServicio());

			elements.put(TareaEnvioMsj_3003, myBPMS.MyBPMSPackage.eINSTANCE.getTareaEnvioMsj());

			elements.put(TareaRecepMsj_3004, myBPMS.MyBPMSPackage.eINSTANCE.getTareaRecepMsj());

			elements.put(TareaConsulta_3005, myBPMS.MyBPMSPackage.eINSTANCE.getTareaConsulta());

			elements.put(TareaBorrado_3006, myBPMS.MyBPMSPackage.eINSTANCE.getTareaBorrado());

			elements.put(TareaInicio_3007, myBPMS.MyBPMSPackage.eINSTANCE.getTareaInicio());

			elements.put(TareaFin_3008, myBPMS.MyBPMSPackage.eINSTANCE.getTareaFin());

			elements.put(Fichero_3009, myBPMS.MyBPMSPackage.eINSTANCE.getFichero());

			elements.put(Tabla_3010, myBPMS.MyBPMSPackage.eINSTANCE.getTabla());

			elements.put(Atributo_3011, myBPMS.MyBPMSPackage.eINSTANCE.getAtributo());

			elements.put(TareaSucesor_4015, myBPMS.MyBPMSPackage.eINSTANCE.getTarea_Sucesor());

			elements.put(TareaUsuarioFormularios_4003, myBPMS.MyBPMSPackage.eINSTANCE.getTareaUsuario_Formularios());

			elements.put(TareaServicioServicio_4004, myBPMS.MyBPMSPackage.eINSTANCE.getTareaServicio_Servicio());

			elements.put(TareaServicioUsa_4005, myBPMS.MyBPMSPackage.eINSTANCE.getTareaServicio_Usa());

			elements.put(TareaServicioGenera_4006, myBPMS.MyBPMSPackage.eINSTANCE.getTareaServicio_Genera());

			elements.put(TareaEnvioMsjEnvio_msj_4007, myBPMS.MyBPMSPackage.eINSTANCE.getTareaEnvioMsj_Envio_msj());

			elements.put(TareaEnvioMsjAdjunta_4008, myBPMS.MyBPMSPackage.eINSTANCE.getTareaEnvioMsj_Adjunta());

			elements.put(TareaRecepMsjRecepcion_msj_4009,
					myBPMS.MyBPMSPackage.eINSTANCE.getTareaRecepMsj_Recepcion_msj());

			elements.put(TareaConsultaConsultar_atributo_4010,
					myBPMS.MyBPMSPackage.eINSTANCE.getTareaConsulta_Consultar_atributo());

			elements.put(TareaBorradoBorrar_atributo_4011,
					myBPMS.MyBPMSPackage.eINSTANCE.getTareaBorrado_Borrar_atributo());

			elements.put(AtributoClave_ajena_4012, myBPMS.MyBPMSPackage.eINSTANCE.getAtributo_Clave_ajena());

			elements.put(AtributoClave_primaria_4013, myBPMS.MyBPMSPackage.eINSTANCE.getAtributo_Clave_primaria());
		}
		return (ENamedElement) elements.get(type);
	}

	/**
	* @generated
	*/
	private static IElementType getElementType(String id) {
		return ElementTypeRegistry.getInstance().getType(id);
	}

	/**
	* @generated
	*/
	public static boolean isKnownElementType(IElementType elementType) {
		if (KNOWN_ELEMENT_TYPES == null) {
			KNOWN_ELEMENT_TYPES = new HashSet<IElementType>();
			KNOWN_ELEMENT_TYPES.add(ProcesoDeNegocio_1000);
			KNOWN_ELEMENT_TYPES.add(Actor_2001);
			KNOWN_ELEMENT_TYPES.add(BaseDeDatos_2002);
			KNOWN_ELEMENT_TYPES.add(TareaUsuario_3001);
			KNOWN_ELEMENT_TYPES.add(TareaServicio_3002);
			KNOWN_ELEMENT_TYPES.add(TareaEnvioMsj_3003);
			KNOWN_ELEMENT_TYPES.add(TareaRecepMsj_3004);
			KNOWN_ELEMENT_TYPES.add(TareaConsulta_3005);
			KNOWN_ELEMENT_TYPES.add(TareaBorrado_3006);
			KNOWN_ELEMENT_TYPES.add(TareaInicio_3007);
			KNOWN_ELEMENT_TYPES.add(TareaFin_3008);
			KNOWN_ELEMENT_TYPES.add(Fichero_3009);
			KNOWN_ELEMENT_TYPES.add(Tabla_3010);
			KNOWN_ELEMENT_TYPES.add(Atributo_3011);
			KNOWN_ELEMENT_TYPES.add(TareaSucesor_4015);
			KNOWN_ELEMENT_TYPES.add(TareaUsuarioFormularios_4003);
			KNOWN_ELEMENT_TYPES.add(TareaServicioServicio_4004);
			KNOWN_ELEMENT_TYPES.add(TareaServicioUsa_4005);
			KNOWN_ELEMENT_TYPES.add(TareaServicioGenera_4006);
			KNOWN_ELEMENT_TYPES.add(TareaEnvioMsjEnvio_msj_4007);
			KNOWN_ELEMENT_TYPES.add(TareaEnvioMsjAdjunta_4008);
			KNOWN_ELEMENT_TYPES.add(TareaRecepMsjRecepcion_msj_4009);
			KNOWN_ELEMENT_TYPES.add(TareaConsultaConsultar_atributo_4010);
			KNOWN_ELEMENT_TYPES.add(TareaBorradoBorrar_atributo_4011);
			KNOWN_ELEMENT_TYPES.add(AtributoClave_ajena_4012);
			KNOWN_ELEMENT_TYPES.add(AtributoClave_primaria_4013);
		}
		return KNOWN_ELEMENT_TYPES.contains(elementType);
	}

	/**
	* @generated
	*/
	public static IElementType getElementType(int visualID) {
		switch (visualID) {
		case myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.VISUAL_ID:
			return ProcesoDeNegocio_1000;
		case myBPMS.diagram.edit.parts.ActorEditPart.VISUAL_ID:
			return Actor_2001;
		case myBPMS.diagram.edit.parts.BaseDeDatosEditPart.VISUAL_ID:
			return BaseDeDatos_2002;
		case myBPMS.diagram.edit.parts.TareaUsuarioEditPart.VISUAL_ID:
			return TareaUsuario_3001;
		case myBPMS.diagram.edit.parts.TareaServicioEditPart.VISUAL_ID:
			return TareaServicio_3002;
		case myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart.VISUAL_ID:
			return TareaEnvioMsj_3003;
		case myBPMS.diagram.edit.parts.TareaRecepMsjEditPart.VISUAL_ID:
			return TareaRecepMsj_3004;
		case myBPMS.diagram.edit.parts.TareaConsultaEditPart.VISUAL_ID:
			return TareaConsulta_3005;
		case myBPMS.diagram.edit.parts.TareaBorradoEditPart.VISUAL_ID:
			return TareaBorrado_3006;
		case myBPMS.diagram.edit.parts.TareaInicioEditPart.VISUAL_ID:
			return TareaInicio_3007;
		case myBPMS.diagram.edit.parts.TareaFinEditPart.VISUAL_ID:
			return TareaFin_3008;
		case myBPMS.diagram.edit.parts.FicheroEditPart.VISUAL_ID:
			return Fichero_3009;
		case myBPMS.diagram.edit.parts.TablaEditPart.VISUAL_ID:
			return Tabla_3010;
		case myBPMS.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return Atributo_3011;
		case myBPMS.diagram.edit.parts.TareaSucesorEditPart.VISUAL_ID:
			return TareaSucesor_4015;
		case myBPMS.diagram.edit.parts.TareaUsuarioFormulariosEditPart.VISUAL_ID:
			return TareaUsuarioFormularios_4003;
		case myBPMS.diagram.edit.parts.TareaServicioServicioEditPart.VISUAL_ID:
			return TareaServicioServicio_4004;
		case myBPMS.diagram.edit.parts.TareaServicioUsaEditPart.VISUAL_ID:
			return TareaServicioUsa_4005;
		case myBPMS.diagram.edit.parts.TareaServicioGeneraEditPart.VISUAL_ID:
			return TareaServicioGenera_4006;
		case myBPMS.diagram.edit.parts.TareaEnvioMsjEnvio_msjEditPart.VISUAL_ID:
			return TareaEnvioMsjEnvio_msj_4007;
		case myBPMS.diagram.edit.parts.TareaEnvioMsjAdjuntaEditPart.VISUAL_ID:
			return TareaEnvioMsjAdjunta_4008;
		case myBPMS.diagram.edit.parts.TareaRecepMsjRecepcion_msjEditPart.VISUAL_ID:
			return TareaRecepMsjRecepcion_msj_4009;
		case myBPMS.diagram.edit.parts.TareaConsultaConsultar_atributoEditPart.VISUAL_ID:
			return TareaConsultaConsultar_atributo_4010;
		case myBPMS.diagram.edit.parts.TareaBorradoBorrar_atributoEditPart.VISUAL_ID:
			return TareaBorradoBorrar_atributo_4011;
		case myBPMS.diagram.edit.parts.AtributoClave_ajenaEditPart.VISUAL_ID:
			return AtributoClave_ajena_4012;
		case myBPMS.diagram.edit.parts.AtributoClave_primariaEditPart.VISUAL_ID:
			return AtributoClave_primaria_4013;
		}
		return null;
	}

	/**
	* @generated
	*/
	public static final DiagramElementTypes TYPED_INSTANCE = new DiagramElementTypes(elementTypeImages) {

		/**
		* @generated
		*/
		@Override

		public boolean isKnownElementType(IElementType elementType) {
			return myBPMS.diagram.providers.MyBPMSElementTypes.isKnownElementType(elementType);
		}

		/**
		* @generated
		*/
		@Override

		public IElementType getElementTypeForVisualId(int visualID) {
			return myBPMS.diagram.providers.MyBPMSElementTypes.getElementType(visualID);
		}

		/**
		* @generated
		*/
		@Override

		public ENamedElement getDefiningNamedElement(IAdaptable elementTypeAdapter) {
			return myBPMS.diagram.providers.MyBPMSElementTypes.getElement(elementTypeAdapter);
		}
	};

}

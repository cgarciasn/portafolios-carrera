/*
 * 
 */
package myBPMS.diagram.providers.assistants;

/**
 * @generated
 */
public class MyBPMSModelingAssistantProviderOfBaseDeDatosEditPart
		extends myBPMS.diagram.providers.MyBPMSModelingAssistantProvider {

}

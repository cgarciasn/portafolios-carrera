/*
 * 
 */
package myBPMS.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class MyBPMSModelingAssistantProviderOfTareaRecepMsjEditPart
		extends myBPMS.diagram.providers.MyBPMSModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSource(IAdaptable source) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSource((myBPMS.diagram.edit.parts.TareaRecepMsjEditPart) sourceEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSource(myBPMS.diagram.edit.parts.TareaRecepMsjEditPart source) {
		List<IElementType> types = new ArrayList<IElementType>(2);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsjRecepcion_msj_4009);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSourceAndTarget(IAdaptable source, IAdaptable target) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSourceAndTarget((myBPMS.diagram.edit.parts.TareaRecepMsjEditPart) sourceEditPart,
				targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSourceAndTarget(myBPMS.diagram.edit.parts.TareaRecepMsjEditPart source,
			IGraphicalEditPart targetEditPart) {
		List<IElementType> types = new LinkedList<IElementType>();
		if (targetEditPart instanceof myBPMS.diagram.edit.parts.TareaUsuarioEditPart) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015);
		}
		if (targetEditPart instanceof myBPMS.diagram.edit.parts.TareaServicioEditPart) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015);
		}
		if (targetEditPart instanceof myBPMS.diagram.edit.parts.TareaEnvioMsjEditPart) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015);
		}
		if (targetEditPart instanceof myBPMS.diagram.edit.parts.TareaRecepMsjEditPart) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015);
		}
		if (targetEditPart instanceof myBPMS.diagram.edit.parts.TareaConsultaEditPart) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015);
		}
		if (targetEditPart instanceof myBPMS.diagram.edit.parts.TareaBorradoEditPart) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015);
		}
		if (targetEditPart instanceof myBPMS.diagram.edit.parts.TareaInicioEditPart) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015);
		}
		if (targetEditPart instanceof myBPMS.diagram.edit.parts.TareaFinEditPart) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015);
		}
		if (targetEditPart instanceof myBPMS.diagram.edit.parts.TablaEditPart) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsjRecepcion_msj_4009);
		}
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForTarget(IAdaptable source, IElementType relationshipType) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForTarget((myBPMS.diagram.edit.parts.TareaRecepMsjEditPart) sourceEditPart, relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForTarget(myBPMS.diagram.edit.parts.TareaRecepMsjEditPart source,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuario_3001);
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicio_3002);
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsj_3003);
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsj_3004);
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsulta_3005);
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorrado_3006);
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaInicio_3007);
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaFin_3008);
		} else if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsjRecepcion_msj_4009) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.Tabla_3010);
		}
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnTarget((myBPMS.diagram.edit.parts.TareaRecepMsjEditPart) targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnTarget(myBPMS.diagram.edit.parts.TareaRecepMsjEditPart target) {
		List<IElementType> types = new ArrayList<IElementType>(1);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForSource(IAdaptable target, IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForSource((myBPMS.diagram.edit.parts.TareaRecepMsjEditPart) targetEditPart, relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForSource(myBPMS.diagram.edit.parts.TareaRecepMsjEditPart target,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.TareaSucesor_4015) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuario_3001);
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicio_3002);
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsj_3003);
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsj_3004);
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsulta_3005);
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorrado_3006);
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaInicio_3007);
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaFin_3008);
		}
		return types;
	}

}

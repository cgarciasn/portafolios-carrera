/*
 * 
 */
package myBPMS.diagram.providers;

import org.eclipse.gmf.runtime.common.ui.services.icon.IIconProvider;
import org.eclipse.gmf.tooling.runtime.providers.DefaultElementTypeIconProvider;

/**
 * @generated
 */
public class MyBPMSIconProvider extends DefaultElementTypeIconProvider implements IIconProvider {

	/**
	* @generated
	*/
	public MyBPMSIconProvider() {
		super(myBPMS.diagram.providers.MyBPMSElementTypes.TYPED_INSTANCE);
	}

}

/*
 * 
 */
package myBPMS.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class MyBPMSModelingAssistantProviderOfFicheroEditPart
		extends myBPMS.diagram.providers.MyBPMSModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnTarget((myBPMS.diagram.edit.parts.FicheroEditPart) targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnTarget(myBPMS.diagram.edit.parts.FicheroEditPart target) {
		List<IElementType> types = new ArrayList<IElementType>(3);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioUsa_4005);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioGenera_4006);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjAdjunta_4008);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForSource(IAdaptable target, IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForSource((myBPMS.diagram.edit.parts.FicheroEditPart) targetEditPart, relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForSource(myBPMS.diagram.edit.parts.FicheroEditPart target,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioUsa_4005) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicio_3002);
		} else if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioGenera_4006) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicio_3002);
		} else if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjAdjunta_4008) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsj_3003);
		}
		return types;
	}

}

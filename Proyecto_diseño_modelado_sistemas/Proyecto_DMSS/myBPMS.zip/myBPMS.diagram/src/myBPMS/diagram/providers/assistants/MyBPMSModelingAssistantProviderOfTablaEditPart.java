/*
 * 
 */
package myBPMS.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class MyBPMSModelingAssistantProviderOfTablaEditPart
		extends myBPMS.diagram.providers.MyBPMSModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnTarget((myBPMS.diagram.edit.parts.TablaEditPart) targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnTarget(myBPMS.diagram.edit.parts.TablaEditPart target) {
		List<IElementType> types = new ArrayList<IElementType>(6);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuarioFormularios_4003);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioServicio_4004);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjEnvio_msj_4007);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsjRecepcion_msj_4009);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_ajena_4012);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_primaria_4013);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForSource(IAdaptable target, IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForSource((myBPMS.diagram.edit.parts.TablaEditPart) targetEditPart, relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForSource(myBPMS.diagram.edit.parts.TablaEditPart target,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuarioFormularios_4003) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaUsuario_3001);
		} else if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicioServicio_4004) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaServicio_3002);
		} else if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsjEnvio_msj_4007) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaEnvioMsj_3003);
		} else if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsjRecepcion_msj_4009) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaRecepMsj_3004);
		} else if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_ajena_4012) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.Atributo_3011);
		} else if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_primaria_4013) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.Atributo_3011);
		}
		return types;
	}

}

/*
 * 
 */
package myBPMS.diagram.providers.assistants;

/**
 * @generated
 */
public class MyBPMSModelingAssistantProviderOfActorEditPart
		extends myBPMS.diagram.providers.MyBPMSModelingAssistantProvider {

}

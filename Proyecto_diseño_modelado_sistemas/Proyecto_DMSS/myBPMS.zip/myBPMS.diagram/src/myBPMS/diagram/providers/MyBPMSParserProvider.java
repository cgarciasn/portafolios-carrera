/*
 * 
 */
package myBPMS.diagram.providers;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.service.AbstractProvider;
import org.eclipse.gmf.runtime.common.core.service.IOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.GetParserOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParserProvider;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserService;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.ui.services.parser.ParserHintAdapter;
import org.eclipse.gmf.runtime.notation.View;

/**
 * @generated
 */
public class MyBPMSParserProvider extends AbstractProvider implements IParserProvider {

	/**
	* @generated
	*/
	private IParser actorId_actor_5008Parser;

	/**
	* @generated
	*/
	private IParser getActorId_actor_5008Parser() {
		if (actorId_actor_5008Parser == null) {
			EAttribute[] features = new EAttribute[] { myBPMS.MyBPMSPackage.eINSTANCE.getActor_Id_actor() };
			myBPMS.diagram.parsers.MessageFormatParser parser = new myBPMS.diagram.parsers.MessageFormatParser(
					features);
			actorId_actor_5008Parser = parser;
		}
		return actorId_actor_5008Parser;
	}

	/**
	* @generated
	*/
	private IParser baseDeDatosId_basedatos_5011Parser;

	/**
	* @generated
	*/
	private IParser getBaseDeDatosId_basedatos_5011Parser() {
		if (baseDeDatosId_basedatos_5011Parser == null) {
			EAttribute[] features = new EAttribute[] { myBPMS.MyBPMSPackage.eINSTANCE.getBaseDeDatos_Id_basedatos() };
			myBPMS.diagram.parsers.MessageFormatParser parser = new myBPMS.diagram.parsers.MessageFormatParser(
					features);
			baseDeDatosId_basedatos_5011Parser = parser;
		}
		return baseDeDatosId_basedatos_5011Parser;
	}

	/**
	* @generated
	*/
	private IParser tareaUsuarioId_tareaworkflow_5001Parser;

	/**
	* @generated
	*/
	private IParser getTareaUsuarioId_tareaworkflow_5001Parser() {
		if (tareaUsuarioId_tareaworkflow_5001Parser == null) {
			EAttribute[] features = new EAttribute[] {
					myBPMS.MyBPMSPackage.eINSTANCE.getTareaWorkflow_Id_tareaworkflow() };
			myBPMS.diagram.parsers.MessageFormatParser parser = new myBPMS.diagram.parsers.MessageFormatParser(
					features);
			tareaUsuarioId_tareaworkflow_5001Parser = parser;
		}
		return tareaUsuarioId_tareaworkflow_5001Parser;
	}

	/**
	* @generated
	*/
	private IParser tareaServicioId_tareaworkflow_5002Parser;

	/**
	* @generated
	*/
	private IParser getTareaServicioId_tareaworkflow_5002Parser() {
		if (tareaServicioId_tareaworkflow_5002Parser == null) {
			EAttribute[] features = new EAttribute[] {
					myBPMS.MyBPMSPackage.eINSTANCE.getTareaWorkflow_Id_tareaworkflow() };
			myBPMS.diagram.parsers.MessageFormatParser parser = new myBPMS.diagram.parsers.MessageFormatParser(
					features);
			tareaServicioId_tareaworkflow_5002Parser = parser;
		}
		return tareaServicioId_tareaworkflow_5002Parser;
	}

	/**
	* @generated
	*/
	private IParser tareaEnvioMsjId_tareaworkflow_5003Parser;

	/**
	* @generated
	*/
	private IParser getTareaEnvioMsjId_tareaworkflow_5003Parser() {
		if (tareaEnvioMsjId_tareaworkflow_5003Parser == null) {
			EAttribute[] features = new EAttribute[] {
					myBPMS.MyBPMSPackage.eINSTANCE.getTareaWorkflow_Id_tareaworkflow() };
			myBPMS.diagram.parsers.MessageFormatParser parser = new myBPMS.diagram.parsers.MessageFormatParser(
					features);
			tareaEnvioMsjId_tareaworkflow_5003Parser = parser;
		}
		return tareaEnvioMsjId_tareaworkflow_5003Parser;
	}

	/**
	* @generated
	*/
	private IParser tareaRecepMsjId_tareaworkflow_5004Parser;

	/**
	* @generated
	*/
	private IParser getTareaRecepMsjId_tareaworkflow_5004Parser() {
		if (tareaRecepMsjId_tareaworkflow_5004Parser == null) {
			EAttribute[] features = new EAttribute[] {
					myBPMS.MyBPMSPackage.eINSTANCE.getTareaWorkflow_Id_tareaworkflow() };
			myBPMS.diagram.parsers.MessageFormatParser parser = new myBPMS.diagram.parsers.MessageFormatParser(
					features);
			tareaRecepMsjId_tareaworkflow_5004Parser = parser;
		}
		return tareaRecepMsjId_tareaworkflow_5004Parser;
	}

	/**
	* @generated
	*/
	private IParser tareaConsultaId_tareaworkflow_5005Parser;

	/**
	* @generated
	*/
	private IParser getTareaConsultaId_tareaworkflow_5005Parser() {
		if (tareaConsultaId_tareaworkflow_5005Parser == null) {
			EAttribute[] features = new EAttribute[] {
					myBPMS.MyBPMSPackage.eINSTANCE.getTareaWorkflow_Id_tareaworkflow() };
			myBPMS.diagram.parsers.MessageFormatParser parser = new myBPMS.diagram.parsers.MessageFormatParser(
					features);
			tareaConsultaId_tareaworkflow_5005Parser = parser;
		}
		return tareaConsultaId_tareaworkflow_5005Parser;
	}

	/**
	* @generated
	*/
	private IParser tareaBorradoId_tareaworkflow_5006Parser;

	/**
	* @generated
	*/
	private IParser getTareaBorradoId_tareaworkflow_5006Parser() {
		if (tareaBorradoId_tareaworkflow_5006Parser == null) {
			EAttribute[] features = new EAttribute[] {
					myBPMS.MyBPMSPackage.eINSTANCE.getTareaWorkflow_Id_tareaworkflow() };
			myBPMS.diagram.parsers.MessageFormatParser parser = new myBPMS.diagram.parsers.MessageFormatParser(
					features);
			tareaBorradoId_tareaworkflow_5006Parser = parser;
		}
		return tareaBorradoId_tareaworkflow_5006Parser;
	}

	/**
	* @generated
	*/
	private IParser ficheroId_fichero_5007Parser;

	/**
	* @generated
	*/
	private IParser getFicheroId_fichero_5007Parser() {
		if (ficheroId_fichero_5007Parser == null) {
			EAttribute[] features = new EAttribute[] { myBPMS.MyBPMSPackage.eINSTANCE.getFichero_Id_fichero() };
			myBPMS.diagram.parsers.MessageFormatParser parser = new myBPMS.diagram.parsers.MessageFormatParser(
					features);
			ficheroId_fichero_5007Parser = parser;
		}
		return ficheroId_fichero_5007Parser;
	}

	/**
	* @generated
	*/
	private IParser tablaId_tabla_5010Parser;

	/**
	* @generated
	*/
	private IParser getTablaId_tabla_5010Parser() {
		if (tablaId_tabla_5010Parser == null) {
			EAttribute[] features = new EAttribute[] { myBPMS.MyBPMSPackage.eINSTANCE.getTabla_Id_tabla() };
			myBPMS.diagram.parsers.MessageFormatParser parser = new myBPMS.diagram.parsers.MessageFormatParser(
					features);
			tablaId_tabla_5010Parser = parser;
		}
		return tablaId_tabla_5010Parser;
	}

	/**
	* @generated
	*/
	private IParser atributoId_atributo_5009Parser;

	/**
	* @generated
	*/
	private IParser getAtributoId_atributo_5009Parser() {
		if (atributoId_atributo_5009Parser == null) {
			EAttribute[] features = new EAttribute[] { myBPMS.MyBPMSPackage.eINSTANCE.getAtributo_Id_atributo() };
			myBPMS.diagram.parsers.MessageFormatParser parser = new myBPMS.diagram.parsers.MessageFormatParser(
					features);
			atributoId_atributo_5009Parser = parser;
		}
		return atributoId_atributo_5009Parser;
	}

	/**
	* @generated
	*/
	protected IParser getParser(int visualID) {
		switch (visualID) {
		case myBPMS.diagram.edit.parts.ActorId_actorEditPart.VISUAL_ID:
			return getActorId_actor_5008Parser();
		case myBPMS.diagram.edit.parts.BaseDeDatosId_basedatosEditPart.VISUAL_ID:
			return getBaseDeDatosId_basedatos_5011Parser();
		case myBPMS.diagram.edit.parts.TareaUsuarioId_tareaworkflowEditPart.VISUAL_ID:
			return getTareaUsuarioId_tareaworkflow_5001Parser();
		case myBPMS.diagram.edit.parts.TareaServicioId_tareaworkflowEditPart.VISUAL_ID:
			return getTareaServicioId_tareaworkflow_5002Parser();
		case myBPMS.diagram.edit.parts.TareaEnvioMsjId_tareaworkflowEditPart.VISUAL_ID:
			return getTareaEnvioMsjId_tareaworkflow_5003Parser();
		case myBPMS.diagram.edit.parts.TareaRecepMsjId_tareaworkflowEditPart.VISUAL_ID:
			return getTareaRecepMsjId_tareaworkflow_5004Parser();
		case myBPMS.diagram.edit.parts.TareaConsultaId_tareaworkflowEditPart.VISUAL_ID:
			return getTareaConsultaId_tareaworkflow_5005Parser();
		case myBPMS.diagram.edit.parts.TareaBorradoId_tareaworkflowEditPart.VISUAL_ID:
			return getTareaBorradoId_tareaworkflow_5006Parser();
		case myBPMS.diagram.edit.parts.FicheroId_ficheroEditPart.VISUAL_ID:
			return getFicheroId_fichero_5007Parser();
		case myBPMS.diagram.edit.parts.TablaId_tablaEditPart.VISUAL_ID:
			return getTablaId_tabla_5010Parser();
		case myBPMS.diagram.edit.parts.AtributoId_atributoEditPart.VISUAL_ID:
			return getAtributoId_atributo_5009Parser();
		}
		return null;
	}

	/**
	* Utility method that consults ParserService
	* @generated
	*/
	public static IParser getParser(IElementType type, EObject object, String parserHint) {
		return ParserService.getInstance().getParser(new HintAdapter(type, object, parserHint));
	}

	/**
	* @generated
	*/
	public IParser getParser(IAdaptable hint) {
		String vid = (String) hint.getAdapter(String.class);
		if (vid != null) {
			return getParser(myBPMS.diagram.part.MyBPMSVisualIDRegistry.getVisualID(vid));
		}
		View view = (View) hint.getAdapter(View.class);
		if (view != null) {
			return getParser(myBPMS.diagram.part.MyBPMSVisualIDRegistry.getVisualID(view));
		}
		return null;
	}

	/**
	* @generated
	*/
	public boolean provides(IOperation operation) {
		if (operation instanceof GetParserOperation) {
			IAdaptable hint = ((GetParserOperation) operation).getHint();
			if (myBPMS.diagram.providers.MyBPMSElementTypes.getElement(hint) == null) {
				return false;
			}
			return getParser(hint) != null;
		}
		return false;
	}

	/**
	* @generated
	*/
	private static class HintAdapter extends ParserHintAdapter {

		/**
		* @generated
		*/
		private final IElementType elementType;

		/**
		* @generated
		*/
		public HintAdapter(IElementType type, EObject object, String parserHint) {
			super(object, parserHint);
			assert type != null;
			elementType = type;
		}

		/**
		* @generated
		*/
		public Object getAdapter(Class adapter) {
			if (IElementType.class.equals(adapter)) {
				return elementType;
			}
			return super.getAdapter(adapter);
		}
	}

}

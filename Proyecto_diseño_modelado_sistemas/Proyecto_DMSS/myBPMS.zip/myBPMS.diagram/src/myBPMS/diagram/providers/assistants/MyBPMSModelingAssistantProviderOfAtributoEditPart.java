/*
 * 
 */
package myBPMS.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class MyBPMSModelingAssistantProviderOfAtributoEditPart
		extends myBPMS.diagram.providers.MyBPMSModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSource(IAdaptable source) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSource((myBPMS.diagram.edit.parts.AtributoEditPart) sourceEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSource(myBPMS.diagram.edit.parts.AtributoEditPart source) {
		List<IElementType> types = new ArrayList<IElementType>(2);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_ajena_4012);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_primaria_4013);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSourceAndTarget(IAdaptable source, IAdaptable target) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSourceAndTarget((myBPMS.diagram.edit.parts.AtributoEditPart) sourceEditPart,
				targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSourceAndTarget(myBPMS.diagram.edit.parts.AtributoEditPart source,
			IGraphicalEditPart targetEditPart) {
		List<IElementType> types = new LinkedList<IElementType>();
		if (targetEditPart instanceof myBPMS.diagram.edit.parts.TablaEditPart) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_ajena_4012);
		}
		if (targetEditPart instanceof myBPMS.diagram.edit.parts.TablaEditPart) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_primaria_4013);
		}
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForTarget(IAdaptable source, IElementType relationshipType) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForTarget((myBPMS.diagram.edit.parts.AtributoEditPart) sourceEditPart, relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForTarget(myBPMS.diagram.edit.parts.AtributoEditPart source,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_ajena_4012) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.Tabla_3010);
		} else if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.AtributoClave_primaria_4013) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.Tabla_3010);
		}
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnTarget((myBPMS.diagram.edit.parts.AtributoEditPart) targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnTarget(myBPMS.diagram.edit.parts.AtributoEditPart target) {
		List<IElementType> types = new ArrayList<IElementType>(2);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsultaConsultar_atributo_4010);
		types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorradoBorrar_atributo_4011);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForSource(IAdaptable target, IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForSource((myBPMS.diagram.edit.parts.AtributoEditPart) targetEditPart, relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForSource(myBPMS.diagram.edit.parts.AtributoEditPart target,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsultaConsultar_atributo_4010) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaConsulta_3005);
		} else if (relationshipType == myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorradoBorrar_atributo_4011) {
			types.add(myBPMS.diagram.providers.MyBPMSElementTypes.TareaBorrado_3006);
		}
		return types;
	}

}

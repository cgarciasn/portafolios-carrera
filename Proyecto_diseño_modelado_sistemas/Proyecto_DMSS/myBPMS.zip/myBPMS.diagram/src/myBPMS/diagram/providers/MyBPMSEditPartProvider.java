/*
 * 
 */
package myBPMS.diagram.providers;

import org.eclipse.gmf.tooling.runtime.providers.DefaultEditPartProvider;

/**
 * @generated
 */
public class MyBPMSEditPartProvider extends DefaultEditPartProvider {

	/**
	* @generated
	*/
	public MyBPMSEditPartProvider() {
		super(new myBPMS.diagram.edit.parts.MyBPMSEditPartFactory(),
				myBPMS.diagram.part.MyBPMSVisualIDRegistry.TYPED_INSTANCE,
				myBPMS.diagram.edit.parts.ProcesoDeNegocioEditPart.MODEL_ID);
	}

}
